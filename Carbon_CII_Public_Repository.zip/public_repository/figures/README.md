# Figure files

1. Study workflow. Fuel prediction feeds a separate deterministic CII assessment.
2. Original project tuned-model fold metrics (exploratory; tuning used the folds).
3. Project-reported vessel-only versus vessel-plus-distance ablation.
4. In-sample actual/predicted fuel and residual diagnostics.
5. In-sample mean absolute error by vessel type.
6. Six largest global mean absolute SHAP attributions.
7. Baseline-to-scenario CII rating transition matrix; not a classifier confusion matrix.
8. Attained-CII percentage change and D/E grade-share distributions under the evaluated scenario.

Use the captions in the blinded manuscript as the authoritative captions.
