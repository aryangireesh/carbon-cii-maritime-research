# Rights and licensing review

This is a review package. No public upload has occurred.

- The project owner authorized public sharing of the analysis code and derived analytical dataset.
- Public availability of the EU MRV reporting portal is confirmed by EMSA, but the applicable reuse licence for the exact downloaded workbook was not verified. The European data portal's general guidance directs users to the original portal's licence when a resource-specific licence is absent.
- The combined derived dataset therefore has no licence assigned here. Public access and a reuse licence are different: posting without a licence does not grant permission to reuse beyond applicable law.
- The MarineVessels GitHub repository identifies an MIT license. The original `.rda` source file is not redistributed in this bundle; attribution and its MIT notice are included for transparency.
- The project scripts were authored within the project, but the author has not selected a software licence. No project-code licence is added.

Before public release, the author should choose whether to (a) publish without an explicit reuse licence, or (b) apply suitable licences after confirming source-data terms. A common option is MIT for original code and CC BY 4.0 for derived data, but this package does not apply those licences automatically.
