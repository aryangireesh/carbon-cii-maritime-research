import pandas as pd
import numpy as np
import os
import joblib

from sklearn.model_selection import KFold, cross_validate
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from xgboost import XGBRegressor


# ============================================================
# CARBON CII PROJECT - FINAL MODEL VALIDATION
# ============================================================

print("=" * 80)
print("CARBON CII PROJECT - FINAL MODEL VALIDATION")
print("=" * 80)


# ============================================================
# 1. PATHS
# ============================================================

INPUT_PATH = "data/processed/MRV_2023_feature_engineered.csv"

TUNED_MODEL_PATH = (
    "outputs/models/final_operational_xgboost_tuned.joblib"
)

OUTPUT_PATH = (
    "outputs/reports/final_model_validation_results.csv"
)

os.makedirs("outputs/reports", exist_ok=True)


# ============================================================
# 2. LOAD DATA
# ============================================================

df = pd.read_csv(INPUT_PATH)

print("\nDataset shape:")
print(df.shape)


# ============================================================
# 3. FEATURES AND TARGET
# ============================================================

features = [
    "Ship_Type",
    "GT",
    "DWT",
    "Length_m",
    "Beam_m",
    "Draft_m",
    "Vessel_Age",
    "Length_Beam_Ratio",
    "DWT_GT_ratio",
    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",
    "Sea_Time_Utilization"
]

TARGET = "Fuel_Consumption_t"

X = df[features].copy()
y = df[TARGET].copy()


# ============================================================
# 4. LOAD TUNED MODEL
# ============================================================

print("\nLoading tuned XGBoost model...")

tuned_model = joblib.load(TUNED_MODEL_PATH)

print("Tuned model loaded successfully.")


# ============================================================
# 5. CROSS-VALIDATION
# ============================================================

cv = KFold(
    n_splits=5,
    shuffle=True,
    random_state=42
)

scoring = {
    "R2": "r2",
    "MAE": "neg_mean_absolute_error",
    "RMSE": "neg_root_mean_squared_error"
}


# ============================================================
# 6. VALIDATE TUNED MODEL
# ============================================================

print("\n")
print("=" * 80)
print("5-FOLD CROSS-VALIDATION - TUNED MODEL")
print("=" * 80)

scores = cross_validate(
    tuned_model,
    X,
    y,
    cv=cv,
    scoring=scoring,
    n_jobs=-1,
    return_train_score=False
)


# ============================================================
# 7. CALCULATE METRICS
# ============================================================

tuned_r2_mean = scores["test_R2"].mean()
tuned_r2_std = scores["test_R2"].std()

tuned_mae_mean = -scores["test_MAE"].mean()
tuned_mae_std = scores["test_MAE"].std()

tuned_rmse_mean = -scores["test_RMSE"].mean()
tuned_rmse_std = scores["test_RMSE"].std()


print("\nTUNED MODEL PERFORMANCE")

print(
    f"R²   : {tuned_r2_mean:.4f} ± {tuned_r2_std:.4f}"
)

print(
    f"MAE  : {tuned_mae_mean:.2f} ± {tuned_mae_std:.2f} t"
)

print(
    f"RMSE : {tuned_rmse_mean:.2f} ± {tuned_rmse_std:.2f} t"
)


# ============================================================
# 8. BASELINE VALUES
# ============================================================

baseline_r2_mean = 0.9450
baseline_r2_std = 0.0160

baseline_mae_mean = 466.09
baseline_mae_std = 33.50

baseline_rmse_mean = 1044.22
baseline_rmse_std = 198.93


# ============================================================
# 9. COMPARE BASELINE VS TUNED
# ============================================================

print("\n")
print("=" * 80)
print("BASELINE VS TUNED MODEL")
print("=" * 80)


r2_improvement = tuned_r2_mean - baseline_r2_mean

mae_reduction = baseline_mae_mean - tuned_mae_mean

rmse_reduction = baseline_rmse_mean - tuned_rmse_mean


r2_percentage = (
    r2_improvement /
    abs(baseline_r2_mean)
) * 100


mae_percentage = (
    mae_reduction /
    baseline_mae_mean
) * 100


rmse_percentage = (
    rmse_reduction /
    baseline_rmse_mean
) * 100


comparison = pd.DataFrame({

    "Metric": [
        "R2",
        "MAE_t",
        "RMSE_t"
    ],

    "Baseline_Mean": [
        baseline_r2_mean,
        baseline_mae_mean,
        baseline_rmse_mean
    ],

    "Baseline_STD": [
        baseline_r2_std,
        baseline_mae_std,
        baseline_rmse_std
    ],

    "Tuned_Mean": [
        tuned_r2_mean,
        tuned_mae_mean,
        tuned_rmse_mean
    ],

    "Tuned_STD": [
        tuned_r2_std,
        tuned_mae_std,
        tuned_rmse_std
    ],

    "Improvement": [
        r2_improvement,
        mae_reduction,
        rmse_reduction
    ],

    "Percentage_Improvement": [
        r2_percentage,
        mae_percentage,
        rmse_percentage
    ]
})


print(
    comparison.to_string(
        index=False,
        float_format=lambda x: f"{x:.4f}"
    )
)


# ============================================================
# 10. FOLD-BY-FOLD PERFORMANCE
# ============================================================

print("\n")
print("=" * 80)
print("FOLD-BY-FOLD PERFORMANCE")
print("=" * 80)

fold_results = pd.DataFrame({
    "Fold": range(1, 6),

    "R2": scores["test_R2"],

    "MAE_t": -scores["test_MAE"],

    "RMSE_t": -scores["test_RMSE"]
})

print(
    fold_results.to_string(
        index=False,
        float_format=lambda x: f"{x:.4f}"
    )
)


# ============================================================
# 11. CHECK MODEL STABILITY
# ============================================================

print("\n")
print("=" * 80)
print("MODEL STABILITY CHECK")
print("=" * 80)


r2_cv = tuned_r2_std / tuned_r2_mean
mae_cv = tuned_mae_std / tuned_mae_mean
rmse_cv = tuned_rmse_std / tuned_rmse_mean


print(
    f"R² coefficient of variation   : {r2_cv:.4f}"
)

print(
    f"MAE coefficient of variation  : {mae_cv:.4f}"
)

print(
    f"RMSE coefficient of variation : {rmse_cv:.4f}"
)


# ============================================================
# 12. FINAL MODEL DECISION
# ============================================================

print("\n")
print("=" * 80)
print("FINAL MODEL DECISION")
print("=" * 80)


if tuned_rmse_mean < baseline_rmse_mean:

    print("\nTUNED MODEL SELECTED")

    print(
        "The tuned XGBoost model has lower cross-validated RMSE "
        "than the baseline model."
    )

    selected_model = "Tuned XGBoost"

else:

    print("\nBASELINE MODEL SELECTED")

    print(
        "The tuned model did not improve cross-validated RMSE "
        "over the baseline."
    )

    selected_model = "Baseline XGBoost"


print(f"\nSelected model: {selected_model}")


# ============================================================
# 13. SAVE RESULTS
# ============================================================

comparison_path = OUTPUT_PATH

comparison.to_csv(
    comparison_path,
    index=False
)


fold_path = (
    "outputs/reports/"
    "final_model_validation_fold_results.csv"
)

fold_results.to_csv(
    fold_path,
    index=False
)


# ============================================================
# 14. COMPLETION
# ============================================================

print("\n")
print("=" * 80)
print("FINAL MODEL VALIDATION COMPLETED")
print("=" * 80)

print("\nComparison saved:")
print(comparison_path)

print("\nFold results saved:")
print(fold_path)

print("\nSelected model:")
print(selected_model)

print("=" * 80)