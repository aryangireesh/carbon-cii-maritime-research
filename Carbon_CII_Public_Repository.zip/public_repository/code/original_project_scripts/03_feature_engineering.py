import pandas as pd
import numpy as np


# ============================================================
# CARBON CII PROJECT
# STEP 3 — FEATURE ENGINEERING & TARGET LEAKAGE AUDIT
# ============================================================

INPUT_PATH = "data/processed/MRV_2023_final_cleaned.csv"

OUTPUT_PATH = "data/processed/MRV_2023_feature_engineered.csv"


# ============================================================
# 1. LOAD CLEAN DATA
# ============================================================

print("=" * 75)
print("CARBON CII PROJECT - FEATURE ENGINEERING")
print("=" * 75)

df = pd.read_csv(INPUT_PATH)

print("\nDataset shape:")
print(df.shape)


# ============================================================
# 2. TARGET VARIABLE
# ============================================================

TARGET = "Fuel_Consumption_t"

print("\nTarget variable:")
print(TARGET)

print("\nTarget statistics:")
print(df[TARGET].describe())


# ============================================================
# 3. TARGET LEAKAGE AUDIT
# ============================================================

print("\n" + "=" * 75)
print("TARGET LEAKAGE AUDIT")
print("=" * 75)

leakage_columns = [
    "CO2_Emissions_t",
    "CO2_per_nm_kg",
    "Transport_Work_Mass",
    "Transport_Work_DWT",
    "Average_Cargo_Density"
]

print("\nThe following variables will NOT be used as ML predictors:")

for column in leakage_columns:
    if column in df.columns:
        print(f"  - {column}")


# ============================================================
# 4. VERIFY LEAKAGE COLUMNS
# ============================================================

print("\nLeakage columns present in dataset:")

for column in leakage_columns:
    print(
        f"{column:30s}: "
        f"{'YES' if column in df.columns else 'NO'}"
    )


# ============================================================
# 5. OPERATIONAL FEATURE ENGINEERING
# ============================================================

print("\n" + "=" * 75)
print("OPERATIONAL FEATURE ENGINEERING")
print("=" * 75)


# Average speed
df["Average_Speed_kn"] = (
    df["Distance_nm"] /
    df["Time_At_Sea_h"].replace(0, np.nan)
)

# Validate recalculated speed
invalid_speed = (
    (df["Average_Speed_kn"] < 3) |
    (df["Average_Speed_kn"] > 30)
)

print(
    f"Suspicious recalculated speeds: {invalid_speed.sum()}"
)

df.loc[invalid_speed, "Average_Speed_kn"] = np.nan


# Percentage of year spent at sea
# 8760 = 365 days × 24 hours
df["Sea_Time_Utilization"] = (
    df["Time_At_Sea_h"] / 8760
)


# ============================================================
# 6. VESSEL GEOMETRY FEATURES
# ============================================================

print("\nCreating vessel geometry features...")


# Length-to-beam ratio
df["Length_Beam_Ratio"] = (
    df["Length_m"] /
    df["Beam_m"].replace(0, np.nan)
)


# DWT / GT ratio
df["DWT_GT_ratio"] = (
    df["DWT"] /
    df["GT"].replace(0, np.nan)
)


# ============================================================
# 7. VESSEL AGE
# ============================================================

print("Creating vessel age features...")


df["Vessel_Age"] = (
    df["Reporting_Year"] -
    df["Build_Year"]
)


# ============================================================
# 8. AGE GROUP
# ============================================================

def age_category(age):

    if pd.isna(age):
        return "Unknown"

    elif age < 10:
        return "Young"

    elif age < 20:
        return "Middle-aged"

    elif age < 30:
        return "Old"

    else:
        return "Very old"


df["Age_Group"] = df["Vessel_Age"].apply(age_category)


# ============================================================
# 9. VESSEL SIZE CATEGORY
# ============================================================

def size_category(gt):

    if pd.isna(gt):
        return "Unknown"

    elif gt < 10000:
        return "Small"

    elif gt < 50000:
        return "Medium"

    elif gt < 100000:
        return "Large"

    else:
        return "Very Large"


df["Vessel_Size_Class"] = df["GT"].apply(size_category)


# ============================================================
# 10. OPERATIONAL SPEED CATEGORY
# ============================================================

def speed_category(speed):

    if pd.isna(speed):
        return "Unknown"

    elif speed < 8:
        return "Slow"

    elif speed < 14:
        return "Normal"

    elif speed < 20:
        return "Fast"

    else:
        return "Very Fast"


df["Speed_Class"] = df["Average_Speed_kn"].apply(speed_category)


# ============================================================
# 11. PRINT NEW FEATURES
# ============================================================

new_features = [
    "Average_Speed_kn",
    "Sea_Time_Utilization",
    "Length_Beam_Ratio",
    "DWT_GT_ratio",
    "Age_Group",
    "Vessel_Size_Class",
    "Speed_Class"
]

print("\nNew engineered features:")

for feature in new_features:
    print(f"  - {feature}")


# ============================================================
# 12. CHECK ENGINEERED FEATURES
# ============================================================

print("\n" + "=" * 75)
print("ENGINEERED FEATURE SUMMARY")
print("=" * 75)

for feature in new_features:

    if feature in df.columns:

        print(f"\n{feature}")

        if df[feature].dtype == "object":

            print(
                df[feature].value_counts(
                    dropna=False
                )
            )

        else:

            print(
                df[feature].describe()
            )


# ============================================================
# 13. DEFINE MODEL FEATURES
# ============================================================

print("\n" + "=" * 75)
print("MODEL FEATURE DEFINITIONS")
print("=" * 75)


# ------------------------------------------------------------
# MODEL A
# Operational fuel prediction
# ------------------------------------------------------------

operational_features = [

    "Ship_Type",

    "GT",
    "DWT",

    "Length_m",
    "Beam_m",
    "Draft_m",

    "Vessel_Age",

    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",

    "Length_Beam_Ratio",
    "DWT_GT_ratio",
    "Sea_Time_Utilization"
]


# ------------------------------------------------------------
# MODEL B
# Pre-operation fuel prediction
# ------------------------------------------------------------

preoperation_features = [

    "Ship_Type",

    "GT",
    "DWT",

    "Length_m",
    "Beam_m",
    "Draft_m",

    "Vessel_Age",

    "Length_Beam_Ratio",
    "DWT_GT_ratio"
]


print("\nMODEL A — OPERATIONAL")

for feature in operational_features:
    print(f"  {feature}")


print("\nMODEL B — PRE-OPERATION")

for feature in preoperation_features:
    print(f"  {feature}")


# ============================================================
# 14. VERIFY NO LEAKAGE IN MODEL FEATURES
# ============================================================

print("\n" + "=" * 75)
print("FINAL LEAKAGE CHECK")
print("=" * 75)

for model_name, features in [
    ("Operational", operational_features),
    ("Pre-operation", preoperation_features)
]:

    leakage_found = [
        feature
        for feature in features
        if feature in leakage_columns
    ]

    print(f"\n{model_name} model:")

    if leakage_found:

        print(
            "WARNING - Leakage detected:"
        )

        for feature in leakage_found:
            print(f"  {feature}")

    else:

        print(
            "PASS - No direct target leakage detected."
        )


# ============================================================
# 15. FEATURE CORRELATION
# ============================================================

print("\n" + "=" * 75)
print("FEATURE CORRELATION WITH TARGET")
print("=" * 75)

numeric_features = [
    feature
    for feature in operational_features
    if feature in df.columns
    and pd.api.types.is_numeric_dtype(df[feature])
]

correlations = (
    df[numeric_features + [TARGET]]
    .corr()[TARGET]
    .drop(TARGET)
    .sort_values(
        ascending=False
    )
)

print(correlations)


# ============================================================
# 16. MISSING VALUE REPORT
# ============================================================

print("\n" + "=" * 75)
print("MODEL FEATURE MISSING VALUES")
print("=" * 75)

all_model_features = list(
    dict.fromkeys(
        operational_features +
        preoperation_features
    )
)

missing_report = pd.DataFrame({

    "Feature": all_model_features,

    "Missing_Count": [
        df[feature].isna().sum()
        for feature in all_model_features
    ],

    "Missing_Percentage": [
        df[feature].isna().mean() * 100
        for feature in all_model_features
    ]

})

print(
    missing_report.to_string(
        index=False
    )
)


# ============================================================
# 17. SAVE FEATURE-ENGINEERED DATASET
# ============================================================

df.to_csv(
    OUTPUT_PATH,
    index=False
)

print("\n" + "=" * 75)
print("FEATURE ENGINEERING COMPLETED")
print("=" * 75)

print(
    f"\nFeature-engineered dataset saved to:\n"
    f"{OUTPUT_PATH}"
)

print("\nFinal dataset shape:")
print(df.shape)