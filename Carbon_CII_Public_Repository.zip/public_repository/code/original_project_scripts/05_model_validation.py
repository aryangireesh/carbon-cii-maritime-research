import pandas as pd
import numpy as np
import os

from sklearn.model_selection import KFold, cross_validate
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import (
    RandomForestRegressor,
    GradientBoostingRegressor
)

from xgboost import XGBRegressor


# ============================================================
# CARBON CII PROJECT
# STEP 5 — CROSS-VALIDATION
# ============================================================


# ============================================================
# 1. PATHS
# ============================================================

INPUT_PATH = "data/processed/MRV_2023_feature_engineered.csv"

OUTPUT_PATH = "outputs/reports/cross_validation_results.csv"


os.makedirs(
    "outputs/reports",
    exist_ok=True
)


# ============================================================
# 2. LOAD DATA
# ============================================================

print("=" * 80)
print("CARBON CII PROJECT - CROSS VALIDATION")
print("=" * 80)

df = pd.read_csv(INPUT_PATH)

print("\nDataset shape:")
print(df.shape)


# ============================================================
# 3. TARGET
# ============================================================

TARGET = "Fuel_Consumption_t"


# ============================================================
# 4. FEATURES
# ============================================================

operational_features = [

    "Ship_Type",

    "GT",
    "DWT",

    "Length_m",
    "Beam_m",
    "Draft_m",

    "Vessel_Age",

    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",

    "Length_Beam_Ratio",
    "DWT_GT_ratio",
    "Sea_Time_Utilization"
]


preoperation_features = [

    "Ship_Type",

    "GT",
    "DWT",

    "Length_m",
    "Beam_m",
    "Draft_m",

    "Vessel_Age",

    "Length_Beam_Ratio",
    "DWT_GT_ratio"
]


# ============================================================
# 5. MODELS
# ============================================================

models = {

    "Linear Regression": LinearRegression(),

    "Random Forest": RandomForestRegressor(
        n_estimators=400,
        max_features="sqrt",
        random_state=42,
        n_jobs=-1
    ),

    "Gradient Boosting": GradientBoostingRegressor(
        n_estimators=300,
        learning_rate=0.05,
        max_depth=3,
        loss="huber",
        random_state=42
    ),

    "XGBoost": XGBRegressor(
        n_estimators=500,
        learning_rate=0.05,
        max_depth=5,
        subsample=0.85,
        colsample_bytree=0.85,
        objective="reg:squarederror",
        random_state=42,
        n_jobs=-1
    )
}


# ============================================================
# 6. CROSS-VALIDATION CONFIGURATION
# ============================================================

cv = KFold(

    n_splits=5,

    shuffle=True,

    random_state=42

)


# ============================================================
# 7. TRAINING FUNCTION
# ============================================================

def validate_models(features, dataset_name):

    print("\n")
    print("=" * 80)
    print(f"{dataset_name.upper()} MODEL VALIDATION")
    print("=" * 80)


    X = df[features]

    y = df[TARGET]


    # --------------------------------------------------------
    # Feature types
    # --------------------------------------------------------

    categorical_features = [
        "Ship_Type"
    ]


    numerical_features = [

        feature

        for feature in features

        if feature not in categorical_features

    ]


    # --------------------------------------------------------
    # Numerical preprocessing
    # --------------------------------------------------------

    numerical_pipeline = Pipeline([

        (
            "imputer",

            SimpleImputer(

                strategy="median",

                add_indicator=True

            )
        ),

        (
            "scaler",

            StandardScaler()

        )

    ])


    # --------------------------------------------------------
    # Categorical preprocessing
    # --------------------------------------------------------

    categorical_pipeline = Pipeline([

        (
            "imputer",

            SimpleImputer(

                strategy="most_frequent"

            )
        ),

        (
            "onehot",

            OneHotEncoder(

                handle_unknown="ignore"

            )
        )

    ])


    # --------------------------------------------------------
    # Combined preprocessing
    # --------------------------------------------------------

    preprocessor = ColumnTransformer([

        (
            "numerical",

            numerical_pipeline,

            numerical_features

        ),

        (
            "categorical",

            categorical_pipeline,

            ["Ship_Type"]

        )

    ])


    results = []


    # ========================================================
    # LOOP THROUGH MODELS
    # ========================================================

    for model_name, model in models.items():

        print("\n" + "-" * 70)

        print(
            f"Validating {model_name}..."
        )

        print("-" * 70)


        pipeline = Pipeline([

            (
                "preprocessor",

                preprocessor

            ),

            (
                "model",

                model

            )

        ])


        # ----------------------------------------------------
        # Cross validation
        # ----------------------------------------------------

        scores = cross_validate(

            pipeline,

            X,

            y,

            cv=cv,

            scoring={

                "R2": "r2",

                "MAE": "neg_mean_absolute_error",

                "RMSE": "neg_root_mean_squared_error"

            },

            n_jobs=-1

        )


        # ----------------------------------------------------
        # Convert negative error metrics
        # ----------------------------------------------------

        r2_scores = scores["test_R2"]

        mae_scores = -scores["test_MAE"]

        rmse_scores = -scores["test_RMSE"]


        # ----------------------------------------------------
        # Calculate statistics
        # ----------------------------------------------------

        r2_mean = r2_scores.mean()

        r2_std = r2_scores.std()


        mae_mean = mae_scores.mean()

        mae_std = mae_scores.std()


        rmse_mean = rmse_scores.mean()

        rmse_std = rmse_scores.std()


        # ----------------------------------------------------
        # Print results
        # ----------------------------------------------------

        print(
            f"R²   : {r2_mean:.4f} ± {r2_std:.4f}"
        )

        print(
            f"MAE  : {mae_mean:.2f} ± {mae_std:.2f} tonnes"
        )

        print(
            f"RMSE : {rmse_mean:.2f} ± {rmse_std:.2f} tonnes"
        )


        # ----------------------------------------------------
        # Store results
        # ----------------------------------------------------

        results.append({

            "Dataset": dataset_name,

            "Model": model_name,

            "R2_Mean": r2_mean,

            "R2_STD": r2_std,

            "MAE_Mean_tonnes": mae_mean,

            "MAE_STD_tonnes": mae_std,

            "RMSE_Mean_tonnes": rmse_mean,

            "RMSE_STD_tonnes": rmse_std

        })


    return pd.DataFrame(results)


# ============================================================
# 8. OPERATIONAL VALIDATION
# ============================================================

operational_results = validate_models(

    operational_features,

    "Operational"

)


# ============================================================
# 9. PRE-OPERATION VALIDATION
# ============================================================

preoperation_results = validate_models(

    preoperation_features,

    "Pre-operation"

)


# ============================================================
# 10. COMBINE RESULTS
# ============================================================

results = pd.concat(

    [

        operational_results,

        preoperation_results

    ],

    ignore_index=True

)


# ============================================================
# 11. SORT
# ============================================================

results = results.sort_values(

    by="R2_Mean",

    ascending=False

)


# ============================================================
# 12. FINAL RESULTS
# ============================================================

print("\n")

print("=" * 80)

print("5-FOLD CROSS-VALIDATION RESULTS")

print("=" * 80)

print(

    results.to_string(

        index=False,

        float_format=lambda x: f"{x:.4f}"

    )

)


# ============================================================
# 13. SAVE
# ============================================================

results.to_csv(

    OUTPUT_PATH,

    index=False

)


# ============================================================
# 14. BEST MODEL
# ============================================================

best = results.iloc[0]


print("\n")

print("=" * 80)

print("BEST CROSS-VALIDATED MODEL")

print("=" * 80)

print(
    f"Dataset : {best['Dataset']}"
)

print(
    f"Model   : {best['Model']}"
)

print(
    f"R²      : "
    f"{best['R2_Mean']:.4f} ± "
    f"{best['R2_STD']:.4f}"
)

print(
    f"MAE     : "
    f"{best['MAE_Mean_tonnes']:.2f} ± "
    f"{best['MAE_STD_tonnes']:.2f} tonnes"
)

print(
    f"RMSE    : "
    f"{best['RMSE_Mean_tonnes']:.2f} ± "
    f"{best['RMSE_STD_tonnes']:.2f} tonnes"
)


print("\nResults saved to:")
print(OUTPUT_PATH)


print("\n" + "=" * 80)
print("CROSS-VALIDATION COMPLETED")
print("=" * 80)