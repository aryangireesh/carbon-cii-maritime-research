import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# ============================================================
# 1. LOAD DATA
# ============================================================

DATA_PATH = "data/processed/MRV_2023_cleaned_for_modeling.csv"

df = pd.read_csv(DATA_PATH)


# ============================================================
# 2. BASIC INFORMATION
# ============================================================

print("=" * 70)
print("CARBON CII PROJECT - DATA EXPLORATION")
print("=" * 70)

print("\nDataset shape:")
print(df.shape)

print("\nFirst 5 rows:")
print(df.head())

print("\nColumn names:")
print(df.columns.tolist())

print("\nData types:")
print(df.dtypes)

print("\nMissing values:")
print(df.isnull().sum())

print("\nDuplicate rows:")
print(df.duplicated().sum())

print("\nDuplicate IMO numbers:")
print(df["IMO"].duplicated().sum())


# ============================================================
# 3. NUMERICAL SUMMARY
# ============================================================

print("\nNumerical summary:")
print(df.describe().T)


# ============================================================
# 4. SHIP TYPE DISTRIBUTION
# ============================================================

print("\nShip type distribution:")
print(df["Ship_Type"].value_counts())


# ============================================================
# 5. FUEL CONSUMPTION
# ============================================================

print("\nFuel consumption statistics:")
print(df["Fuel_Consumption_t"].describe())


# ============================================================
# 6. CO2 EMISSIONS
# ============================================================

print("\nCO2 emissions statistics:")
print(df["CO2_Emissions_t"].describe())


# ============================================================
# 7. CORRELATION ANALYSIS
# ============================================================

numeric_columns = df.select_dtypes(include=np.number).columns

correlation = df[numeric_columns].corr()

print("\nCorrelation with fuel consumption:")
print(
    correlation["Fuel_Consumption_t"]
    .sort_values(ascending=False)
)


# ============================================================
# 8. FUEL DISTRIBUTION
# ============================================================

plt.figure(figsize=(10, 6))

sns.histplot(
    df["Fuel_Consumption_t"],
    bins=50,
    kde=True
)

plt.title("Fuel Consumption Distribution")
plt.xlabel("Fuel Consumption (tonnes)")
plt.ylabel("Number of Vessels")

plt.tight_layout()
plt.show()


# ============================================================
# 9. FUEL BY SHIP TYPE
# ============================================================

plt.figure(figsize=(12, 7))

sns.boxplot(
    data=df,
    x="Ship_Type",
    y="Fuel_Consumption_t"
)

plt.xticks(rotation=45, ha="right")

plt.title("Fuel Consumption by Ship Type")
plt.xlabel("Ship Type")
plt.ylabel("Fuel Consumption (tonnes)")

plt.tight_layout()
plt.show()


# ============================================================
# 10. DISTANCE VS FUEL
# ============================================================

plt.figure(figsize=(9, 6))

sns.scatterplot(
    data=df,
    x="Distance_nm",
    y="Fuel_Consumption_t",
    alpha=0.5
)

plt.title("Distance vs Fuel Consumption")
plt.xlabel("Distance (nautical miles)")
plt.ylabel("Fuel Consumption (tonnes)")

plt.tight_layout()
plt.show()


# ============================================================
# 11. TIME AT SEA VS FUEL
# ============================================================

plt.figure(figsize=(9, 6))

sns.scatterplot(
    data=df,
    x="Time_At_Sea_h",
    y="Fuel_Consumption_t",
    alpha=0.5
)

plt.title("Time at Sea vs Fuel Consumption")
plt.xlabel("Time at Sea (hours)")
plt.ylabel("Fuel Consumption (tonnes)")

plt.tight_layout()
plt.show()


print("\nData exploration completed successfully.")