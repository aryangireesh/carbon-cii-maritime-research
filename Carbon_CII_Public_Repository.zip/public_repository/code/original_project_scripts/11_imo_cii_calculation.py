import os
import numpy as np
import pandas as pd


# ============================================================
# CARBON CII PROJECT
# STEP 11 - IMO CII CALCULATION
# ============================================================
#
# Regulatory framework:
#
#   MEPC.352(78) - 2022 Guidelines for operational carbon
#                  intensity indicators and the calculation
#                  methods (G1)
#
#   MEPC.353(78) - 2022 Guidelines for reference lines
#                  (G2)
#
#   MEPC.338(76) - 2021 Guidelines on operational carbon
#                  intensity reduction factors relative to
#                  the 2019 reference line (G3)
#
#   MEPC.354(78) - 2022 Guidelines on the operational carbon
#                  intensity rating of ships (G4)
#
#   MEPC.355(78) - 2022 Guidelines on operational carbon
#                  intensity reduction factors relative to
#                  the 2019 reference line (G5 corrections
#                  and voyage adjustments)
#
# Dataset:
#   2023 EU MRV annual ship-level data
#
# IMPORTANT:
#   This script calculates the standard annual attained CII
#   from the available MRV data.
#
#   G5 correction factors / voyage adjustments are NOT applied
#   because the current dataset does not contain the detailed
#   voyage-level information required to determine them.
#
#   Low annual distance is treated as a DATA-QUALITY WARNING,
#   not an IMO applicability rule.
# ============================================================


print("=" * 90)
print("CARBON CII PROJECT - IMO CII CALCULATION")
print("=" * 90)


# ============================================================
# 1. PATHS
# ============================================================

INPUT_PATH = "data/processed/MRV_2023_feature_engineered.csv"

OUTPUT_DIR = "outputs/reports"

OUTPUT_PATH = os.path.join(
    OUTPUT_DIR,
    "imo_cii_2023_calculations.csv"
)

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)


# ============================================================
# 2. LOAD DATA
# ============================================================

df = pd.read_csv(
    INPUT_PATH
)

print("\nDataset shape:")
print(df.shape)


# ============================================================
# 3. REQUIRED COLUMNS
# ============================================================

required_columns = [
    "IMO",
    "Ship_Name",
    "Ship_Type",
    "Reporting_Year",
    "GT",
    "DWT",
    "Distance_nm",
    "CO2_Emissions_t"
]

missing_columns = [
    col
    for col in required_columns
    if col not in df.columns
]

if missing_columns:

    raise ValueError(
        "The following required columns are missing:\n"
        + "\n".join(missing_columns)
    )


# ============================================================
# 4. CII CALCULATION YEAR
# ============================================================

CII_YEAR = 2023

print(
    f"\nCII calculation year: {CII_YEAR}"
)


# ============================================================
# 5. IMO REDUCTION FACTOR - G3
# ============================================================

# Reduction factors relative to the 2019 reference line.
#
# For this project:
#
# 2023 = 5%
#
# Therefore:
#
# Required CII = Reference CII * 0.95
#
# Later values are retained here so the engine can be reused
# for future years.


Z_FACTORS = {
    2023: 5.000,
    2024: 7.000,
    2025: 9.000,
    2026: 11.000,
    2027: 13.625,
    2028: 16.250,
    2029: 18.875,
    2030: 21.500
}


if CII_YEAR not in Z_FACTORS:

    raise ValueError(
        f"No IMO Z reduction factor configured for {CII_YEAR}"
    )


Z = Z_FACTORS[CII_YEAR]

print(
    f"Z reduction factor: {Z:.3f}%"
)


# ============================================================
# 6. IMO REFERENCE-LINE PARAMETERS
#    MEPC.353(78)
# ============================================================
#
# Reference-line equation:
#
#   CII_reference = a * Capacity^(-c)
#
# Special capacity rules are handled separately.
# ============================================================


REFERENCE_LINES = {

    # --------------------------------------------------------
    # Bulk carrier
    # --------------------------------------------------------

    "Bulk carrier": {
        "capacity_type": "DWT",
        "a": 4745.0,
        "c": 0.622,
        "capacity_rule": "DWT capped at 279000"
    },

    # --------------------------------------------------------
    # Gas carrier
    # --------------------------------------------------------

    "Gas carrier >=65000": {
        "capacity_type": "DWT",
        "a": 14405e7,
        "c": 2.071,
        "capacity_rule": "DWT"
    },

    "Gas carrier <65000": {
        "capacity_type": "DWT",
        "a": 8104.0,
        "c": 0.639,
        "capacity_rule": "DWT"
    },

    # --------------------------------------------------------
    # Tanker
    #
    # Includes oil tanker and chemical tanker mappings.
    # --------------------------------------------------------

    "Tanker": {
        "capacity_type": "DWT",
        "a": 5247.0,
        "c": 0.610,
        "capacity_rule": "DWT"
    },

    # --------------------------------------------------------
    # Container ship
    # --------------------------------------------------------

    "Container ship": {
        "capacity_type": "DWT",
        "a": 1984.0,
        "c": 0.489,
        "capacity_rule": "DWT"
    },

    # --------------------------------------------------------
    # General cargo
    # --------------------------------------------------------

    "General cargo >=20000": {
        "capacity_type": "DWT",
        "a": 31948.0,
        "c": 0.792,
        "capacity_rule": "DWT"
    },

    "General cargo <20000": {
        "capacity_type": "DWT",
        "a": 588.0,
        "c": 0.3885,
        "capacity_rule": "DWT"
    },

    # --------------------------------------------------------
    # Refrigerated cargo
    # --------------------------------------------------------

    "Refrigerated cargo carrier": {
        "capacity_type": "DWT",
        "a": 4600.0,
        "c": 0.557,
        "capacity_rule": "DWT"
    },

    # --------------------------------------------------------
    # Combination carrier
    # --------------------------------------------------------

    "Combination carrier": {
        "capacity_type": "DWT",
        "a": 5119.0,
        "c": 0.622,
        "capacity_rule": "DWT"
    },

    # --------------------------------------------------------
    # LNG carrier
    # --------------------------------------------------------

    "LNG >=100000": {
        "capacity_type": "DWT",
        "a": 9.827,
        "c": 0.000,
        "capacity_rule": "DWT"
    },

    "LNG 65000-99999": {
        "capacity_type": "DWT",
        "a": 14479e10,
        "c": 2.673,
        "capacity_rule": "DWT"
    },

    "LNG <65000": {
        "capacity_type": "DWT",
        "a": 14779e10,
        "c": 2.673,
        "capacity_rule": "fixed 65000 DWT"
    },

    # --------------------------------------------------------
    # Vehicle carrier
    # --------------------------------------------------------

    "Vehicle carrier >=57700": {
        "capacity_type": "GT",
        "a": 3627.0,
        "c": 0.590,
        "capacity_rule": "fixed 57700 GT"
    },

    "Vehicle carrier 30000-57699": {
        "capacity_type": "GT",
        "a": 3627.0,
        "c": 0.590,
        "capacity_rule": "GT"
    },

    "Vehicle carrier <30000": {
        "capacity_type": "GT",
        "a": 330.0,
        "c": 0.329,
        "capacity_rule": "GT"
    },

    # --------------------------------------------------------
    # Ro-ro cargo
    # --------------------------------------------------------

    "Ro-ro cargo ship": {
        "capacity_type": "GT",
        "a": 1967.0,
        "c": 0.485,
        "capacity_rule": "GT"
    },

    # --------------------------------------------------------
    # Ro-ro passenger
    # --------------------------------------------------------

    "Ro-ro passenger ship": {
        "capacity_type": "GT",
        "a": 2023.0,
        "c": 0.460,
        "capacity_rule": "GT"
    },

    # --------------------------------------------------------
    # Cruise passenger
    # --------------------------------------------------------

    "Cruise passenger ship": {
        "capacity_type": "GT",
        "a": 930.0,
        "c": 0.383,
        "capacity_rule": "GT"
    }
}


# ============================================================
# 7. IMO RATING MULTIPLIERS
#    MEPC.354(78)
# ============================================================
#
# A:
#   Attained CII <= Required CII * d1
#
# B:
#   Attained CII <= Required CII * d2
#
# C:
#   Attained CII <= Required CII * d3
#
# D:
#   Attained CII <= Required CII * d4
#
# E:
#   Attained CII > Required CII * d4
# ============================================================


RATING_MULTIPLIERS = {

    "Bulk carrier":
        (0.86, 0.94, 1.06, 1.18),

    "Gas carrier >=65000":
        (0.81, 0.91, 1.12, 1.44),

    "Gas carrier <65000":
        (0.85, 0.95, 1.06, 1.25),

    "Tanker":
        (0.82, 0.93, 1.08, 1.28),

    "Container ship":
        (0.83, 0.94, 1.07, 1.19),

    "General cargo >=20000":
        (0.83, 0.94, 1.06, 1.19),

    "General cargo <20000":
        (0.83, 0.94, 1.06, 1.19),

    "Refrigerated cargo carrier":
        (0.78, 0.91, 1.07, 1.20),

    "Combination carrier":
        (0.87, 0.96, 1.06, 1.14),

    "LNG >=100000":
        (0.89, 0.98, 1.06, 1.13),

    "LNG 65000-99999":
        (0.78, 0.92, 1.10, 1.37),

    "LNG <65000":
        (0.78, 0.92, 1.10, 1.37),

    "Vehicle carrier >=57700":
        (0.86, 0.94, 1.06, 1.16),

    "Vehicle carrier 30000-57699":
        (0.86, 0.94, 1.06, 1.16),

    "Vehicle carrier <30000":
        (0.86, 0.94, 1.06, 1.16),

    "Ro-ro cargo ship":
        (0.76, 0.89, 1.08, 1.27),

    "Ro-ro passenger ship":
        (0.76, 0.92, 1.14, 1.30),

    "Cruise passenger ship":
        (0.87, 0.95, 1.06, 1.16)
}


# ============================================================
# 8. NUMERIC CONVERSION
# ============================================================

numeric_columns = [
    "GT",
    "DWT",
    "Distance_nm",
    "CO2_Emissions_t"
]


for col in numeric_columns:

    df[col] = pd.to_numeric(
        df[col],
        errors="coerce"
    )


# ============================================================
# 9. IMO CII SHIP-TYPE CLASSIFICATION
# ============================================================

def classify_imo_category(row):

    """
    Convert the EU MRV ship-type label into the corresponding
    IMO CII reference-line category where the mapping is
    sufficiently justified.

    IMPORTANT:
    We intentionally do NOT guess unsupported categories.
    """

    ship_type = str(
        row["Ship_Type"]
    ).strip()

    dwt = row["DWT"]

    gt = row["GT"]


    # --------------------------------------------------------
    # BULK CARRIER
    # --------------------------------------------------------

    if ship_type == "Bulk carrier":

        return "Bulk carrier"


    # --------------------------------------------------------
    # GAS CARRIER
    # --------------------------------------------------------

    elif ship_type == "Gas carrier":

        if pd.isna(dwt):
            return None

        if dwt >= 65000:
            return "Gas carrier >=65000"

        return "Gas carrier <65000"


    # --------------------------------------------------------
    # TANKER
    #
    # Oil tanker and chemical tanker are mapped to Tanker.
    # --------------------------------------------------------

    elif ship_type in [
        "Oil tanker",
        "Chemical tanker"
    ]:

        return "Tanker"


    # --------------------------------------------------------
    # CONTAINER SHIP
    # --------------------------------------------------------

    elif ship_type == "Container ship":

        return "Container ship"


    # --------------------------------------------------------
    # GENERAL CARGO
    # --------------------------------------------------------

    elif ship_type == "General cargo ship":

        if pd.isna(dwt):
            return None

        if dwt >= 20000:
            return "General cargo >=20000"

        return "General cargo <20000"


    # --------------------------------------------------------
    # REFRIGERATED CARGO
    # --------------------------------------------------------

    elif ship_type in [
        "refrigerated cargo ship",
        "Refrigerated cargo carrier"
    ]:

        return "Refrigerated cargo carrier"


    # --------------------------------------------------------
    # COMBINATION CARRIER
    # --------------------------------------------------------

    elif ship_type == "Combination carrier":

        return "Combination carrier"


    # --------------------------------------------------------
    # LNG CARRIER
    # --------------------------------------------------------

    elif ship_type == "LNG carrier":

        if pd.isna(dwt):
            return None

        if dwt >= 100000:

            return "LNG >=100000"

        elif dwt >= 65000:

            return "LNG 65000-99999"

        return "LNG <65000"


    # --------------------------------------------------------
    # VEHICLE CARRIER
    # --------------------------------------------------------

    elif ship_type == "Vehicle carrier":

        if pd.isna(gt):
            return None

        if gt >= 57700:

            return "Vehicle carrier >=57700"

        elif gt >= 30000:

            return "Vehicle carrier 30000-57699"

        return "Vehicle carrier <30000"


    # --------------------------------------------------------
    # RO-RO CARGO SHIP
    #
    # Corrected mapping:
    #
    # MRV: "Ro-ro ship"
    # IMO: "Ro-ro cargo ship"
    # --------------------------------------------------------

    elif ship_type == "Ro-ro ship":

        return "Ro-ro cargo ship"


    # --------------------------------------------------------
    # RO-RO PASSENGER SHIP
    #
    # MRV: "Ro-pax ship"
    # IMO: "Ro-ro passenger ship"
    # --------------------------------------------------------

    elif ship_type in [
        "Ro-pax",
        "Ro-pax ship"
    ]:

        return "Ro-ro passenger ship"


    # --------------------------------------------------------
    # CRUISE PASSENGER SHIP
    #
    # Explicitly identified cruise passenger records can
    # safely be mapped.
    #
    # Generic "Passenger ship" is NOT mapped.
    # --------------------------------------------------------

    elif ship_type in [
        "cruise passenger ship",
        "Passenger ship (Cruise Passenger ship)"
    ]:

        return "Cruise passenger ship"


    # --------------------------------------------------------
    # UNSUPPORTED / UNKNOWN
    #
    # Examples:
    #   Other ship types
    #   Passenger ship
    #   Container/ro-ro cargo ship
    #
    # We deliberately return None instead of guessing.
    # --------------------------------------------------------

    return None


df["IMO_CII_Category"] = df.apply(
    classify_imo_category,
    axis=1
)


# ============================================================
# 10. CII REGULATORY APPLICABILITY
# ============================================================

# General applicability criterion used here:
#
#   GT >= 5,000
#
# AND
#
#   ship belongs to a category covered by the CII framework.


df["CII_GT_Eligible"] = (
    df["GT"].notna()
    &
    (df["GT"] >= 5000)
)


df["CII_Ship_Type_Eligible"] = (
    df["IMO_CII_Category"].notna()
)


df["CII_Applicable"] = (
    df["CII_GT_Eligible"]
    &
    df["CII_Ship_Type_Eligible"]
)


# ============================================================
# 11. ATTAINED CII CAPACITY
# ============================================================

df["CII_Capacity"] = np.nan


# Explicit object dtype prevents pandas from throwing
# "Invalid value 'DWT' for dtype float64".

df["CII_Capacity_Type"] = pd.Series(
    pd.NA,
    index=df.index,
    dtype="object"
)


# ------------------------------------------------------------
# DWT-based categories
# ------------------------------------------------------------

dwt_categories = [

    "Bulk carrier",

    "Gas carrier >=65000",
    "Gas carrier <65000",

    "Tanker",

    "Container ship",

    "General cargo >=20000",
    "General cargo <20000",

    "Refrigerated cargo carrier",

    "Combination carrier",

    "LNG >=100000",
    "LNG 65000-99999"
]


for category in dwt_categories:

    mask = (
        df["IMO_CII_Category"] == category
    )

    df.loc[
        mask,
        "CII_Capacity"
    ] = df.loc[
        mask,
        "DWT"
    ]

    df.loc[
        mask,
        "CII_Capacity_Type"
    ] = "DWT"


# ------------------------------------------------------------
# LNG carrier <65,000 DWT
#
# Fixed capacity = 65,000 DWT.
# ------------------------------------------------------------

mask = (
    df["IMO_CII_Category"] == "LNG <65000"
)


df.loc[
    mask,
    "CII_Capacity"
] = 65000.0


df.loc[
    mask,
    "CII_Capacity_Type"
] = "65,000 DWT"


# ------------------------------------------------------------
# GT-based categories
# ------------------------------------------------------------

gt_categories = [

    "Vehicle carrier >=57700",
    "Vehicle carrier 30000-57699",
    "Vehicle carrier <30000",

    "Ro-ro cargo ship",

    "Ro-ro passenger ship",

    "Cruise passenger ship"
]


for category in gt_categories:

    mask = (
        df["IMO_CII_Category"] == category
    )

    df.loc[
        mask,
        "CII_Capacity"
    ] = df.loc[
        mask,
        "GT"
    ]

    df.loc[
        mask,
        "CII_Capacity_Type"
    ] = "GT"


# ============================================================
# 12. ACTIVITY / DATA QUALITY CHECK
# ============================================================

# IMPORTANT:
#
# There is NO arbitrary deletion here.
#
# We retain the records and explicitly flag suspicious
# annual activity.
#
# The threshold below is a PROJECT DATA-QUALITY WARNING,
# NOT an IMO regulatory exclusion.
#
# Why?
#
# A vessel can legitimately have a low annual distance because
# of partial-year operation, lay-up, entry/exit from service,
# etc.
#
# Therefore we don't automatically call such a vessel
# non-compliant.
#
# We withhold its A-E rating for review.


LOW_DISTANCE_THRESHOLD_NM = 1000.0


df["Activity_Quality_Flag"] = "Valid"


# ------------------------------------------------------------
# Invalid distance
# ------------------------------------------------------------

invalid_distance_mask = (
    df["Distance_nm"].isna()
    |
    (df["Distance_nm"] <= 0)
)


df.loc[
    invalid_distance_mask,
    "Activity_Quality_Flag"
] = "Invalid distance"


# ------------------------------------------------------------
# Invalid CO2
# ------------------------------------------------------------

invalid_co2_mask = (
    df["CO2_Emissions_t"].isna()
    |
    (df["CO2_Emissions_t"] <= 0)
)


df.loc[
    invalid_co2_mask,
    "Activity_Quality_Flag"
] = "Invalid CO2"


# ------------------------------------------------------------
# Invalid capacity
# ------------------------------------------------------------

invalid_capacity_mask = (
    df["CII_Capacity"].isna()
    |
    (df["CII_Capacity"] <= 0)
)


df.loc[
    invalid_capacity_mask,
    "Activity_Quality_Flag"
] = "Invalid capacity"


# ------------------------------------------------------------
# Low annual distance
#
# Only apply if the record is otherwise usable.
# ------------------------------------------------------------

low_distance_mask = (
    df["Distance_nm"].notna()
    &
    (df["Distance_nm"] > 0)
    &
    (df["Distance_nm"] < LOW_DISTANCE_THRESHOLD_NM)
)


valid_low_distance_mask = (
    low_distance_mask
    &
    ~invalid_co2_mask
    &
    ~invalid_capacity_mask
)


df.loc[
    valid_low_distance_mask,
    "Activity_Quality_Flag"
] = (
    "Low annual distance (<1000 NM)"
)


# ============================================================
# 13. ANNUAL CO2 IN GRAMS
# ============================================================

# MRV CO2:
#
#   metric tonnes
#
# CII requires:
#
#   grams CO2
#
# Therefore:
#
#   1 tonne = 1,000,000 grams


df["Annual_CO2_g"] = (
    df["CO2_Emissions_t"] * 1_000_000
)


# ============================================================
# 14. ATTAINED CII
# ============================================================

# Formula:
#
#   Attained CII = Annual CO2 / (Capacity × Distance)
#
# Unit:
#
#   g CO2 / (capacity × nautical mile)


valid_attained_inputs = (
    df["CII_Applicable"]
    &
    df["CII_Capacity"].notna()
    &
    (df["CII_Capacity"] > 0)
    &
    df["Distance_nm"].notna()
    &
    (df["Distance_nm"] > 0)
    &
    df["CO2_Emissions_t"].notna()
    &
    (df["CO2_Emissions_t"] > 0)
)


df["Attained_CII"] = np.nan


df.loc[
    valid_attained_inputs,
    "Attained_CII"
] = (
    df.loc[
        valid_attained_inputs,
        "Annual_CO2_g"
    ]
    /
    (
        df.loc[
            valid_attained_inputs,
            "CII_Capacity"
        ]
        *
        df.loc[
            valid_attained_inputs,
            "Distance_nm"
        ]
    )
)


# ============================================================
# 15. REFERENCE-LINE CAPACITY
# ============================================================

df["Reference_Capacity"] = np.nan


df["Reference_Capacity_Type"] = pd.Series(
    pd.NA,
    index=df.index,
    dtype="object"
)


# ------------------------------------------------------------
# Bulk carrier
#
# Reference capacity capped at 279,000 DWT.
# ------------------------------------------------------------

mask = (
    df["IMO_CII_Category"] == "Bulk carrier"
)


df.loc[
    mask,
    "Reference_Capacity"
] = df.loc[
    mask,
    "DWT"
].clip(
    upper=279000
)


df.loc[
    mask,
    "Reference_Capacity_Type"
] = "DWT (max 279000)"


# ------------------------------------------------------------
# LNG <65,000
# ------------------------------------------------------------

mask = (
    df["IMO_CII_Category"] == "LNG <65000"
)


df.loc[
    mask,
    "Reference_Capacity"
] = 65000.0


df.loc[
    mask,
    "Reference_Capacity_Type"
] = "65,000 DWT"


# ------------------------------------------------------------
# Vehicle carrier >=57,700 GT
# ------------------------------------------------------------

mask = (
    df["IMO_CII_Category"]
    == "Vehicle carrier >=57700"
)


df.loc[
    mask,
    "Reference_Capacity"
] = 57700.0


df.loc[
    mask,
    "Reference_Capacity_Type"
] = "57,700 GT"


# ------------------------------------------------------------
# Vehicle carrier 30,000-57,699 GT
# ------------------------------------------------------------

mask = (
    df["IMO_CII_Category"]
    == "Vehicle carrier 30000-57699"
)


df.loc[
    mask,
    "Reference_Capacity"
] = df.loc[
    mask,
    "GT"
]


df.loc[
    mask,
    "Reference_Capacity_Type"
] = "GT"


# ------------------------------------------------------------
# Vehicle carrier <30,000 GT
# ------------------------------------------------------------

mask = (
    df["IMO_CII_Category"]
    == "Vehicle carrier <30000"
)


df.loc[
    mask,
    "Reference_Capacity"
] = df.loc[
    mask,
    "GT"
]


df.loc[
    mask,
    "Reference_Capacity_Type"
] = "GT"


# ------------------------------------------------------------
# All remaining supported categories
# ------------------------------------------------------------

remaining_mask = (
    df["IMO_CII_Category"].notna()
    &
    df["Reference_Capacity"].isna()
)


df.loc[
    remaining_mask,
    "Reference_Capacity"
] = df.loc[
    remaining_mask,
    "CII_Capacity"
]


df.loc[
    remaining_mask,
    "Reference_Capacity_Type"
] = df.loc[
    remaining_mask,
    "CII_Capacity_Type"
]


# ============================================================
# 16. REFERENCE-LINE PARAMETERS
# ============================================================

df["Reference_a"] = np.nan

df["Reference_c"] = np.nan

df["Reference_Line_Name"] = pd.Series(
    pd.NA,
    index=df.index,
    dtype="object"
)


for category, params in REFERENCE_LINES.items():

    mask = (
        df["IMO_CII_Category"] == category
    )

    df.loc[
        mask,
        "Reference_a"
    ] = params["a"]

    df.loc[
        mask,
        "Reference_c"
    ] = params["c"]

    df.loc[
        mask,
        "Reference_Line_Name"
    ] = category


# ============================================================
# 17. REFERENCE CII
# ============================================================

valid_reference_inputs = (
    df["CII_Applicable"]
    &
    df["Reference_Capacity"].notna()
    &
    (df["Reference_Capacity"] > 0)
    &
    df["Reference_a"].notna()
    &
    df["Reference_c"].notna()
)


df["Reference_CII"] = np.nan


df.loc[
    valid_reference_inputs,
    "Reference_CII"
] = (
    df.loc[
        valid_reference_inputs,
        "Reference_a"
    ]
    *
    np.power(
        df.loc[
            valid_reference_inputs,
            "Reference_Capacity"
        ],
        -df.loc[
            valid_reference_inputs,
            "Reference_c"
        ]
    )
)


# ============================================================
# 18. REQUIRED CII
# ============================================================

# Required CII:
#
#   Required CII =
#       Reference CII × (1 - Z)
#
# For 2023:
#
#   Required CII =
#       Reference CII × 0.95


df["Required_CII"] = np.nan


df.loc[
    valid_reference_inputs,
    "Required_CII"
] = (
    df.loc[
        valid_reference_inputs,
        "Reference_CII"
    ]
    *
    (1 - Z / 100)
)


# ============================================================
# 19. CII RATIO
# ============================================================

# Ratio:
#
#   CII Ratio =
#       Attained CII / Required CII
#
# Interpretation:
#
#   < 1.0  -> below required CII
#   = 1.0  -> equal to required CII
#   > 1.0  -> above required CII


df["CII_Ratio"] = np.nan


valid_ratio_inputs = (
    df["Attained_CII"].notna()
    &
    df["Required_CII"].notna()
    &
    (df["Required_CII"] > 0)
)


df.loc[
    valid_ratio_inputs,
    "CII_Ratio"
] = (
    df.loc[
        valid_ratio_inputs,
        "Attained_CII"
    ]
    /
    df.loc[
        valid_ratio_inputs,
        "Required_CII"
    ]
)


# ============================================================
# 20. RATING BOUNDARIES
# ============================================================

df["CII_A_Boundary"] = np.nan
df["CII_B_Boundary"] = np.nan
df["CII_C_Boundary"] = np.nan
df["CII_D_Boundary"] = np.nan


for category, multipliers in RATING_MULTIPLIERS.items():

    mask = (
        df["IMO_CII_Category"] == category
    )

    d1, d2, d3, d4 = multipliers


    df.loc[
        mask,
        "CII_A_Boundary"
    ] = (
        df.loc[
            mask,
            "Required_CII"
        ] * d1
    )


    df.loc[
        mask,
        "CII_B_Boundary"
    ] = (
        df.loc[
            mask,
            "Required_CII"
        ] * d2
    )


    df.loc[
        mask,
        "CII_C_Boundary"
    ] = (
        df.loc[
            mask,
            "Required_CII"
        ] * d3
    )


    df.loc[
        mask,
        "CII_D_Boundary"
    ] = (
        df.loc[
            mask,
            "Required_CII"
        ] * d4
    )


# ============================================================
# 21. CII STATUS
# ============================================================

df["CII_Status"] = "Not Applicable"


# ------------------------------------------------------------
# Unsupported ship type
# ------------------------------------------------------------

unsupported_mask = (
    ~df["CII_Ship_Type_Eligible"]
)


df.loc[
    unsupported_mask,
    "CII_Status"
] = "Unsupported ship type"


# ------------------------------------------------------------
# Below 5000 GT
# ------------------------------------------------------------

below_gt_mask = (
    df["CII_Ship_Type_Eligible"]
    &
    ~df["CII_GT_Eligible"]
)


df.loc[
    below_gt_mask,
    "CII_Status"
] = "Below 5000 GT"


# ------------------------------------------------------------
# Insufficient calculation data
# ------------------------------------------------------------

invalid_calculation_mask = (
    df["CII_Applicable"]
    &
    (
        df["Attained_CII"].isna()
        |
        df["Required_CII"].isna()
    )
)


df.loc[
    invalid_calculation_mask,
    "CII_Status"
] = "Insufficient calculation data"


# ------------------------------------------------------------
# Low annual distance
#
# Numerical CII is retained.
# Rating is withheld.
# ------------------------------------------------------------

low_activity_mask = (
    df["CII_Applicable"]
    &
    df["Attained_CII"].notna()
    &
    df["Required_CII"].notna()
    &
    low_distance_mask
)


df.loc[
    low_activity_mask,
    "CII_Status"
] = (
    "Valid calculation - low annual distance warning"
)


# ------------------------------------------------------------
# Valid calculation
# ------------------------------------------------------------

valid_rating_mask = (
    df["CII_Applicable"]
    &
    df["Attained_CII"].notna()
    &
    df["Required_CII"].notna()
    &
    ~low_activity_mask
)


df.loc[
    valid_rating_mask,
    "CII_Status"
] = "Valid"


# ============================================================
# 22. FINAL A-E RATING
# ============================================================

df["CII_Rating"] = pd.Series(
    pd.NA,
    index=df.index,
    dtype="object"
)


def calculate_rating(row):

    status = row["CII_Status"]


    # --------------------------------------------------------
    # Not applicable
    # --------------------------------------------------------

    if status == "Not Applicable":
        return "Not Applicable"


    # --------------------------------------------------------
    # Unsupported category
    # --------------------------------------------------------

    if status == "Unsupported ship type":
        return "Not Applicable"


    # --------------------------------------------------------
    # Below regulatory threshold
    # --------------------------------------------------------

    if status == "Below 5000 GT":
        return "Not Applicable"


    # --------------------------------------------------------
    # Missing data
    # --------------------------------------------------------

    if status == "Insufficient calculation data":
        return "Insufficient Data"


    # --------------------------------------------------------
    # Low activity
    # --------------------------------------------------------

    if status == (
        "Valid calculation - low annual distance warning"
    ):

        return "Review - Low Activity"


    attained = row["Attained_CII"]

    boundary_a = row["CII_A_Boundary"]
    boundary_b = row["CII_B_Boundary"]
    boundary_c = row["CII_C_Boundary"]
    boundary_d = row["CII_D_Boundary"]


    if pd.isna(attained):
        return "Insufficient Data"


    if pd.isna(boundary_a):
        return "Insufficient Data"


    if attained <= boundary_a:
        return "A"

    elif attained <= boundary_b:
        return "B"

    elif attained <= boundary_c:
        return "C"

    elif attained <= boundary_d:
        return "D"

    else:
        return "E"


df["CII_Rating"] = df.apply(
    calculate_rating,
    axis=1
)


# ============================================================
# 23. G5 CORRECTION STATUS
# ============================================================

# We do not have the voyage-level information required to
# calculate all applicable correction factors / adjustments.
#
# Therefore, the result is explicitly labelled as an
# unadjusted standard annual CII calculation.


df["CII_Correction_Applied"] = False


df["CII_Correction_Status"] = (
    "G5 corrections not applied - "
    "voyage-level inputs unavailable"
)


# ============================================================
# 24. FINAL VALIDITY FLAG
# ============================================================

# A numerical CII calculation is valid if:
#
#   - ship is CII applicable
#   - attained CII exists
#   - required CII exists
#
# Low-activity records are retained as valid numerical
# calculations but their A-E rating is withheld.


df["CII_Valid"] = (
    df["CII_Status"].isin(
        [
            "Valid",
            "Valid calculation - low annual distance warning"
        ]
    )
    &
    df["Attained_CII"].notna()
    &
    df["Required_CII"].notna()
)


# ============================================================
# 25. PRINT REGULATORY APPLICABILITY
# ============================================================

print("\n")
print("=" * 90)
print("CII REGULATORY APPLICABILITY")
print("=" * 90)

print(
    df["CII_Applicable"]
    .value_counts()
)


# ============================================================
# 26. PRINT SHIP-TYPE MAPPING
# ============================================================

print("\n")
print("=" * 90)
print("IMO CII CATEGORY MAPPING")
print("=" * 90)


mapping_summary = (
    df.groupby(
        [
            "Ship_Type",
            "IMO_CII_Category"
        ],
        dropna=False
    )
    .size()
    .reset_index(
        name="Count"
    )
    .sort_values(
        "Count",
        ascending=False
    )
)


print(
    mapping_summary.to_string(
        index=False
    )
)


# ============================================================
# 27. CII STATUS SUMMARY
# ============================================================

print("\n")
print("=" * 90)
print("CII STATUS SUMMARY")
print("=" * 90)


print(
    df["CII_Status"]
    .value_counts(
        dropna=False
    )
)


# ============================================================
# 28. ACTIVITY QUALITY SUMMARY
# ============================================================

print("\n")
print("=" * 90)
print("ACTIVITY QUALITY SUMMARY")
print("=" * 90)


print(
    df["Activity_Quality_Flag"]
    .value_counts(
        dropna=False
    )
)


# ============================================================
# 29. RATING SUMMARY
# ============================================================

print("\n")
print("=" * 90)
print("CII RATING SUMMARY")
print("=" * 90)


rating_order = [
    "A",
    "B",
    "C",
    "D",
    "E",
    "Review - Low Activity",
    "Insufficient Data",
    "Not Applicable"
]


rating_counts = (
    df["CII_Rating"]
    .value_counts()
    .reindex(
        rating_order,
        fill_value=0
    )
)


print(
    rating_counts
)


# ============================================================
# 30. VALID A-E RATING COUNT
# ============================================================

ae_mask = (
    df["CII_Rating"].isin(
        [
            "A",
            "B",
            "C",
            "D",
            "E"
        ]
    )
)


print("\n")
print("=" * 90)
print("VALID A-E RATING COUNT")
print("=" * 90)


print(
    int(ae_mask.sum())
)


# ============================================================
# 31. ATTAINED CII STATISTICS
# ============================================================

cii_valid_mask = (
    df["CII_Valid"]
    &
    df["Attained_CII"].notna()
)


print("\n")
print("=" * 90)
print("ATTAINED CII STATISTICS")
print("=" * 90)


if cii_valid_mask.sum() > 0:

    print(
        df.loc[
            cii_valid_mask,
            "Attained_CII"
        ].describe()
    )

else:

    print(
        "No valid CII values."
    )


# ============================================================
# 32. CII RATIO STATISTICS
# ============================================================

ratio_mask = (
    ae_mask
    &
    df["CII_Ratio"].notna()
)


print("\n")
print("=" * 90)
print("CII RATIO STATISTICS - A-E RATED SHIPS")
print("=" * 90)


if ratio_mask.sum() > 0:

    print(
        df.loc[
            ratio_mask,
            "CII_Ratio"
        ].describe()
    )

else:

    print(
        "No valid A-E CII ratios."
    )


# ============================================================
# 33. WORST A-E PERFORMERS
# ============================================================

print("\n")
print("=" * 90)
print("TOP 10 WORST A-E CII PERFORMERS")
print("=" * 90)


worst_columns = [
    "IMO",
    "Ship_Name",
    "Ship_Type",
    "GT",
    "DWT",
    "Distance_nm",
    "CO2_Emissions_t",
    "Attained_CII",
    "Reference_CII",
    "Required_CII",
    "CII_Ratio",
    "CII_Rating"
]


worst = (
    df.loc[
        ae_mask,
        worst_columns
    ]
    .sort_values(
        "CII_Ratio",
        ascending=False
    )
    .head(10)
)


print(
    worst.to_string(
        index=False
    )
)


# ============================================================
# 34. BEST A-E PERFORMERS
# ============================================================

print("\n")
print("=" * 90)
print("TOP 10 BEST A-E CII PERFORMERS")
print("=" * 90)


best = (
    df.loc[
        ae_mask,
        worst_columns
    ]
    .sort_values(
        "CII_Ratio",
        ascending=True
    )
    .head(10)
)


print(
    best.to_string(
        index=False
    )
)


# ============================================================
# 35. LOW-ACTIVITY VESSELS
# ============================================================

print("\n")
print("=" * 90)
print("LOW-ACTIVITY VESSELS - RATING WITHHELD")
print("=" * 90)


low_activity_columns = [
    "IMO",
    "Ship_Name",
    "Ship_Type",
    "GT",
    "DWT",
    "Distance_nm",
    "Time_At_Sea_h",
    "CO2_Emissions_t",
    "Attained_CII",
    "Required_CII",
    "CII_Ratio",
    "CII_Rating"
]


available_low_columns = [
    col
    for col in low_activity_columns
    if col in df.columns
]


low_activity_output = (
    df.loc[
        df["CII_Rating"] ==
        "Review - Low Activity",
        available_low_columns
    ]
    .sort_values(
        "Distance_nm"
    )
    .head(20)
)


if len(low_activity_output) > 0:

    print(
        low_activity_output.to_string(
            index=False
        )
    )

else:

    print(
        "No low-activity vessels found."
    )


# ============================================================
# 36. UNSUPPORTED / UNMAPPED SHIP TYPES
# ============================================================

print("\n")
print("=" * 90)
print("UNSUPPORTED / UNMAPPED SHIP TYPES")
print("=" * 90)


unsupported = (
    df.loc[
        ~df["CII_Ship_Type_Eligible"],
        "Ship_Type"
    ]
    .value_counts()
)


if len(unsupported) > 0:

    print(
        unsupported
    )

else:

    print(
        "No unsupported ship types."
    )


# ============================================================
# 37. CII RATING PERCENTAGES
# ============================================================

print("\n")
print("=" * 90)
print("A-E RATING PERCENTAGES")
print("=" * 90)


if ae_mask.sum() > 0:

    rating_percentage = (
        df.loc[
            ae_mask,
            "CII_Rating"
        ]
        .value_counts()
        .reindex(
            [
                "A",
                "B",
                "C",
                "D",
                "E"
            ],
            fill_value=0
        )
    )

    rating_percentage = (
        rating_percentage
        /
        rating_percentage.sum()
        *
        100
    )

    print(
        rating_percentage.round(2)
    )

else:

    print(
        "No A-E ratings available."
    )


# ============================================================
# 38. D/E VESSEL COUNT
# ============================================================

de_mask = (
    df["CII_Rating"].isin(
        [
            "D",
            "E"
        ]
    )
)


print("\n")
print("=" * 90)
print("D + E RATING COUNT")
print("=" * 90)


print(
    int(de_mask.sum())
)


if ae_mask.sum() > 0:

    print(
        "D + E percentage: "
        f"{(de_mask.sum() / ae_mask.sum()) * 100:.2f}%"
    )


# ============================================================
# 39. SAVE OUTPUT
# ============================================================

output_columns = [

    # Vessel identity
    "IMO",
    "Ship_Name",
    "Ship_Type",
    "Reporting_Year",

    # Vessel characteristics
    "GT",
    "DWT",

    # Annual activity
    "Distance_nm",
    "CO2_Emissions_t",
    "Annual_CO2_g",

    # IMO category
    "IMO_CII_Category",

    # Applicability
    "CII_GT_Eligible",
    "CII_Ship_Type_Eligible",
    "CII_Applicable",

    # Attained CII capacity
    "CII_Capacity",
    "CII_Capacity_Type",

    # Reference line
    "Reference_Capacity",
    "Reference_Capacity_Type",
    "Reference_Line_Name",
    "Reference_a",
    "Reference_c",

    # CII calculations
    "Reference_CII",
    "Required_CII",
    "Attained_CII",
    "CII_Ratio",

    # Rating boundaries
    "CII_A_Boundary",
    "CII_B_Boundary",
    "CII_C_Boundary",
    "CII_D_Boundary",

    # Final rating
    "CII_Rating",

    # Quality / audit
    "Activity_Quality_Flag",
    "CII_Status",

    # G5
    "CII_Correction_Applied",
    "CII_Correction_Status",

    # Final validity
    "CII_Valid"
]


output_columns = [
    col
    for col in output_columns
    if col in df.columns
]


output = df[
    output_columns
].copy()


output.to_csv(
    OUTPUT_PATH,
    index=False
)


# ============================================================
# 40. FINAL SUMMARY
# ============================================================

print("\n")
print("=" * 90)
print("IMO CII CALCULATION COMPLETED")
print("=" * 90)


print(
    f"\nTotal vessels: "
    f"{len(df):,}"
)


print(
    f"CII applicable: "
    f"{int(df['CII_Applicable'].sum()):,}"
)


print(
    f"Valid CII calculations: "
    f"{int(df['CII_Valid'].sum()):,}"
)


print(
    f"Final A-E ratings: "
    f"{int(ae_mask.sum()):,}"
)


print(
    f"Low-activity reviews: "
    f"{int((df['CII_Rating'] == 'Review - Low Activity').sum()):,}"
)


print(
    f"Unsupported ship type: "
    f"{int((df['CII_Status'] == 'Unsupported ship type').sum()):,}"
)


print(
    f"\nOutput saved to:"
    f"\n{OUTPUT_PATH}"
)


print("\n")
print("=" * 90)