import pandas as pd
import numpy as np
import os

from sklearn.model_selection import KFold, RandomizedSearchCV
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder

from xgboost import XGBRegressor

import joblib


# ============================================================
# CARBON CII PROJECT - XGBOOST HYPERPARAMETER TUNING
# ============================================================

print("=" * 80)
print("CARBON CII PROJECT - XGBOOST HYPERPARAMETER TUNING")
print("=" * 80)


# ============================================================
# 1. PATHS
# ============================================================

INPUT_PATH = "data/processed/MRV_2023_feature_engineered.csv"

REPORT_DIR = "outputs/reports"
MODEL_DIR = "outputs/models"

os.makedirs(REPORT_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)


# ============================================================
# 2. LOAD DATA
# ============================================================

df = pd.read_csv(INPUT_PATH)

print("\nDataset shape:")
print(df.shape)


# ============================================================
# 3. FEATURES
# ============================================================

features = [
    "Ship_Type",
    "GT",
    "DWT",
    "Length_m",
    "Beam_m",
    "Draft_m",
    "Vessel_Age",
    "Length_Beam_Ratio",
    "DWT_GT_ratio",
    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",
    "Sea_Time_Utilization"
]

TARGET = "Fuel_Consumption_t"

X = df[features].copy()
y = df[TARGET].copy()


print("\nNumber of features:")
print(len(features))

print("\nTarget:")
print(TARGET)


# ============================================================
# 4. FEATURE TYPES
# ============================================================

categorical_features = [
    "Ship_Type"
]

numerical_features = [
    feature
    for feature in features
    if feature not in categorical_features
]


# ============================================================
# 5. PREPROCESSING
# ============================================================

numerical_pipeline = Pipeline([
    (
        "imputer",
        SimpleImputer(
            strategy="median",
            add_indicator=True
        )
    )
])


categorical_pipeline = Pipeline([
    (
        "imputer",
        SimpleImputer(
            strategy="most_frequent"
        )
    ),
    (
        "onehot",
        OneHotEncoder(
            handle_unknown="ignore"
        )
    )
])


preprocessor = ColumnTransformer(
    transformers=[
        (
            "numerical",
            numerical_pipeline,
            numerical_features
        ),
        (
            "categorical",
            categorical_pipeline,
            categorical_features
        )
    ]
)


# ============================================================
# 6. BASE XGBOOST MODEL
# ============================================================

xgb_model = XGBRegressor(
    objective="reg:squarederror",
    random_state=42,
    n_jobs=-1
)


pipeline = Pipeline([
    ("preprocessor", preprocessor),
    ("model", xgb_model)
])


# ============================================================
# 7. HYPERPARAMETER SEARCH SPACE
# ============================================================

param_distributions = {

    "model__n_estimators": [
        300,
        400,
        500,
        600,
        800,
        1000
    ],

    "model__learning_rate": [
        0.01,
        0.03,
        0.05,
        0.07,
        0.10
    ],

    "model__max_depth": [
        3,
        4,
        5,
        6,
        7,
        8
    ],

    "model__min_child_weight": [
        1,
        3,
        5,
        7
    ],

    "model__subsample": [
        0.70,
        0.80,
        0.85,
        0.90,
        1.00
    ],

    "model__colsample_bytree": [
        0.70,
        0.80,
        0.85,
        0.90,
        1.00
    ],

    "model__gamma": [
        0,
        0.1,
        0.2,
        0.3
    ]
}


# ============================================================
# 8. CROSS-VALIDATION
# ============================================================

cv = KFold(
    n_splits=5,
    shuffle=True,
    random_state=42
)


# ============================================================
# 9. RANDOMIZED SEARCH
# ============================================================

print("\n")
print("=" * 80)
print("STARTING RANDOMIZED SEARCH")
print("=" * 80)

print("\nRandomized search configuration:")
print("Iterations : 30")
print("CV folds   : 5")
print("Total fits : 150")


search = RandomizedSearchCV(
    estimator=pipeline,
    param_distributions=param_distributions,
    n_iter=30,
    scoring="neg_root_mean_squared_error",
    cv=cv,
    verbose=2,
    random_state=42,
    n_jobs=-1,
    return_train_score=False
)


search.fit(X, y)


# ============================================================
# 10. BEST PARAMETERS
# ============================================================

print("\n")
print("=" * 80)
print("BEST HYPERPARAMETERS")
print("=" * 80)

for parameter, value in search.best_params_.items():
    print(f"{parameter}: {value}")


# ============================================================
# 11. BEST CV SCORE
# ============================================================

best_rmse = -search.best_score_

print("\nBest Cross-Validation RMSE:")
print(f"{best_rmse:.2f} t")


# ============================================================
# 12. EVALUATE TOP MODELS
# ============================================================

cv_results = pd.DataFrame(search.cv_results_)

cv_results["RMSE_t"] = -cv_results["mean_test_score"]

cv_results = cv_results.sort_values(
    "RMSE_t",
    ascending=True
)


print("\n")
print("=" * 80)
print("TOP 10 TUNING RESULTS")
print("=" * 80)

columns_to_show = [
    "rank_test_score",
    "RMSE_t",
    "param_model__n_estimators",
    "param_model__learning_rate",
    "param_model__max_depth",
    "param_model__min_child_weight",
    "param_model__subsample",
    "param_model__colsample_bytree",
    "param_model__gamma"
]

print(
    cv_results[columns_to_show]
    .head(10)
    .to_string(index=False)
)


# ============================================================
# 13. SAVE SEARCH RESULTS
# ============================================================

results_path = os.path.join(
    REPORT_DIR,
    "xgboost_tuning_results.csv"
)

cv_results.to_csv(
    results_path,
    index=False
)


# ============================================================
# 14. SAVE BEST MODEL
# ============================================================

model_path = os.path.join(
    MODEL_DIR,
    "final_operational_xgboost_tuned.joblib"
)

joblib.dump(
    search.best_estimator_,
    model_path
)


# ============================================================
# 15. SAVE BEST PARAMETERS
# ============================================================

best_parameters_df = pd.DataFrame(
    list(search.best_params_.items()),
    columns=["Parameter", "Value"]
)

parameters_path = os.path.join(
    REPORT_DIR,
    "best_xgboost_parameters.csv"
)

best_parameters_df.to_csv(
    parameters_path,
    index=False
)


# ============================================================
# 16. COMPLETION
# ============================================================

print("\n")
print("=" * 80)
print("HYPERPARAMETER TUNING COMPLETED")
print("=" * 80)

print("\nBest RMSE:")
print(f"{best_rmse:.2f} t")

print("\nBest model saved:")
print(model_path)

print("\nTuning results saved:")
print(results_path)

print("\nBest parameters saved:")
print(parameters_path)

print("=" * 80)