import pandas as pd
import numpy as np
import os

from sklearn.model_selection import KFold, cross_validate
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from xgboost import XGBRegressor


# ============================================================
# CARBON CII PROJECT - FEATURE ABLATION STUDY
# ============================================================

print("=" * 80)
print("CARBON CII PROJECT - FEATURE ABLATION STUDY")
print("=" * 80)


# ============================================================
# 1. LOAD DATA
# ============================================================

INPUT_PATH = "data/processed/MRV_2023_feature_engineered.csv"
OUTPUT_PATH = "outputs/reports/feature_ablation_results.csv"

os.makedirs("outputs/reports", exist_ok=True)

df = pd.read_csv(INPUT_PATH)

print("\nDataset shape:")
print(df.shape)


# ============================================================
# 2. TARGET
# ============================================================

TARGET = "Fuel_Consumption_t"

y = df[TARGET].copy()


# ============================================================
# 3. FEATURE GROUPS
# ============================================================

# ------------------------------------------------------------
# Model A: Vessel characteristics only
# ------------------------------------------------------------

vessel_features = [
    "Ship_Type",
    "GT",
    "DWT",
    "Length_m",
    "Beam_m",
    "Draft_m",
    "Vessel_Age",
    "Length_Beam_Ratio",
    "DWT_GT_ratio"
]


# ------------------------------------------------------------
# Model B: Vessel + Distance
# ------------------------------------------------------------

vessel_distance_features = vessel_features + [
    "Distance_nm"
]


# ------------------------------------------------------------
# Model C: Vessel + Distance + Time
# ------------------------------------------------------------

vessel_distance_time_features = vessel_distance_features + [
    "Time_At_Sea_h"
]


# ------------------------------------------------------------
# Model D: Full operational model
# ------------------------------------------------------------

full_operational_features = vessel_distance_time_features + [
    "Average_Speed_kn",
    "Sea_Time_Utilization"
]


experiments = {
    "A_Vessel_Only": vessel_features,
    "B_Vessel_Plus_Distance": vessel_distance_features,
    "C_Vessel_Distance_Time": vessel_distance_time_features,
    "D_Full_Operational": full_operational_features
}


# ============================================================
# 4. XGBOOST MODEL
# ============================================================

def create_model(features):

    categorical_features = [
        feature
        for feature in features
        if feature == "Ship_Type"
    ]

    numerical_features = [
        feature
        for feature in features
        if feature != "Ship_Type"
    ]

    numerical_pipeline = Pipeline([
        (
            "imputer",
            SimpleImputer(
                strategy="median",
                add_indicator=True
            )
        )
    ])

    categorical_pipeline = Pipeline([
        (
            "imputer",
            SimpleImputer(
                strategy="most_frequent"
            )
        ),
        (
            "onehot",
            OneHotEncoder(
                handle_unknown="ignore"
            )
        )
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            (
                "numerical",
                numerical_pipeline,
                numerical_features
            ),
            (
                "categorical",
                categorical_pipeline,
                categorical_features
            )
        ]
    )

    model = XGBRegressor(
        n_estimators=500,
        learning_rate=0.05,
        max_depth=5,
        subsample=0.85,
        colsample_bytree=0.85,
        objective="reg:squarederror",
        random_state=42,
        n_jobs=-1
    )

    pipeline = Pipeline([
        ("preprocessor", preprocessor),
        ("model", model)
    ])

    return pipeline


# ============================================================
# 5. CROSS-VALIDATION
# ============================================================

cv = KFold(
    n_splits=5,
    shuffle=True,
    random_state=42
)


scoring = {
    "R2": "r2",
    "MAE": "neg_mean_absolute_error",
    "RMSE": "neg_root_mean_squared_error"
}


# ============================================================
# 6. RUN ABLATION EXPERIMENTS
# ============================================================

results = []


for experiment_name, features in experiments.items():

    print("\n" + "-" * 80)
    print(experiment_name)
    print("-" * 80)

    print("Features:")
    for feature in features:
        print("  -", feature)

    X = df[features].copy()

    pipeline = create_model(features)

    scores = cross_validate(
        pipeline,
        X,
        y,
        cv=cv,
        scoring=scoring,
        n_jobs=-1
    )

    mean_r2 = scores["test_R2"].mean()
    std_r2 = scores["test_R2"].std()

    mean_mae = -scores["test_MAE"].mean()
    std_mae = scores["test_MAE"].std()

    mean_rmse = -scores["test_RMSE"].mean()
    std_rmse = scores["test_RMSE"].std()

    print(f"\nR²   : {mean_r2:.4f} ± {std_r2:.4f}")
    print(f"MAE  : {mean_mae:.2f} ± {std_mae:.2f} t")
    print(f"RMSE : {mean_rmse:.2f} ± {std_rmse:.2f} t")

    results.append({
        "Experiment": experiment_name,
        "Number_of_Features": len(features),
        "R2_Mean": mean_r2,
        "R2_STD": std_r2,
        "MAE_Mean_t": mean_mae,
        "MAE_STD_t": std_mae,
        "RMSE_Mean_t": mean_rmse,
        "RMSE_STD_t": std_rmse
    })


# ============================================================
# 7. RESULTS TABLE
# ============================================================

results_df = pd.DataFrame(results)

print("\n")
print("=" * 80)
print("FEATURE ABLATION RESULTS")
print("=" * 80)

print(
    results_df.to_string(
        index=False,
        float_format=lambda x: f"{x:.4f}"
    )
)


# ============================================================
# 8. IMPROVEMENT BETWEEN EXPERIMENTS
# ============================================================

print("\n")
print("=" * 80)
print("PERFORMANCE IMPROVEMENT")
print("=" * 80)

baseline_r2 = results_df.loc[
    results_df["Experiment"] == "A_Vessel_Only",
    "R2_Mean"
].iloc[0]

baseline_mae = results_df.loc[
    results_df["Experiment"] == "A_Vessel_Only",
    "MAE_Mean_t"
].iloc[0]


for _, row in results_df.iterrows():

    r2_change = row["R2_Mean"] - baseline_r2

    mae_reduction = baseline_mae - row["MAE_Mean_t"]

    print(f"\n{row['Experiment']}")

    print(
        f"  R² improvement from vessel-only: "
        f"{r2_change:+.4f}"
    )

    print(
        f"  MAE reduction from vessel-only: "
        f"{mae_reduction:+.2f} t"
    )


# ============================================================
# 9. SAVE RESULTS
# ============================================================

results_df.to_csv(
    OUTPUT_PATH,
    index=False
)

print("\n")
print("=" * 80)
print("ABLATION STUDY COMPLETED")
print("=" * 80)

print("\nResults saved:")
print(OUTPUT_PATH)