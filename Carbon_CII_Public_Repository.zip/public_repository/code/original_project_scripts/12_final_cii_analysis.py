import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# ============================================================
# CARBON CII PROJECT
# STEP 12 - FINAL IMO CII FLEET ANALYSIS
# ============================================================
#
# Input:
#   outputs/reports/imo_cii_2023_calculations.csv
#
# Outputs:
#   Fleet rating distribution
#   Ship-type CII analysis
#   D/E analysis
#   Best/worst vessel reports
#   CII charts
#   Summary report
#
# IMPORTANT:
# This step analyzes the deterministic CII calculations from
# Step 11.
#
# It does NOT replace regulatory CII with ML predictions.
# ============================================================


print("=" * 90)
print("CARBON CII PROJECT - STEP 12")
print("FINAL IMO CII FLEET ANALYSIS")
print("=" * 90)


# ============================================================
# 1. PATHS
# ============================================================

INPUT_PATH = (
    "outputs/reports/imo_cii_2023_calculations.csv"
)

REPORT_DIR = "outputs/reports"
FIGURE_DIR = "outputs/figures"


os.makedirs(
    REPORT_DIR,
    exist_ok=True
)

os.makedirs(
    FIGURE_DIR,
    exist_ok=True
)


# ============================================================
# 2. LOAD STEP 11 DATA
# ============================================================

df = pd.read_csv(
    INPUT_PATH
)


print("\nDataset shape:")
print(df.shape)


# ============================================================
# 3. BASIC VALIDATION
# ============================================================

required_columns = [
    "IMO",
    "Ship_Name",
    "Ship_Type",
    "GT",
    "DWT",
    "Distance_nm",
    "CO2_Emissions_t",
    "Attained_CII",
    "Reference_CII",
    "Required_CII",
    "CII_Ratio",
    "CII_Rating",
    "CII_Applicable",
    "CII_Status"
]


missing_columns = [
    col
    for col in required_columns
    if col not in df.columns
]


if missing_columns:

    raise ValueError(
        "Missing required columns:\n"
        + "\n".join(missing_columns)
    )


# ============================================================
# 4. DEFINE RATING GROUPS
# ============================================================

rating_order = [
    "A",
    "B",
    "C",
    "D",
    "E"
]


ae_mask = (
    df["CII_Rating"].isin(
        rating_order
    )
)


de_mask = (
    df["CII_Rating"].isin(
        ["D", "E"]
    )
)


low_activity_mask = (
    df["CII_Rating"]
    == "Review - Low Activity"
)


# ============================================================
# 5. BASIC FLEET STATISTICS
# ============================================================

total_vessels = len(df)

cii_applicable = int(
    df["CII_Applicable"].sum()
)

valid_cii = int(
    df["CII_Valid"].sum()
)

ae_count = int(
    ae_mask.sum()
)

low_activity_count = int(
    low_activity_mask.sum()
)

unsupported_count = int(
    (
        df["CII_Status"]
        == "Unsupported ship type"
    ).sum()
)


print("\n")
print("=" * 90)
print("FLEET OVERVIEW")
print("=" * 90)

print(
    f"Total vessels:              {total_vessels:,}"
)

print(
    f"CII applicable:             {cii_applicable:,}"
)

print(
    f"Valid CII calculations:     {valid_cii:,}"
)

print(
    f"A-E rated vessels:          {ae_count:,}"
)

print(
    f"Low activity review:        {low_activity_count:,}"
)

print(
    f"Unsupported ship type:      {unsupported_count:,}"
)


# ============================================================
# 6. A-E RATING DISTRIBUTION
# ============================================================

rating_counts = (
    df.loc[
        ae_mask,
        "CII_Rating"
    ]
    .value_counts()
    .reindex(
        rating_order,
        fill_value=0
    )
)


rating_percentages = (
    rating_counts
    / rating_counts.sum()
    * 100
)


rating_distribution = pd.DataFrame({
    "Rating": rating_order,
    "Vessel_Count": [
        rating_counts[x]
        for x in rating_order
    ],
    "Percentage": [
        rating_percentages[x]
        for x in rating_order
    ]
})


rating_distribution[
    "Percentage"
] = rating_distribution[
    "Percentage"
].round(2)


print("\n")
print("=" * 90)
print("A-E RATING DISTRIBUTION")
print("=" * 90)

print(
    rating_distribution.to_string(
        index=False
    )
)


rating_distribution.to_csv(
    os.path.join(
        REPORT_DIR,
        "cii_rating_distribution.csv"
    ),
    index=False
)


# ============================================================
# 7. D + E ANALYSIS
# ============================================================

de_count = int(
    de_mask.sum()
)


de_percentage = (
    de_count
    /
    ae_count
    *
    100
)


print("\n")
print("=" * 90)
print("D + E PERFORMANCE")
print("=" * 90)

print(
    f"D-rated vessels:            "
    f"{int(rating_counts['D']):,}"
)

print(
    f"E-rated vessels:            "
    f"{int(rating_counts['E']):,}"
)

print(
    f"D + E vessels:              "
    f"{de_count:,}"
)

print(
    f"D + E percentage:           "
    f"{de_percentage:.2f}%"
)


# ============================================================
# 8. CII STATISTICS
# ============================================================

valid_ae = df.loc[
    ae_mask
].copy()


cii_statistics = pd.DataFrame({
    "Metric": [
        "Attained CII mean",
        "Attained CII median",
        "Attained CII minimum",
        "Attained CII maximum",
        "Required CII mean",
        "Required CII median",
        "CII ratio mean",
        "CII ratio median",
        "CII ratio minimum",
        "CII ratio maximum"
    ],

    "Value": [

        valid_ae["Attained_CII"].mean(),

        valid_ae["Attained_CII"].median(),

        valid_ae["Attained_CII"].min(),

        valid_ae["Attained_CII"].max(),

        valid_ae["Required_CII"].mean(),

        valid_ae["Required_CII"].median(),

        valid_ae["CII_Ratio"].mean(),

        valid_ae["CII_Ratio"].median(),

        valid_ae["CII_Ratio"].min(),

        valid_ae["CII_Ratio"].max()
    ]
})


print("\n")
print("=" * 90)
print("CII STATISTICS")
print("=" * 90)

print(
    cii_statistics.to_string(
        index=False
    )
)


cii_statistics.to_csv(
    os.path.join(
        REPORT_DIR,
        "cii_overall_statistics.csv"
    ),
    index=False
)


# ============================================================
# 9. SHIP-TYPE ANALYSIS
# ============================================================

ship_type_summary = (
    valid_ae
    .groupby(
        "Ship_Type"
    )
    .agg(
        Vessel_Count=(
            "IMO",
            "count"
        ),

        Mean_Attained_CII=(
            "Attained_CII",
            "mean"
        ),

        Median_Attained_CII=(
            "Attained_CII",
            "median"
        ),

        Mean_Required_CII=(
            "Required_CII",
            "mean"
        ),

        Mean_CII_Ratio=(
            "CII_Ratio",
            "mean"
        ),

        Median_CII_Ratio=(
            "CII_Ratio",
            "median"
        )
    )
    .reset_index()
)


# ============================================================
# 10. ADD RATING COUNTS BY SHIP TYPE
# ============================================================

for rating in rating_order:

    rating_count_by_type = (
        valid_ae[
            valid_ae["CII_Rating"] == rating
        ]
        .groupby(
            "Ship_Type"
        )
        .size()
    )

    ship_type_summary[
        f"Rating_{rating}"
    ] = (
        ship_type_summary[
            "Ship_Type"
        ]
        .map(
            rating_count_by_type
        )
        .fillna(0)
        .astype(int)
    )


# ============================================================
# 11. D/E COUNT AND PERCENTAGE BY SHIP TYPE
# ============================================================

de_by_type = (
    valid_ae[
        valid_ae["CII_Rating"].isin(
            ["D", "E"]
        )
    ]
    .groupby(
        "Ship_Type"
    )
    .size()
)


ship_type_summary[
    "D_E_Count"
] = (
    ship_type_summary[
        "Ship_Type"
    ]
    .map(
        de_by_type
    )
    .fillna(0)
    .astype(int)
)


ship_type_summary[
    "D_E_Percentage"
] = (
    ship_type_summary["D_E_Count"]
    /
    ship_type_summary["Vessel_Count"]
    *
    100
)


# ============================================================
# 12. A RATING PERCENTAGE BY SHIP TYPE
# ============================================================

ship_type_summary[
    "A_Percentage"
] = (
    ship_type_summary["Rating_A"]
    /
    ship_type_summary["Vessel_Count"]
    *
    100
)


ship_type_summary[
    "B_Percentage"
] = (
    ship_type_summary["Rating_B"]
    /
    ship_type_summary["Vessel_Count"]
    *
    100
)


ship_type_summary[
    "C_Percentage"
] = (
    ship_type_summary["Rating_C"]
    /
    ship_type_summary["Vessel_Count"]
    *
    100
)


ship_type_summary[
    "D_Percentage"
] = (
    ship_type_summary["Rating_D"]
    /
    ship_type_summary["Vessel_Count"]
    *
    100
)


ship_type_summary[
    "E_Percentage"
] = (
    ship_type_summary["Rating_E"]
    /
    ship_type_summary["Vessel_Count"]
    *
    100
)


# ============================================================
# 13. ROUND RESULTS
# ============================================================

percentage_columns = [
    "D_E_Percentage",
    "A_Percentage",
    "B_Percentage",
    "C_Percentage",
    "D_Percentage",
    "E_Percentage"
]


for col in percentage_columns:

    ship_type_summary[col] = (
        ship_type_summary[col]
        .round(2)
    )


for col in [
    "Mean_Attained_CII",
    "Median_Attained_CII",
    "Mean_Required_CII",
    "Mean_CII_Ratio",
    "Median_CII_Ratio"
]:

    ship_type_summary[col] = (
        ship_type_summary[col]
        .round(4)
    )


# ============================================================
# 14. SORT BY D/E PERCENTAGE
# ============================================================

ship_type_summary = (
    ship_type_summary
    .sort_values(
        "D_E_Percentage",
        ascending=False
    )
)


print("\n")
print("=" * 90)
print("SHIP-TYPE CII PERFORMANCE")
print("=" * 90)

print(
    ship_type_summary.to_string(
        index=False
    )
)


ship_type_summary.to_csv(
    os.path.join(
        REPORT_DIR,
        "cii_ship_type_analysis.csv"
    ),
    index=False
)


# ============================================================
# 15. WORST 20 VESSELS
# ============================================================

worst_20 = (
    valid_ae[
        [
            "IMO",
            "Ship_Name",
            "Ship_Type",
            "GT",
            "DWT",
            "Distance_nm",
            "CO2_Emissions_t",
            "Attained_CII",
            "Reference_CII",
            "Required_CII",
            "CII_Ratio",
            "CII_Rating"
        ]
    ]
    .sort_values(
        "CII_Ratio",
        ascending=False
    )
    .head(20)
)


print("\n")
print("=" * 90)
print("TOP 20 WORST CII PERFORMERS")
print("=" * 90)

print(
    worst_20.to_string(
        index=False
    )
)


worst_20.to_csv(
    os.path.join(
        REPORT_DIR,
        "cii_worst_20_vessels.csv"
    ),
    index=False
)


# ============================================================
# 16. BEST 20 VESSELS
# ============================================================

best_20 = (
    valid_ae[
        [
            "IMO",
            "Ship_Name",
            "Ship_Type",
            "GT",
            "DWT",
            "Distance_nm",
            "CO2_Emissions_t",
            "Attained_CII",
            "Reference_CII",
            "Required_CII",
            "CII_Ratio",
            "CII_Rating"
        ]
    ]
    .sort_values(
        "CII_Ratio",
        ascending=True
    )
    .head(20)
)


print("\n")
print("=" * 90)
print("TOP 20 BEST CII PERFORMERS")
print("=" * 90)

print(
    best_20.to_string(
        index=False
    )
)


best_20.to_csv(
    os.path.join(
        REPORT_DIR,
        "cii_best_20_vessels.csv"
    ),
    index=False
)


# ============================================================
# 17. E-RATED VESSELS
# ============================================================

e_vessels = (
    valid_ae[
        valid_ae["CII_Rating"] == "E"
    ]
    [
        [
            "IMO",
            "Ship_Name",
            "Ship_Type",
            "GT",
            "DWT",
            "Distance_nm",
            "CO2_Emissions_t",
            "Attained_CII",
            "Required_CII",
            "CII_Ratio"
        ]
    ]
    .sort_values(
        "CII_Ratio",
        ascending=False
    )
)


print("\n")
print("=" * 90)
print("E-RATED VESSELS")
print("=" * 90)

print(
    f"Number of E-rated vessels: "
    f"{len(e_vessels):,}"
)


e_vessels.to_csv(
    os.path.join(
        REPORT_DIR,
        "cii_e_rated_vessels.csv"
    ),
    index=False
)


# ============================================================
# 18. D-RATED VESSELS
# ============================================================

d_vessels = (
    valid_ae[
        valid_ae["CII_Rating"] == "D"
    ]
    [
        [
            "IMO",
            "Ship_Name",
            "Ship_Type",
            "GT",
            "DWT",
            "Distance_nm",
            "CO2_Emissions_t",
            "Attained_CII",
            "Required_CII",
            "CII_Ratio"
        ]
    ]
    .sort_values(
        "CII_Ratio",
        ascending=False
    )
)


d_vessels.to_csv(
    os.path.join(
        REPORT_DIR,
        "cii_d_rated_vessels.csv"
    ),
    index=False
)


# ============================================================
# 19. LOW-ACTIVITY VESSELS
# ============================================================

low_activity = (
    df[
        df["CII_Rating"]
        == "Review - Low Activity"
    ]
    [
        [
            "IMO",
            "Ship_Name",
            "Ship_Type",
            "GT",
            "DWT",
            "Distance_nm",
            "CO2_Emissions_t",
            "Attained_CII",
            "Required_CII",
            "CII_Ratio"
        ]
    ]
    .sort_values(
        "Distance_nm"
    )
)


low_activity.to_csv(
    os.path.join(
        REPORT_DIR,
        "cii_low_activity_vessels.csv"
    ),
    index=False
)


# ============================================================
# 20. UNSUPPORTED VESSELS
# ============================================================

unsupported = (
    df[
        df["CII_Status"]
        == "Unsupported ship type"
    ]
    [
        [
            "IMO",
            "Ship_Name",
            "Ship_Type",
            "GT",
            "DWT"
        ]
    ]
)


unsupported.to_csv(
    os.path.join(
        REPORT_DIR,
        "cii_unsupported_vessels.csv"
    ),
    index=False
)


# ============================================================
# 21. FIGURE 1
# A-E RATING DISTRIBUTION
# ============================================================

plt.figure(
    figsize=(9, 6)
)


plt.bar(
    rating_distribution["Rating"],
    rating_distribution["Vessel_Count"]
)


plt.title(
    "2023 IMO CII Rating Distribution"
)

plt.xlabel(
    "CII Rating"
)

plt.ylabel(
    "Number of Vessels"
)


plt.tight_layout()


plt.savefig(
    os.path.join(
        FIGURE_DIR,
        "cii_rating_distribution.png"
    ),
    dpi=300
)


plt.close()


# ============================================================
# 22. FIGURE 2
# A-E RATING PERCENTAGE
# ============================================================

plt.figure(
    figsize=(9, 6)
)


plt.bar(
    rating_distribution["Rating"],
    rating_distribution["Percentage"]
)


plt.title(
    "2023 IMO CII Rating Percentage"
)

plt.xlabel(
    "CII Rating"
)

plt.ylabel(
    "Percentage of Rated Vessels (%)"
)


plt.tight_layout()


plt.savefig(
    os.path.join(
        FIGURE_DIR,
        "cii_rating_percentage.png"
    ),
    dpi=300
)


plt.close()


# ============================================================
# 23. FIGURE 3
# SHIP-TYPE D/E PERCENTAGE
# ============================================================

plot_ship_types = (
    ship_type_summary
    .sort_values(
        "D_E_Percentage",
        ascending=False
    )
)


plt.figure(
    figsize=(12, 7)
)


plt.bar(
    plot_ship_types["Ship_Type"],
    plot_ship_types["D_E_Percentage"]
)


plt.title(
    "D/E CII Percentage by Ship Type"
)

plt.xlabel(
    "Ship Type"
)

plt.ylabel(
    "D/E Vessels (%)"
)


plt.xticks(
    rotation=60,
    ha="right"
)


plt.tight_layout()


plt.savefig(
    os.path.join(
        FIGURE_DIR,
        "cii_de_percentage_by_ship_type.png"
    ),
    dpi=300
)


plt.close()


# ============================================================
# 24. FIGURE 4
# CII RATIO DISTRIBUTION
# ============================================================

plt.figure(
    figsize=(10, 6)
)


plt.hist(
    valid_ae["CII_Ratio"],
    bins=50
)


plt.axvline(
    1.0,
    linestyle="--",
    linewidth=2
)


plt.title(
    "Distribution of CII Ratio"
)

plt.xlabel(
    "Attained CII / Required CII"
)

plt.ylabel(
    "Number of Vessels"
)


plt.tight_layout()


plt.savefig(
    os.path.join(
        FIGURE_DIR,
        "cii_ratio_distribution.png"
    ),
    dpi=300
)


plt.close()


# ============================================================
# 25. FIGURE 5
# ATTAINED VS REQUIRED CII
# ============================================================

plt.figure(
    figsize=(9, 7)
)


plt.scatter(
    valid_ae["Required_CII"],
    valid_ae["Attained_CII"],
    alpha=0.5
)


max_value = max(
    valid_ae["Required_CII"].max(),
    valid_ae["Attained_CII"].max()
)


plt.plot(
    [0, max_value],
    [0, max_value],
    linestyle="--",
    linewidth=2
)


plt.title(
    "Attained CII vs Required CII"
)

plt.xlabel(
    "Required CII"
)

plt.ylabel(
    "Attained CII"
)


plt.tight_layout()


plt.savefig(
    os.path.join(
        FIGURE_DIR,
        "attained_vs_required_cii.png"
    ),
    dpi=300
)


plt.close()


# ============================================================
# 26. FIGURE 6
# WORST 20 CII RATIO
# ============================================================

worst_plot = (
    worst_20
    .sort_values(
        "CII_Ratio",
        ascending=True
    )
)


plt.figure(
    figsize=(11, 8)
)


plt.barh(
    worst_plot["Ship_Name"],
    worst_plot["CII_Ratio"]
)


plt.axvline(
    1.0,
    linestyle="--",
    linewidth=2
)


plt.title(
    "Top 20 Worst CII Performers"
)

plt.xlabel(
    "CII Ratio"
)

plt.ylabel(
    "Vessel"
)


plt.tight_layout()


plt.savefig(
    os.path.join(
        FIGURE_DIR,
        "top_20_worst_cii.png"
    ),
    dpi=300
)


plt.close()


# ============================================================
# 27. FIGURE 7
# SHIP-TYPE MEAN CII RATIO
# ============================================================

mean_ratio_plot = (
    ship_type_summary
    .sort_values(
        "Mean_CII_Ratio",
        ascending=False
    )
)


plt.figure(
    figsize=(12, 7)
)


plt.bar(
    mean_ratio_plot["Ship_Type"],
    mean_ratio_plot["Mean_CII_Ratio"]
)


plt.axhline(
    1.0,
    linestyle="--",
    linewidth=2
)


plt.title(
    "Mean CII Ratio by Ship Type"
)

plt.xlabel(
    "Ship Type"
)

plt.ylabel(
    "Mean CII Ratio"
)


plt.xticks(
    rotation=60,
    ha="right"
)


plt.tight_layout()


plt.savefig(
    os.path.join(
        FIGURE_DIR,
        "mean_cii_ratio_by_ship_type.png"
    ),
    dpi=300
)


plt.close()


# ============================================================
# 28. FLEET SUMMARY DATASET
# ============================================================

fleet_summary = pd.DataFrame({

    "Metric": [

        "Total vessels",

        "CII applicable vessels",

        "Valid CII calculations",

        "A-E rated vessels",

        "A-rated vessels",

        "B-rated vessels",

        "C-rated vessels",

        "D-rated vessels",

        "E-rated vessels",

        "D+E vessels",

        "D+E percentage",

        "Low activity review vessels",

        "Unsupported ship-type vessels",

        "Z reduction factor (%)"
    ],

    "Value": [

        total_vessels,

        cii_applicable,

        valid_cii,

        ae_count,

        int(rating_counts["A"]),

        int(rating_counts["B"]),

        int(rating_counts["C"]),

        int(rating_counts["D"]),

        int(rating_counts["E"]),

        de_count,

        round(
            de_percentage,
            2
        ),

        low_activity_count,

        unsupported_count,

        Z if "Z" in globals() else 5.0
    ]
})


fleet_summary.to_csv(
    os.path.join(
        REPORT_DIR,
        "cii_fleet_summary.csv"
    ),
    index=False
)


# ============================================================
# 29. PRINT FINAL EXECUTIVE SUMMARY
# ============================================================

print("\n")
print("=" * 90)
print("FINAL STEP 12 EXECUTIVE SUMMARY")
print("=" * 90)


print(
    f"\nTotal vessels analyzed: "
    f"{total_vessels:,}"
)


print(
    f"CII applicable: "
    f"{cii_applicable:,}"
)


print(
    f"A-E rated: "
    f"{ae_count:,}"
)


print(
    f"\nRating distribution:"
)


for rating in rating_order:

    print(
        f"  {rating}: "
        f"{int(rating_counts[rating]):,} "
        f"("
        f"{rating_percentages[rating]:.2f}%"
        f")"
    )


print(
    f"\nD + E vessels: "
    f"{de_count:,}"
)


print(
    f"D + E percentage: "
    f"{de_percentage:.2f}%"
)


print(
    f"\nLow activity reviews: "
    f"{low_activity_count:,}"
)


print(
    f"Unsupported ship types: "
    f"{unsupported_count:,}"
)


# ============================================================
# 30. OUTPUT FILE LIST
# ============================================================

print("\n")
print("=" * 90)
print("STEP 12 OUTPUT FILES")
print("=" * 90)


output_files = [

    "cii_rating_distribution.csv",

    "cii_overall_statistics.csv",

    "cii_ship_type_analysis.csv",

    "cii_worst_20_vessels.csv",

    "cii_best_20_vessels.csv",

    "cii_e_rated_vessels.csv",

    "cii_d_rated_vessels.csv",

    "cii_low_activity_vessels.csv",

    "cii_unsupported_vessels.csv",

    "cii_fleet_summary.csv"
]


for filename in output_files:

    print(
        os.path.join(
            REPORT_DIR,
            filename
        )
    )


print("\n")
print("Figures saved to:")


figure_files = [

    "cii_rating_distribution.png",

    "cii_rating_percentage.png",

    "cii_de_percentage_by_ship_type.png",

    "cii_ratio_distribution.png",

    "attained_vs_required_cii.png",

    "top_20_worst_cii.png",

    "mean_cii_ratio_by_ship_type.png"
]


for filename in figure_files:

    print(
        os.path.join(
            FIGURE_DIR,
            filename
        )
    )


print("\n")
print("=" * 90)
print("STEP 12 COMPLETED SUCCESSFULLY")
print("=" * 90)