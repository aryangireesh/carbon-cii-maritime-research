# ============================================================
# STEP 14 — VISUALIZATION & FINAL ANALYTICAL REPORTING
# ============================================================
#
# Purpose:
# Create final analytical charts and summary tables from
# Step 13 ML + IMO CII integrated scenario analysis.
#
# Input:
#   Step 13 integrated scenario results
#   Step 13 summary
#   Step 13 transition matrix
#   Step 13 ship-type analysis
#
# Output:
#   outputs/figures/
#   outputs/reports/
#
# ============================================================

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# ============================================================
# PROJECT PATHS
# ============================================================

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

REPORT_DIR = os.path.join(
    BASE_DIR,
    "outputs",
    "reports"
)

FIGURE_DIR = os.path.join(
    BASE_DIR,
    "outputs",
    "figures"
)

os.makedirs(
    REPORT_DIR,
    exist_ok=True
)

os.makedirs(
    FIGURE_DIR,
    exist_ok=True
)


# ============================================================
# INPUT FILES
# ============================================================

INTEGRATED_FILE = os.path.join(
    REPORT_DIR,
    "ml_cii_integrated_scenario_results.csv"
)

SUMMARY_FILE = os.path.join(
    REPORT_DIR,
    "ml_cii_scenario_summary.csv"
)

TRANSITION_FILE = os.path.join(
    REPORT_DIR,
    "ml_cii_rating_transition_matrix.csv"
)

SHIP_TYPE_FILE = os.path.join(
    REPORT_DIR,
    "ml_cii_ship_type_scenario_analysis.csv"
)

WORST_FILE = os.path.join(
    REPORT_DIR,
    "ml_cii_worst_scenario_changes.csv"
)

BEST_FILE = os.path.join(
    REPORT_DIR,
    "ml_cii_best_scenario_changes.csv"
)

DE_FILE = os.path.join(
    REPORT_DIR,
    "ml_cii_de_scenario_analysis.csv"
)


# ============================================================
# HEADER
# ============================================================

print("=" * 85)
print("STEP 14 — VISUALIZATION & FINAL ANALYTICAL REPORTING")
print("=" * 85)


# ============================================================
# [1/12] LOAD DATA
# ============================================================

print("\n[1/12] Loading Step 13 outputs...")


required_files = [
    INTEGRATED_FILE,
    SUMMARY_FILE,
    TRANSITION_FILE,
    SHIP_TYPE_FILE,
    WORST_FILE,
    BEST_FILE,
    DE_FILE
]


for file_path in required_files:

    if not os.path.exists(file_path):

        raise FileNotFoundError(
            f"\nRequired Step 13 file not found:\n{file_path}"
        )


integrated = pd.read_csv(
    INTEGRATED_FILE
)

summary = pd.read_csv(
    SUMMARY_FILE
)

transition = pd.read_csv(
    TRANSITION_FILE,
    index_col=0
)

ship_type = pd.read_csv(
    SHIP_TYPE_FILE
)

worst = pd.read_csv(
    WORST_FILE
)

best = pd.read_csv(
    BEST_FILE
)

de_analysis = pd.read_csv(
    DE_FILE
)


print(
    f"Integrated dataset : {integrated.shape}"
)

print(
    f"Summary            : {summary.shape}"
)

print(
    f"Transition matrix  : {transition.shape}"
)

print(
    f"Ship-type analysis : {ship_type.shape}"
)


# ============================================================
# [2/12] PREPARE DATA
# ============================================================

print("\n[2/12] Preparing visualization data...")


rating_order = [
    "A",
    "B",
    "C",
    "D",
    "E"
]


# ------------------------------------------------------------
# Baseline ratings
# ------------------------------------------------------------

baseline_rating_counts = (

    integrated[
        "CII_Rating"
    ]

    .value_counts()

    .reindex(
        rating_order,
        fill_value=0
    )

)


# ------------------------------------------------------------
# Scenario ratings
# ------------------------------------------------------------

scenario_rating_counts = (

    integrated[
        "Scenario_CII_Rating"
    ]

    .value_counts()

    .reindex(
        rating_order,
        fill_value=0
    )

)


# ------------------------------------------------------------
# Comparable vessels
# ------------------------------------------------------------

comparable = integrated[

    integrated["CII_Rating"].isin(
        rating_order
    )

    &

    integrated["Scenario_CII_Rating"].isin(
        rating_order
    )

].copy()


print(
    f"Comparable A-E vessels: "
    f"{len(comparable):,}"
)


# ============================================================
# [3/12] FIGURE 1 — RATING DISTRIBUTION
# ============================================================

print("\n[3/12] Creating rating distribution chart...")


x = np.arange(
    len(rating_order)
)

width = 0.35


plt.figure(
    figsize=(10, 6)
)


plt.bar(
    x - width / 2,
    baseline_rating_counts.values,
    width,
    label="Baseline"
)


plt.bar(
    x + width / 2,
    scenario_rating_counts.values,
    width,
    label="ML Scenario"
)


plt.xticks(
    x,
    rating_order
)

plt.xlabel(
    "CII Rating"
)

plt.ylabel(
    "Number of Vessels"
)

plt.title(
    "Baseline vs ML Scenario IMO CII Ratings"
)

plt.legend()

plt.tight_layout()


rating_distribution_file = os.path.join(
    FIGURE_DIR,
    "step14_baseline_vs_scenario_rating_distribution.png"
)


plt.savefig(
    rating_distribution_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# [4/12] FIGURE 2 — RATING PERCENTAGES
# ============================================================

print(
    "\n[4/12] Creating rating percentage chart..."
)


comparable_baseline = (

    comparable[
        "CII_Rating"
    ]

    .value_counts()

    .reindex(
        rating_order,
        fill_value=0
    )

)


comparable_scenario = (

    comparable[
        "Scenario_CII_Rating"
    ]

    .value_counts()

    .reindex(
        rating_order,
        fill_value=0
    )

)


baseline_pct = (

    comparable_baseline

    /

    len(comparable)

) * 100


scenario_pct = (

    comparable_scenario

    /

    len(comparable)

) * 100


plt.figure(
    figsize=(10, 6)
)


plt.bar(
    x - width / 2,
    baseline_pct.values,
    width,
    label="Baseline"
)


plt.bar(
    x + width / 2,
    scenario_pct.values,
    width,
    label="ML Scenario"
)


plt.xticks(
    x,
    rating_order
)

plt.xlabel(
    "CII Rating"
)

plt.ylabel(
    "Percentage of Comparable Vessels (%)"
)

plt.title(
    "Baseline vs ML Scenario CII Rating Percentage"
)

plt.legend()

plt.tight_layout()


rating_percentage_file = os.path.join(
    FIGURE_DIR,
    "step14_baseline_vs_scenario_rating_percentage.png"
)


plt.savefig(
    rating_percentage_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# [5/12] FIGURE 3 — TRANSITION HEATMAP
# ============================================================

print(
    "\n[5/12] Creating rating transition heatmap..."
)


plt.figure(
    figsize=(8, 7)
)


plt.imshow(
    transition.values,
    aspect="auto"
)


plt.xticks(
    range(len(rating_order)),
    rating_order
)

plt.yticks(
    range(len(rating_order)),
    rating_order
)


plt.xlabel(
    "Scenario Rating"
)

plt.ylabel(
    "Baseline Rating"
)

plt.title(
    "IMO CII Rating Transition: Baseline → ML Scenario"
)


# Add cell values

for i in range(
    len(rating_order)
):

    for j in range(
        len(rating_order)
    ):

        value = transition.iloc[i, j]

        plt.text(
            j,
            i,
            f"{int(value)}",
            ha="center",
            va="center"
        )


plt.colorbar(
    label="Number of Vessels"
)


plt.tight_layout()


transition_file = os.path.join(
    FIGURE_DIR,
    "step14_cii_rating_transition_heatmap.png"
)


plt.savefig(
    transition_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# [6/12] FIGURE 4 — D/E PERFORMANCE
# ============================================================

print(
    "\n[6/12] Creating D/E comparison chart..."
)


baseline_de = (

    comparable[
        "CII_Rating"
    ]

    .isin(
        [
            "D",
            "E"
        ]
    )

    .sum()

)


scenario_de = (

    comparable[
        "Scenario_CII_Rating"
    ]

    .isin(
        [
            "D",
            "E"
        ]
    )

    .sum()

)


baseline_de_pct = (
    baseline_de /
    len(comparable)
) * 100


scenario_de_pct = (
    scenario_de /
    len(comparable)
) * 100


de_values = [
    baseline_de_pct,
    scenario_de_pct
]


de_labels = [
    "Baseline",
    "ML Scenario"
]


plt.figure(
    figsize=(8, 6)
)


plt.bar(
    de_labels,
    de_values
)


plt.ylabel(
    "D/E Vessels (%)"
)

plt.title(
    "D/E IMO CII Performance Comparison"
)


for i, value in enumerate(
    de_values
):

    plt.text(
        i,
        value,
        f"{value:.2f}%",
        ha="center",
        va="bottom"
    )


plt.tight_layout()


de_file = os.path.join(
    FIGURE_DIR,
    "step14_baseline_vs_scenario_de_percentage.png"
)


plt.savefig(
    de_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# [7/12] FIGURE 5 — SHIP TYPE CII CHANGE
# ============================================================

print(
    "\n[7/12] Creating ship-type CII change chart..."
)


ship_type_plot = ship_type.copy()


ship_type_plot = (

    ship_type_plot

    .sort_values(
        "Mean_CII_Change_Percent",
        ascending=True
    )

)


plt.figure(
    figsize=(12, 8)
)


plt.barh(

    ship_type_plot[
        "IMO_CII_Category"
    ],

    ship_type_plot[
        "Mean_CII_Change_Percent"
    ]

)


plt.axvline(
    0,
    linewidth=1
)


plt.xlabel(
    "Mean CII Change (%)"
)

plt.ylabel(
    "IMO CII Ship Category"
)

plt.title(
    "Mean Scenario CII Change by Ship Category"
)

plt.tight_layout()


ship_type_change_file = os.path.join(
    FIGURE_DIR,
    "step14_ship_type_cii_change.png"
)


plt.savefig(
    ship_type_change_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# [8/12] FIGURE 6 — SHIP TYPE D/E COMPARISON
# ============================================================

print(
    "\n[8/12] Creating ship-type D/E comparison..."
)


ship_type_de = ship_type.copy()


ship_type_de = ship_type_de.sort_values(
    "Baseline_DE_Percent",
    ascending=True
)


y = np.arange(
    len(ship_type_de)
)


plt.figure(
    figsize=(12, 9)
)


plt.barh(
    y - width / 2,
    ship_type_de[
        "Baseline_DE_Percent"
    ],
    width,
    label="Baseline"
)


plt.barh(
    y + width / 2,
    ship_type_de[
        "Scenario_DE_Percent"
    ],
    width,
    label="ML Scenario"
)


plt.yticks(
    y,
    ship_type_de[
        "IMO_CII_Category"
    ]
)


plt.xlabel(
    "D/E Vessels (%)"
)

plt.ylabel(
    "IMO CII Ship Category"
)

plt.title(
    "Baseline vs ML Scenario D/E Performance by Ship Category"
)

plt.legend()

plt.tight_layout()


ship_type_de_file = os.path.join(
    FIGURE_DIR,
    "step14_ship_type_de_comparison.png"
)


plt.savefig(
    ship_type_de_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# [9/12] FIGURE 7 — OBSERVED VS SCENARIO CII
# ============================================================

print(
    "\n[9/12] Creating observed vs scenario CII chart..."
)


plot_data = comparable[
    [
        "Attained_CII",
        "Scenario_CII"
    ]
].dropna()


plt.figure(
    figsize=(8, 8)
)


plt.scatter(

    plot_data[
        "Attained_CII"
    ],

    plot_data[
        "Scenario_CII"
    ],

    alpha=0.35
)


min_value = min(

    plot_data[
        "Attained_CII"
    ].min(),

    plot_data[
        "Scenario_CII"
    ].min()

)


max_value = max(

    plot_data[
        "Attained_CII"
    ].max(),

    plot_data[
        "Scenario_CII"
    ].max()

)


plt.plot(

    [
        min_value,
        max_value
    ],

    [
        min_value,
        max_value
    ],

    linestyle="--"
)


plt.xlabel(
    "Observed Attained CII"
)

plt.ylabel(
    "ML Scenario Attained CII"
)

plt.title(
    "Observed vs ML Scenario Attained CII"
)

plt.tight_layout()


observed_scenario_file = os.path.join(
    FIGURE_DIR,
    "step14_observed_vs_scenario_cii.png"
)


plt.savefig(
    observed_scenario_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# [10/12] FIGURE 8 — WORST 20 CII CHANGES
# ============================================================

print(
    "\n[10/12] Creating worst 20 CII change chart..."
)


worst_plot = worst.copy()


worst_plot = worst_plot.sort_values(
    "CII_Change_Percent",
    ascending=True
)


if "Ship_Name" in worst_plot.columns:

    names = worst_plot[
        "Ship_Name"
    ].astype(str)

else:

    names = worst_plot[
        "IMO"
    ].astype(str)


plt.figure(
    figsize=(12, 8)
)


plt.barh(

    names,

    worst_plot[
        "CII_Change_Percent"
    ]

)


plt.xlabel(
    "CII Change (%)"
)

plt.ylabel(
    "Vessel"
)

plt.title(
    "Top 20 Vessels with Largest CII Increase"
)

plt.tight_layout()


worst_file = os.path.join(
    FIGURE_DIR,
    "step14_top20_worst_cii_changes.png"
)


plt.savefig(
    worst_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# [11/12] FIGURE 9 — BEST 20 CII CHANGES
# ============================================================

print(
    "\n[11/12] Creating best 20 CII change chart..."
)


best_plot = best.copy()


best_plot = best_plot.sort_values(
    "CII_Change_Percent",
    ascending=False
)


if "Ship_Name" in best_plot.columns:

    names = best_plot[
        "Ship_Name"
    ].astype(str)

else:

    names = best_plot[
        "IMO"
    ].astype(str)


plt.figure(
    figsize=(12, 8)
)


plt.barh(

    names,

    best_plot[
        "CII_Change_Percent"
    ]

)


plt.xlabel(
    "CII Change (%)"
)

plt.ylabel(
    "Vessel"
)

plt.title(
    "Top 20 Vessels with Largest CII Improvement"
)

plt.tight_layout()


best_file = os.path.join(
    FIGURE_DIR,
    "step14_top20_best_cii_changes.png"
)


plt.savefig(
    best_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# [12/12] FLEET SUMMARY VISUALIZATION
# ============================================================

print(
    "\n[12/12] Creating fleet fuel and CO2 charts..."
)


# ------------------------------------------------------------
# Read values from integrated dataset directly
# ------------------------------------------------------------

actual_fuel_total = pd.to_numeric(
    integrated["Actual_Fuel_t"],
    errors="coerce"
).sum()


scenario_fuel_total = pd.to_numeric(
    integrated["Scenario_Fuel_t"],
    errors="coerce"
).sum()


actual_co2_total = pd.to_numeric(
    integrated["Actual_CO2_t"],
    errors="coerce"
).sum()


scenario_co2_total = pd.to_numeric(
    integrated["Scenario_CO2_t"],
    errors="coerce"
).sum()


# ------------------------------------------------------------
# Fleet fuel
# ------------------------------------------------------------

plt.figure(
    figsize=(8, 6)
)


plt.bar(

    [
        "Actual",
        "ML Scenario"
    ],

    [
        actual_fuel_total,
        scenario_fuel_total
    ]

)


plt.ylabel(
    "Fuel Consumption (t)"
)

plt.title(
    "Fleet Fuel Consumption: Actual vs ML Scenario"
)

plt.tight_layout()


fleet_fuel_file = os.path.join(
    FIGURE_DIR,
    "step14_fleet_fuel_actual_vs_scenario.png"
)


plt.savefig(
    fleet_fuel_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ------------------------------------------------------------
# Fleet CO2
# ------------------------------------------------------------

plt.figure(
    figsize=(8, 6)
)


plt.bar(

    [
        "Actual",
        "ML Scenario"
    ],

    [
        actual_co2_total,
        scenario_co2_total
    ]

)


plt.ylabel(
    "CO₂ Emissions (t)"
)

plt.title(
    "Fleet CO₂ Emissions: Actual vs ML Scenario"
)

plt.tight_layout()


fleet_co2_file = os.path.join(
    FIGURE_DIR,
    "step14_fleet_co2_actual_vs_scenario.png"
)


plt.savefig(
    fleet_co2_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# ADDITIONAL FIGURE — CII CHANGE DISTRIBUTION
# ============================================================

print(
    "\nCreating CII change distribution..."
)


cii_change = comparable[
    "CII_Change_Percent"
].dropna()


plt.figure(
    figsize=(10, 6)
)


plt.hist(
    cii_change,
    bins=50
)


plt.axvline(
    0,
    linestyle="--"
)


plt.xlabel(
    "CII Change (%)"
)

plt.ylabel(
    "Number of Vessels"
)

plt.title(
    "Distribution of Vessel-Level CII Change"
)

plt.tight_layout()


cii_change_distribution_file = os.path.join(
    FIGURE_DIR,
    "step14_cii_change_distribution.png"
)


plt.savefig(
    cii_change_distribution_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# ADDITIONAL FIGURE — CII RATIO DISTRIBUTION
# ============================================================

print(
    "\nCreating CII ratio distribution..."
)


cii_ratio = comparable[
    "Scenario_CII_Ratio"
].dropna()


plt.figure(
    figsize=(10, 6)
)


plt.hist(
    cii_ratio,
    bins=50
)


plt.axvline(
    1,
    linestyle="--",
    label="Required CII threshold"
)


plt.xlabel(
    "Scenario CII Ratio"
)

plt.ylabel(
    "Number of Vessels"
)

plt.title(
    "Distribution of Scenario CII Ratio"
)

plt.legend()

plt.tight_layout()


cii_ratio_file = os.path.join(
    FIGURE_DIR,
    "step14_scenario_cii_ratio_distribution.png"
)


plt.savefig(
    cii_ratio_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# FINAL ANALYTICAL SUMMARY
# ============================================================

print(
    "\nCreating final analytical summary..."
)


# ------------------------------------------------------------
# Fleet-level metrics
# ------------------------------------------------------------

fuel_change = (

    (

        scenario_fuel_total

        -

        actual_fuel_total

    )

    /

    actual_fuel_total

) * 100


co2_change = (

    (

        scenario_co2_total

        -

        actual_co2_total

    )

    /

    actual_co2_total

) * 100


# ------------------------------------------------------------
# Rating changes
# ------------------------------------------------------------

improved = (

    comparable["CII_Rating"].map(
        {
            "A": 1,
            "B": 2,
            "C": 3,
            "D": 4,
            "E": 5
        }
    )

    >

    comparable[
        "Scenario_CII_Rating"
    ].map(
        {
            "A": 1,
            "B": 2,
            "C": 3,
            "D": 4,
            "E": 5
        }
    )

).sum()


# The above comparison direction is intentionally reversed
# because lower rating score = better performance.
# Recalculate explicitly.

baseline_score = comparable[
    "CII_Rating"
].map(
    {
        "A": 1,
        "B": 2,
        "C": 3,
        "D": 4,
        "E": 5
    }
)


scenario_score = comparable[
    "Scenario_CII_Rating"
].map(
    {
        "A": 1,
        "B": 2,
        "C": 3,
        "D": 4,
        "E": 5
    }
)


improved = (
    scenario_score < baseline_score
).sum()


unchanged = (
    scenario_score == baseline_score
).sum()


worsened = (
    scenario_score > baseline_score
).sum()


# ------------------------------------------------------------
# Worst and best category
# ------------------------------------------------------------

largest_increase_category = None

largest_decrease_category = None


if len(ship_type) > 0:

    largest_increase_category = (

        ship_type

        .sort_values(
            "Mean_CII_Change_Percent",
            ascending=False
        )

        .iloc[0][
            "IMO_CII_Category"
        ]

    )


    largest_decrease_category = (

        ship_type

        .sort_values(
            "Mean_CII_Change_Percent",
            ascending=True
        )

        .iloc[0][
            "IMO_CII_Category"
        ]

    )


# ------------------------------------------------------------
# Summary table
# ------------------------------------------------------------

final_summary = pd.DataFrame({

    "Metric": [

        "Total vessels",

        "CII applicable vessels",

        "Comparable A-E vessels",

        "Baseline D/E vessels",

        "Scenario D/E vessels",

        "D/E vessel change",

        "Baseline D/E percentage",

        "Scenario D/E percentage",

        "D/E percentage-point change",

        "Improved ratings",

        "Unchanged ratings",

        "Worsened ratings",

        "Actual fleet fuel (t)",

        "Scenario fleet fuel (t)",

        "Fleet fuel change (%)",

        "Actual fleet CO2 (t)",

        "Scenario fleet CO2 (t)",

        "Fleet CO2 change (%)",

        "Largest mean CII increase category",

        "Largest mean CII decrease category"

    ],


    "Value": [

        len(integrated),

        integrated[
            "CII_Applicable_Final"
        ].sum(),

        len(comparable),

        baseline_de,

        scenario_de,

        scenario_de - baseline_de,

        baseline_de_pct,

        scenario_de_pct,

        scenario_de_pct - baseline_de_pct,

        improved,

        unchanged,

        worsened,

        actual_fuel_total,

        scenario_fuel_total,

        fuel_change,

        actual_co2_total,

        scenario_co2_total,

        co2_change,

        largest_increase_category,

        largest_decrease_category

    ]

})


final_summary_file = os.path.join(

    REPORT_DIR,

    "step14_final_analytical_summary.csv"

)


final_summary.to_csv(

    final_summary_file,

    index=False

)


# ============================================================
# SAVE RATING COMPARISON TABLE
# ============================================================

rating_comparison = pd.DataFrame({

    "Rating": rating_order,

    "Baseline_Vessels": [
        baseline_rating_counts[r]
        for r in rating_order
    ],

    "Scenario_Vessels": [
        scenario_rating_counts[r]
        for r in rating_order
    ],

    "Baseline_Percent": [
        baseline_pct[r]
        for r in rating_order
    ],

    "Scenario_Percent": [
        scenario_pct[r]
        for r in rating_order
    ]

})


rating_comparison_file = os.path.join(

    REPORT_DIR,

    "step14_rating_comparison.csv"

)


rating_comparison.to_csv(

    rating_comparison_file,

    index=False

)


# ============================================================
# PRINT FINAL RESULTS
# ============================================================

print("\n")
print("=" * 85)
print("STEP 14 — FINAL RESULTS")
print("=" * 85)


print(
    "\nFLEET"
)

print(
    "-" * 85
)

print(
    f"Total vessels          : {len(integrated):,}"
)

print(
    f"CII applicable         : "
    f"{integrated['CII_Applicable_Final'].sum():,}"
)

print(
    f"Comparable A-E         : {len(comparable):,}"
)


print(
    "\nRATING CHANGES"
)

print(
    "-" * 85
)

print(
    f"Improved               : {improved:,}"
)

print(
    f"Unchanged              : {unchanged:,}"
)

print(
    f"Worsened               : {worsened:,}"
)


print(
    "\nD/E PERFORMANCE"
)

print(
    "-" * 85
)

print(
    f"Baseline D/E           : "
    f"{baseline_de:,} ({baseline_de_pct:.2f}%)"
)

print(
    f"Scenario D/E           : "
    f"{scenario_de:,} ({scenario_de_pct:.2f}%)"
)

print(
    f"D/E vessel change      : "
    f"{scenario_de - baseline_de:+,}"
)

print(
    f"D/E percentage points  : "
    f"{scenario_de_pct - baseline_de_pct:+.2f}"
)


print(
    "\nFLEET FUEL"
)

print(
    "-" * 85
)

print(
    f"Actual                 : "
    f"{actual_fuel_total:,.2f} t"
)

print(
    f"Scenario               : "
    f"{scenario_fuel_total:,.2f} t"
)

print(
    f"Change                 : "
    f"{fuel_change:+.4f}%"
)


print(
    "\nFLEET CO₂"
)

print(
    "-" * 85
)

print(
    f"Actual                 : "
    f"{actual_co2_total:,.2f} t"
)

print(
    f"Scenario               : "
    f"{scenario_co2_total:,.2f} t"
)

print(
    f"Change                 : "
    f"{co2_change:+.4f}%"
)


print(
    "\nSHIP-TYPE FINDINGS"
)

print(
    "-" * 85
)

print(
    f"Largest mean CII increase : "
    f"{largest_increase_category}"
)

print(
    f"Largest mean CII decrease : "
    f"{largest_decrease_category}"
)


# ============================================================
# OUTPUT FILE LIST
# ============================================================

print(
    "\n"
)

print(
    "=" * 85
)

print(
    "STEP 14 COMPLETED SUCCESSFULLY"
)

print(
    "=" * 85
)


print(
    "\nGenerated figures:"
)


figure_files = [

    rating_distribution_file,

    rating_percentage_file,

    transition_file,

    de_file,

    ship_type_change_file,

    ship_type_de_file,

    observed_scenario_file,

    worst_file,

    best_file,

    fleet_fuel_file,

    fleet_co2_file,

    cii_change_distribution_file,

    cii_ratio_file

]


for i, file_path in enumerate(
    figure_files,
    start=1
):

    print(
        f"{i:2d}. {file_path}"
    )


print(
    "\nGenerated reports:"
)


print(
    f"1. {final_summary_file}"
)

print(
    f"2. {rating_comparison_file}"
)


print(
    "\n"
)

print(
    "=" * 85
)

print(
    "END OF STEP 14"
)

print(
    "=" * 85
)