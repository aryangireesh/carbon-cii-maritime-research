import pandas as pd
import numpy as np
import os
import joblib

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import (
    RandomForestRegressor,
    GradientBoostingRegressor
)

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

from xgboost import XGBRegressor


# ============================================================
# CARBON CII PROJECT
# STEP 4 — MODEL TRAINING
# ============================================================


# ============================================================
# 1. PATHS
# ============================================================

INPUT_PATH = "data/processed/MRV_2023_feature_engineered.csv"

RESULTS_PATH = "outputs/reports/model_training_results.csv"

MODEL_DIR = "outputs/models"


# ============================================================
# 2. CREATE OUTPUT DIRECTORIES
# ============================================================

os.makedirs("outputs/reports", exist_ok=True)
os.makedirs("outputs/models", exist_ok=True)


# ============================================================
# 3. LOAD DATA
# ============================================================

print("=" * 80)
print("CARBON CII PROJECT - MODEL TRAINING")
print("=" * 80)

df = pd.read_csv(INPUT_PATH)

print("\nDataset shape:")
print(df.shape)


# ============================================================
# 4. TARGET
# ============================================================

TARGET = "Fuel_Consumption_t"

print("\nTarget variable:")
print(TARGET)

print("\nTarget statistics:")
print(df[TARGET].describe())


# ============================================================
# 5. FEATURE DEFINITIONS
# ============================================================

# ------------------------------------------------------------
# MODEL A — OPERATIONAL
# ------------------------------------------------------------

operational_features = [

    "Ship_Type",

    "GT",
    "DWT",

    "Length_m",
    "Beam_m",
    "Draft_m",

    "Vessel_Age",

    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",

    "Length_Beam_Ratio",
    "DWT_GT_ratio",
    "Sea_Time_Utilization"
]


# ------------------------------------------------------------
# MODEL B — PRE-OPERATION
# ------------------------------------------------------------

preoperation_features = [

    "Ship_Type",

    "GT",
    "DWT",

    "Length_m",
    "Beam_m",
    "Draft_m",

    "Vessel_Age",

    "Length_Beam_Ratio",
    "DWT_GT_ratio"
]


# ============================================================
# 6. TARGET LEAKAGE COLUMNS
# ============================================================

leakage_columns = [

    "CO2_Emissions_t",
    "CO2_per_nm_kg",
    "Transport_Work_Mass",
    "Transport_Work_DWT",
    "Average_Cargo_Density"
]


# ============================================================
# 7. LEAKAGE CHECK
# ============================================================

print("\n" + "=" * 80)
print("TARGET LEAKAGE CHECK")
print("=" * 80)

for model_name, features in [
    ("Operational", operational_features),
    ("Pre-operation", preoperation_features)
]:

    leakage_found = [

        feature

        for feature in features

        if feature in leakage_columns

    ]

    print(f"\n{model_name} model:")

    if not leakage_found:

        print("PASS - No target leakage detected.")

    else:

        print("WARNING - Leakage detected:")

        for feature in leakage_found:

            print(f"  {feature}")


# ============================================================
# 8. MODEL DEFINITIONS
# ============================================================

models = {

    "Linear Regression": LinearRegression(),

    "Random Forest": RandomForestRegressor(
        n_estimators=400,
        max_features="sqrt",
        random_state=42,
        n_jobs=-1
    ),

    "Gradient Boosting": GradientBoostingRegressor(
        n_estimators=300,
        learning_rate=0.05,
        max_depth=3,
        loss="huber",
        random_state=42
    ),

    "XGBoost": XGBRegressor(
        n_estimators=500,
        learning_rate=0.05,
        max_depth=5,
        subsample=0.85,
        colsample_bytree=0.85,
        objective="reg:squarederror",
        random_state=42,
        n_jobs=-1
    )
}


# ============================================================
# 9. TRAINING FUNCTION
# ============================================================

def train_models(features, dataset_name):

    print("\n")
    print("=" * 80)
    print(f"TRAINING {dataset_name.upper()} MODEL")
    print("=" * 80)


    # --------------------------------------------------------
    # Separate X and y
    # --------------------------------------------------------

    X = df[features].copy()

    y = df[TARGET].copy()


    # --------------------------------------------------------
    # Train / test split
    # --------------------------------------------------------

    X_train, X_test, y_train, y_test = train_test_split(

        X,
        y,

        test_size=0.20,

        random_state=42

    )


    print("\nTraining samples:", len(X_train))

    print("Testing samples:", len(X_test))


    # ========================================================
    # EXPLICIT FEATURE TYPE DEFINITION
    # ========================================================

    categorical_features = [
        "Ship_Type"
    ]


    numerical_features = [

        feature

        for feature in features

        if feature not in categorical_features

    ]


    print("\nCategorical features:")

    for feature in categorical_features:

        if feature in features:

            print("  -", feature)


    print("\nNumerical features:")

    for feature in numerical_features:

        print("  -", feature)


    # ========================================================
    # NUMERICAL PIPELINE
    # ========================================================

    numerical_pipeline = Pipeline([

        (
            "imputer",

            SimpleImputer(

                strategy="median",

                add_indicator=True

            )

        ),

        (
            "scaler",

            StandardScaler()

        )

    ])


    # ========================================================
    # CATEGORICAL PIPELINE
    # ========================================================

    categorical_pipeline = Pipeline([

        (
            "imputer",

            SimpleImputer(

                strategy="most_frequent"

            )

        ),

        (
            "onehot",

            OneHotEncoder(

                handle_unknown="ignore"

            )

        )

    ])


    # ========================================================
    # COMBINE PREPROCESSING
    # ========================================================

    preprocessor = ColumnTransformer([

        (
            "numerical",

            numerical_pipeline,

            numerical_features

        ),

        (
            "categorical",

            categorical_pipeline,

            ["Ship_Type"]

        )

    ])


    # ========================================================
    # RESULTS
    # ========================================================

    results = []


    # ========================================================
    # TRAIN MODELS
    # ========================================================

    for model_name, model in models.items():

        print("\n" + "-" * 70)

        print(
            f"Training {model_name}..."
        )

        print("-" * 70)


        # ----------------------------------------------------
        # Complete pipeline
        # ----------------------------------------------------

        pipeline = Pipeline([

            (
                "preprocessor",

                preprocessor

            ),

            (
                "model",

                model

            )

        ])


        # ----------------------------------------------------
        # Train
        # ----------------------------------------------------

        pipeline.fit(

            X_train,

            y_train

        )


        # ----------------------------------------------------
        # Predict
        # ----------------------------------------------------

        predictions = pipeline.predict(

            X_test

        )


        # ====================================================
        # METRICS
        # ====================================================

        mae = mean_absolute_error(

            y_test,

            predictions

        )


        rmse = np.sqrt(

            mean_squared_error(

                y_test,

                predictions

            )

        )


        r2 = r2_score(

            y_test,

            predictions

        )


        print(
            f"MAE  : {mae:.2f} tonnes"
        )

        print(
            f"RMSE : {rmse:.2f} tonnes"
        )

        print(
            f"R²   : {r2:.4f}"
        )


        # ====================================================
        # STORE RESULTS
        # ====================================================

        results.append({

            "Dataset": dataset_name,

            "Model": model_name,

            "MAE_tonnes": mae,

            "RMSE_tonnes": rmse,

            "R2": r2

        })


        # ====================================================
        # SAVE MODEL
        # ====================================================

        dataset_clean = (

            dataset_name

            .lower()

            .replace("-", "")

            .replace(" ", "_")

        )


        model_clean = (

            model_name

            .lower()

            .replace(" ", "_")

        )


        model_path = (

            f"{MODEL_DIR}/"

            f"{dataset_clean}_"

            f"{model_clean}.joblib"

        )


        joblib.dump(

            pipeline,

            model_path

        )


        print(
            f"Model saved: {model_path}"
        )


    return pd.DataFrame(results)


# ============================================================
# 10. OPERATIONAL MODELS
# ============================================================

operational_results = train_models(

    operational_features,

    "Operational"

)


# ============================================================
# 11. PRE-OPERATION MODELS
# ============================================================

preoperation_results = train_models(

    preoperation_features,

    "Pre-operation"

)


# ============================================================
# 12. COMBINE RESULTS
# ============================================================

results = pd.concat(

    [

        operational_results,

        preoperation_results

    ],

    ignore_index=True

)


# ============================================================
# 13. SORT
# ============================================================

results = results.sort_values(

    by="R2",

    ascending=False

)


# ============================================================
# 14. DISPLAY FINAL RESULTS
# ============================================================

print("\n")

print("=" * 80)

print("FINAL MODEL COMPARISON")

print("=" * 80)

print(

    results.to_string(

        index=False,

        float_format=lambda x: f"{x:.4f}"

    )

)


# ============================================================
# 15. SAVE RESULTS
# ============================================================

results.to_csv(

    RESULTS_PATH,

    index=False

)


# ============================================================
# 16. BEST MODEL
# ============================================================

best_model = results.iloc[0]


print("\n")

print("=" * 80)

print("BEST BASELINE MODEL")

print("=" * 80)

print(

    f"Dataset : "
    f"{best_model['Dataset']}"

)

print(

    f"Model   : "
    f"{best_model['Model']}"

)

print(

    f"MAE     : "
    f"{best_model['MAE_tonnes']:.2f} tonnes"

)

print(

    f"RMSE    : "
    f"{best_model['RMSE_tonnes']:.2f} tonnes"

)

print(

    f"R²      : "
    f"{best_model['R2']:.4f}"

)


# ============================================================
# 17. COMPLETION
# ============================================================

print("\nResults saved to:")

print(RESULTS_PATH)

print("\nModels saved to:")

print(MODEL_DIR)

print("\n" + "=" * 80)

print("MODEL TRAINING COMPLETED")

print("=" * 80)