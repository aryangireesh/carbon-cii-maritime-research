import pandas as pd
import numpy as np


# ============================================================
# CARBON CII PROJECT
# STEP 2 — DATA CLEANING & VALIDATION
# ============================================================

INPUT_PATH = "data/processed/MRV_2023_cleaned_for_modeling.csv"

OUTPUT_PATH = "data/processed/MRV_2023_final_cleaned.csv"


# ============================================================
# 1. LOAD DATA
# ============================================================

print("=" * 75)
print("CARBON CII PROJECT - DATA CLEANING")
print("=" * 75)

df = pd.read_csv(INPUT_PATH)

print("\nOriginal dataset shape:")
print(df.shape)


# ============================================================
# 2. STANDARDIZE COLUMN NAMES
# ============================================================

df.columns = df.columns.str.strip()

print("\nColumns:")
print(df.columns.tolist())


# ============================================================
# 3. CHECK DUPLICATES
# ============================================================

print("\n" + "=" * 75)
print("DUPLICATE CHECK")
print("=" * 75)

duplicate_rows = df.duplicated().sum()
duplicate_imo = df["IMO"].duplicated().sum()

print(f"Duplicate rows: {duplicate_rows}")
print(f"Duplicate IMO numbers: {duplicate_imo}")


# Remove exact duplicate rows if any exist
df = df.drop_duplicates()


# Keep only one record per IMO if duplicates exist
df = df.drop_duplicates(subset="IMO", keep="first")


# ============================================================
# 4. NUMERIC DATA VALIDATION
# ============================================================

numeric_columns = [
    "GT",
    "DWT",
    "Draft_m",
    "Length_m",
    "Beam_m",
    "Fuel_Consumption_t",
    "CO2_Emissions_t",
    "Distance_nm",
    "Time_At_Sea_h",
    "CO2_per_nm_kg",
    "Average_Speed_kn"
]

print("\n" + "=" * 75)
print("NUMERIC VALIDATION")
print("=" * 75)

for column in numeric_columns:

    if column in df.columns:

        negative_count = (df[column] < 0).sum()

        print(
            f"{column:25s} "
            f"negative values = {negative_count}"
        )


# ============================================================
# 5. REMOVE ZERO-ACTIVITY VESSELS
# ============================================================

print("\n" + "=" * 75)
print("ZERO-ACTIVITY CHECK")
print("=" * 75)

zero_fuel = (df["Fuel_Consumption_t"] <= 0).sum()
zero_co2 = (df["CO2_Emissions_t"] <= 0).sum()
zero_distance = (df["Distance_nm"] <= 0).sum()
zero_time = (df["Time_At_Sea_h"] <= 0).sum()

print(f"Zero/negative fuel:     {zero_fuel}")
print(f"Zero/negative CO2:      {zero_co2}")
print(f"Zero/negative distance: {zero_distance}")
print(f"Zero/negative time:     {zero_time}")


# A vessel with no fuel and no operational activity
# cannot be used for annual fuel prediction.
before = len(df)

df = df[
    (df["Fuel_Consumption_t"] > 0) &
    (df["CO2_Emissions_t"] > 0) &
    (df["Distance_nm"] > 0) &
    (df["Time_At_Sea_h"] > 0)
].copy()

removed = before - len(df)

print(f"\nRows removed: {removed}")


# ============================================================
# 6. DRAFT VALIDATION
# ============================================================

print("\n" + "=" * 75)
print("DRAFT VALIDATION")
print("=" * 75)

# Conservative physical screening.
# Values outside this range are treated as unreliable/missing.
invalid_draft = (
    (df["Draft_m"] < 2) |
    (df["Draft_m"] > 20)
)

print(
    "Suspicious draft values:",
    invalid_draft.sum()
)

df.loc[invalid_draft, "Draft_m"] = np.nan


# ============================================================
# 7. LENGTH VALIDATION
# ============================================================

print("\n" + "=" * 75)
print("LENGTH VALIDATION")
print("=" * 75)

invalid_length = (
    (df["Length_m"] <= 0) |
    (df["Length_m"] > 500)
)

print(
    "Suspicious length values:",
    invalid_length.sum()
)

df.loc[invalid_length, "Length_m"] = np.nan


# ============================================================
# 8. BEAM VALIDATION
# ============================================================

print("\n" + "=" * 75)
print("BEAM VALIDATION")
print("=" * 75)

invalid_beam = (
    (df["Beam_m"] <= 0) |
    (df["Beam_m"] > 100)
)

print(
    "Suspicious beam values:",
    invalid_beam.sum()
)

df.loc[invalid_beam, "Beam_m"] = np.nan


# ============================================================
# 9. CALCULATE AVERAGE SPEED
# ============================================================

print("\n" + "=" * 75)
print("SPEED CALCULATION")
print("=" * 75)

df["Average_Speed_kn"] = (
    df["Distance_nm"] /
    df["Time_At_Sea_h"]
)

# Physically questionable annual average speeds.
invalid_speed = (
    (df["Average_Speed_kn"] < 3) |
    (df["Average_Speed_kn"] > 30)
)

print(
    "Suspicious speed values:",
    invalid_speed.sum()
)

df.loc[invalid_speed, "Average_Speed_kn"] = np.nan


# ============================================================
# 10. CALCULATE VESSEL AGE
# ============================================================

print("\n" + "=" * 75)
print("VESSEL AGE")
print("=" * 75)

df["Vessel_Age"] = (
    df["Reporting_Year"] -
    df["Build_Year"]
)

invalid_age = (
    (df["Vessel_Age"] < 0) |
    (df["Vessel_Age"] > 100)
)

print(
    "Invalid vessel ages:",
    invalid_age.sum()
)

df.loc[invalid_age, "Vessel_Age"] = np.nan


# ============================================================
# 11. DWT / GT RATIO
# ============================================================

print("\n" + "=" * 75)
print("DWT / GT RATIO")
print("=" * 75)

df["DWT_GT_ratio"] = (
    df["DWT"] /
    df["GT"].replace(0, np.nan)
)

print(
    df["DWT_GT_ratio"].describe()
)


# ============================================================
# 12. FUEL-TO-CO2 CONSISTENCY CHECK
# ============================================================

print("\n" + "=" * 75)
print("FUEL / CO2 CONSISTENCY")
print("=" * 75)

df["CO2_Fuel_Ratio"] = (
    df["CO2_Emissions_t"] /
    df["Fuel_Consumption_t"]
)

print(
    df["CO2_Fuel_Ratio"].describe()
)


# ============================================================
# 13. DISTANCE RECONSTRUCTION CHECK
# ============================================================

print("\n" + "=" * 75)
print("DISTANCE CONSISTENCY CHECK")
print("=" * 75)

df["Calculated_Distance_nm"] = (
    df["CO2_Emissions_t"] * 1000 /
    df["CO2_per_nm_kg"]
)

df["Distance_Error_pct"] = (
    abs(
        df["Distance_nm"] -
        df["Calculated_Distance_nm"]
    )
    /
    df["Distance_nm"]
) * 100

print(
    "Median distance reconstruction error:",
    df["Distance_Error_pct"].median()
)

print(
    "Maximum distance reconstruction error:",
    df["Distance_Error_pct"].max()
)


# ============================================================
# 14. REMOVE TEMPORARY VALIDATION COLUMNS
# ============================================================

df.drop(
    columns=[
        "CO2_Fuel_Ratio",
        "Calculated_Distance_nm",
        "Distance_Error_pct"
    ],
    inplace=True,
    errors="ignore"
)


# ============================================================
# 15. MISSING VALUE REPORT
# ============================================================

print("\n" + "=" * 75)
print("FINAL MISSING VALUE REPORT")
print("=" * 75)

missing = df.isnull().sum()

missing_percentage = (
    df.isnull().mean() * 100
)

missing_report = pd.DataFrame({
    "Missing_Count": missing,
    "Missing_Percentage": missing_percentage
})

print(
    missing_report[
        missing_report["Missing_Count"] > 0
    ].sort_values(
        "Missing_Count",
        ascending=False
    )
)


# ============================================================
# 16. FINAL DATASET INFORMATION
# ============================================================

print("\n" + "=" * 75)
print("FINAL DATASET")
print("=" * 75)

print("Rows:", len(df))
print("Columns:", len(df.columns))

print("\nDuplicate rows:")
print(df.duplicated().sum())

print("\nDuplicate IMO:")
print(df["IMO"].duplicated().sum())


# ============================================================
# 17. SAVE CLEAN DATASET
# ============================================================

df.to_csv(
    OUTPUT_PATH,
    index=False
)

print("\n" + "=" * 75)
print("CLEANING COMPLETED")
print("=" * 75)

print(
    f"Clean dataset saved to:\n{OUTPUT_PATH}"
)