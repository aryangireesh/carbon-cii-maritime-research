# ================================================================
# STEP 10 — FINAL ML PREDICTIONS & SCENARIO ANALYSIS
# Carbon CII Project
# ================================================================

import os
import warnings
import joblib
import numpy as np
import pandas as pd

from sklearn.metrics import (
    r2_score,
    mean_absolute_error,
    mean_squared_error
)

warnings.filterwarnings("ignore")


# ================================================================
# 1. PROJECT PATHS
# ================================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

# IMPORTANT:
# Feature-engineered dataset is inside data/processed
DATA_DIR = os.path.join(
    BASE_DIR,
    "data",
    "processed"
)

OUTPUT_DIR = os.path.join(
    BASE_DIR,
    "outputs"
)

MODEL_DIR = os.path.join(
    OUTPUT_DIR,
    "models"
)

REPORT_DIR = os.path.join(
    OUTPUT_DIR,
    "reports"
)


# Create output directory if required

os.makedirs(
    REPORT_DIR,
    exist_ok=True
)


# ================================================================
# 2. INPUT FILE
# ================================================================

DATA_FILE = os.path.join(
    DATA_DIR,
    "MRV_2023_feature_engineered.csv"
)


# ================================================================
# 3. MODEL FILE
# ================================================================

MODEL_FILE = os.path.join(
    MODEL_DIR,
    "final_operational_xgboost_tuned.joblib"
)


# ================================================================
# 4. OUTPUT FILES
# ================================================================

PREDICTION_FILE = os.path.join(
    REPORT_DIR,
    "ml_final_predictions_2023.csv"
)

SUMMARY_FILE = os.path.join(
    REPORT_DIR,
    "ml_prediction_summary.csv"
)

ERROR_FILE = os.path.join(
    REPORT_DIR,
    "ml_prediction_error_analysis.csv"
)

ZERO_FILE = os.path.join(
    REPORT_DIR,
    "ml_zero_predictions_diagnostic.csv"
)


# ================================================================
# 5. START
# ================================================================

print("=" * 75)
print("STEP 10 — FINAL ML PREDICTIONS & SCENARIO ANALYSIS")
print("=" * 75)


# ================================================================
# [1/10] LOAD FEATURE-ENGINEERED DATA
# ================================================================

print("\n[1/10] Loading feature-engineered dataset...")

if not os.path.exists(DATA_FILE):

    raise FileNotFoundError(
        "\nFeature-engineered dataset not found.\n\n"
        f"Expected location:\n{DATA_FILE}\n\n"
        "Please check that the file exists."
    )

df = pd.read_csv(
    DATA_FILE
)

print(
    f"Dataset shape: {df.shape}"
)

print(
    f"Dataset loaded successfully."
)


# ================================================================
# [2/10] CHECK REQUIRED COLUMNS
# ================================================================

print("\n[2/10] Checking required columns...")


TARGET_COLUMN = "Fuel_Consumption_t"


required_columns = [
    "IMO",
    "Ship_Name",
    "Ship_Type",
    "Reporting_Year",
    "Build_Year",
    "Vessel_Age",
    "GT",
    "DWT",
    "Draft_m",
    "Length_m",
    "Beam_m",
    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",
    "Fuel_Consumption_t",
    "CO2_Emissions_t"
]


missing_columns = [
    column
    for column in required_columns
    if column not in df.columns
]


if missing_columns:

    print("\nMissing columns:")

    for column in missing_columns:
        print(
            f"  - {column}"
        )

    raise ValueError(
        "\nRequired columns are missing from the dataset."
    )


print(
    "All required columns are present."
)


# ================================================================
# [3/10] PREPARE OPERATIONAL FEATURES
# ================================================================

print("\n[3/10] Preparing operational ML features...")


OPERATIONAL_FEATURES = [

    "Ship_Type",

    "GT",
    "DWT",

    "Length_m",
    "Beam_m",
    "Draft_m",

    "Vessel_Age",

    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",

    "Length_Beam_Ratio",
    "DWT_GT_ratio",
    "Sea_Time_Utilization"
]


missing_features = [
    column
    for column in OPERATIONAL_FEATURES
    if column not in df.columns
]


if missing_features:

    print("\nMissing ML features:")

    for column in missing_features:
        print(
            f"  - {column}"
        )

    raise ValueError(
        "\nOperational ML features are missing."
    )


# Feature matrix

X = df[
    OPERATIONAL_FEATURES
].copy()


# Target

y = pd.to_numeric(
    df[TARGET_COLUMN],
    errors="coerce"
)


print(
    f"Number of ML features: "
    f"{len(OPERATIONAL_FEATURES)}"
)

print(
    f"Number of observations: "
    f"{len(df):,}"
)


# ================================================================
# [4/10] PREPARE ACTUAL FUEL
# ================================================================

print("\n[4/10] Preparing actual fuel-consumption values...")


# IMPORTANT:
# Keep the original observed fuel consumption.
#
# This MUST be created before calculating errors.

df["Actual_Fuel_t"] = y


# Identify rows with valid target

valid_target_mask = y.notna()


X_train = X.loc[
    valid_target_mask
].copy()


y_train = y.loc[
    valid_target_mask
].copy()


print(
    f"Valid target rows: "
    f"{len(y_train):,}"
)

print(
    f"Actual fuel mean: "
    f"{y_train.mean():,.2f} t"
)

print(
    f"Actual fuel minimum: "
    f"{y_train.min():,.4f} t"
)

print(
    f"Actual fuel maximum: "
    f"{y_train.max():,.2f} t"
)


# ================================================================
# [5/10] LOAD TUNED MODEL
# ================================================================

print("\n[5/10] Loading tuned XGBoost model...")


if not os.path.exists(MODEL_FILE):

    raise FileNotFoundError(
        "\nTuned model not found.\n\n"
        f"Expected location:\n{MODEL_FILE}"
    )


model = joblib.load(
    MODEL_FILE
)


print(
    "Tuned XGBoost model loaded successfully."
)


# ================================================================
# [6/10] FIT MODEL ON COMPLETE DATASET
# ================================================================

print(
    "\n[6/10] Fitting tuned XGBoost "
    "on complete dataset..."
)


model.fit(
    X_train,
    y_train
)


print(
    "Model fitted successfully."
)


# ================================================================
# [7/10] GENERATE FINAL PREDICTIONS
# ================================================================

print(
    "\n[7/10] Generating final "
    "fuel-consumption predictions..."
)


# Predict for all observations

X_all = X.copy()


predicted_fuel = model.predict(
    X_all
)


predicted_fuel = np.asarray(
    predicted_fuel,
    dtype=float
)


# Save predictions

df["Predicted_Fuel_t"] = predicted_fuel


print(
    "Predictions generated successfully."
)


print(
    f"Predicted fuel mean: "
    f"{np.nanmean(predicted_fuel):,.2f} t"
)

print(
    f"Predicted fuel minimum: "
    f"{np.nanmin(predicted_fuel):,.6f} t"
)

print(
    f"Predicted fuel maximum: "
    f"{np.nanmax(predicted_fuel):,.2f} t"
)


# Count zero predictions

zero_predictions = np.sum(
    predicted_fuel == 0
)


negative_predictions = np.sum(
    predicted_fuel < 0
)


print(
    f"Zero predictions: "
    f"{zero_predictions:,}"
)

print(
    f"Negative predictions: "
    f"{negative_predictions:,}"
)


# ================================================================
# [8/10] FUEL PREDICTION ERRORS
# ================================================================

print(
    "\n[8/10] Calculating fuel prediction errors..."
)


# Prediction error

df["Fuel_Error_t"] = (
    df["Predicted_Fuel_t"]
    - df["Actual_Fuel_t"]
)


# Absolute error

df["Fuel_Absolute_Error_t"] = (
    df["Fuel_Error_t"]
    .abs()
)


# Percentage error

df["Fuel_Error_Percent"] = np.where(

    df["Actual_Fuel_t"] != 0,

    (
        df["Fuel_Error_t"]
        /
        df["Actual_Fuel_t"]
    ) * 100,

    np.nan
)


# ================================================================
# [9/10] CO2 SCENARIO CALCULATION
# ================================================================

print(
    "\n[9/10] Calculating CO₂ scenario values..."
)


# ------------------------------------------------
# Actual CO2
# ------------------------------------------------

df["Actual_CO2_t"] = pd.to_numeric(
    df["CO2_Emissions_t"],
    errors="coerce"
)


# ------------------------------------------------
# Observed vessel-specific CO2/Fuel ratio
# ------------------------------------------------

df["CO2_per_Fuel_Ratio"] = np.where(

    df["Actual_Fuel_t"] > 0,

    (
        df["Actual_CO2_t"]
        /
        df["Actual_Fuel_t"]
    ),

    np.nan
)


# ------------------------------------------------
# Scenario CO2
# ------------------------------------------------
#
# IMPORTANT:
#
# ML predicts fuel.
#
# Scenario CO2 is calculated using each vessel's
# observed CO2/fuel ratio.
#
# This is NOT an independent CO2 ML model.

df["Predicted_CO2_t"] = (

    df["Predicted_Fuel_t"]

    *

    df["CO2_per_Fuel_Ratio"]
)


# ------------------------------------------------
# CO2 error
# ------------------------------------------------

df["CO2_Error_t"] = (

    df["Predicted_CO2_t"]

    -

    df["Actual_CO2_t"]
)


# ------------------------------------------------
# Absolute CO2 error
# ------------------------------------------------

df["CO2_Absolute_Error_t"] = (

    df["CO2_Error_t"]
    .abs()
)


# ------------------------------------------------
# CO2 percentage error
# ------------------------------------------------

df["CO2_Error_Percent"] = np.where(

    df["Actual_CO2_t"] != 0,

    (
        df["CO2_Error_t"]
        /
        df["Actual_CO2_t"]
    ) * 100,

    np.nan
)


print(
    "CO₂ scenario calculated successfully."
)


# ================================================================
# [10/10] CREATE FINAL OUTPUT
# ================================================================

print(
    "\n[10/10] Creating final prediction dataset..."
)


OUTPUT_COLUMNS = [

    "IMO",
    "Ship_Name",
    "Ship_Type",
    "Reporting_Year",
    "Build_Year",
    "Vessel_Age",

    "GT",
    "DWT",
    "Draft_m",
    "Length_m",
    "Beam_m",

    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",

    "Actual_Fuel_t",
    "Predicted_Fuel_t",

    "Fuel_Error_t",
    "Fuel_Absolute_Error_t",
    "Fuel_Error_Percent",

    "Actual_CO2_t",
    "Predicted_CO2_t",

    "CO2_Error_t",
    "CO2_Absolute_Error_t",
    "CO2_Error_Percent"
]


final_df = df[
    OUTPUT_COLUMNS
].copy()


# ================================================================
# SAVE FINAL PREDICTIONS
# ================================================================

final_df.to_csv(
    PREDICTION_FILE,
    index=False
)


print(
    "\nFinal prediction file saved:"
)

print(
    PREDICTION_FILE
)


# ================================================================
# MODEL PERFORMANCE ON COMPLETE DATA
# ================================================================

valid_fuel = (

    final_df["Actual_Fuel_t"].notna()

    &

    final_df["Predicted_Fuel_t"].notna()
)


actual_fuel = final_df.loc[
    valid_fuel,
    "Actual_Fuel_t"
]


predicted_fuel_valid = final_df.loc[
    valid_fuel,
    "Predicted_Fuel_t"
]


# R²

r2 = r2_score(
    actual_fuel,
    predicted_fuel_valid
)


# MAE

mae = mean_absolute_error(
    actual_fuel,
    predicted_fuel_valid
)


# RMSE

rmse = np.sqrt(
    mean_squared_error(
        actual_fuel,
        predicted_fuel_valid
    )
)


# ================================================================
# CO2 PERFORMANCE
# ================================================================

valid_co2 = (

    final_df["Actual_CO2_t"].notna()

    &

    final_df["Predicted_CO2_t"].notna()
)


actual_co2 = final_df.loc[
    valid_co2,
    "Actual_CO2_t"
]


predicted_co2_valid = final_df.loc[
    valid_co2,
    "Predicted_CO2_t"
]


co2_mae = mean_absolute_error(
    actual_co2,
    predicted_co2_valid
)


co2_rmse = np.sqrt(
    mean_squared_error(
        actual_co2,
        predicted_co2_valid
    )
)


# ================================================================
# FLEET TOTALS
# ================================================================

actual_fuel_total = (
    final_df["Actual_Fuel_t"]
    .sum()
)


predicted_fuel_total = (
    final_df["Predicted_Fuel_t"]
    .sum()
)


actual_co2_total = (
    final_df["Actual_CO2_t"]
    .sum()
)


predicted_co2_total = (
    final_df["Predicted_CO2_t"]
    .sum()
)


# Fleet fuel change

fuel_total_change_pct = (

    (
        predicted_fuel_total
        -
        actual_fuel_total
    )

    /

    actual_fuel_total

) * 100


# Fleet CO2 change

co2_total_change_pct = (

    (
        predicted_co2_total
        -
        actual_co2_total
    )

    /

    actual_co2_total

) * 100


# ================================================================
# PRINT FINAL SUMMARY
# ================================================================

print("\n")
print("=" * 75)
print("FINAL ML PREDICTION SUMMARY")
print("=" * 75)


print("\nMODEL PERFORMANCE")
print("-" * 75)


print(
    f"R²                  : {r2:.4f}"
)

print(
    f"MAE                 : {mae:,.2f} t"
)

print(
    f"RMSE                : {rmse:,.2f} t"
)


print("\nCO₂ SCENARIO PERFORMANCE")
print("-" * 75)


print(
    f"CO₂ MAE             : {co2_mae:,.2f} t"
)

print(
    f"CO₂ RMSE            : {co2_rmse:,.2f} t"
)


print("\nMEAN VALUES")
print("-" * 75)


print(
    f"Actual mean fuel    : "
    f"{actual_fuel.mean():,.2f} t"
)

print(
    f"Predicted mean fuel : "
    f"{predicted_fuel_valid.mean():,.2f} t"
)

print(
    f"Actual mean CO₂     : "
    f"{actual_co2.mean():,.2f} t"
)

print(
    f"Scenario mean CO₂   : "
    f"{predicted_co2_valid.mean():,.2f} t"
)


print("\nFLEET TOTALS")
print("-" * 75)


print(
    f"Actual fuel total   : "
    f"{actual_fuel_total:,.2f} t"
)

print(
    f"Scenario fuel total : "
    f"{predicted_fuel_total:,.2f} t"
)

print(
    f"Fuel total change   : "
    f"{fuel_total_change_pct:+.4f}%"
)

print(
    f"Actual CO₂ total    : "
    f"{actual_co2_total:,.2f} t"
)

print(
    f"Scenario CO₂ total  : "
    f"{predicted_co2_total:,.2f} t"
)

print(
    f"CO₂ total change    : "
    f"{co2_total_change_pct:+.4f}%"
)


# ================================================================
# ZERO / NEGATIVE PREDICTION DIAGNOSTIC
# ================================================================

print("\n")
print("=" * 75)
print("ZERO / NEGATIVE PREDICTION DIAGNOSTICS")
print("=" * 75)


zero_mask = (
    final_df["Predicted_Fuel_t"] <= 0
)


zero_df = final_df.loc[
    zero_mask
].copy()


print(
    f"\nZero/negative predictions: "
    f"{len(zero_df):,}"
)


if len(zero_df) > 0:

    diagnostic_columns = [

        "IMO",
        "Ship_Name",
        "Ship_Type",

        "GT",
        "DWT",

        "Distance_nm",
        "Time_At_Sea_h",
        "Average_Speed_kn",

        "Actual_Fuel_t",
        "Predicted_Fuel_t",

        "Fuel_Error_t",
        "Fuel_Absolute_Error_t"
    ]


    print(
        "\nAffected vessels:"
    )


    print(
        zero_df[
            diagnostic_columns
        ].to_string(
            index=False
        )
    )


    zero_df[
        diagnostic_columns
    ].to_csv(
        ZERO_FILE,
        index=False
    )


    print(
        "\nZero-prediction diagnostic saved:"
    )

    print(
        ZERO_FILE
    )


# ================================================================
# TOP 10 ACTUAL FUEL CONSUMERS
# ================================================================

print("\n")
print("=" * 75)
print("TOP 10 ACTUAL FUEL CONSUMERS")
print("=" * 75)


top_actual = (

    final_df

    .sort_values(
        "Actual_Fuel_t",
        ascending=False
    )

    .head(10)
)


print(
    top_actual[
        [
            "IMO",
            "Ship_Name",
            "Ship_Type",
            "Actual_Fuel_t",
            "Predicted_Fuel_t"
        ]
    ].to_string(
        index=False
    )
)


# ================================================================
# TOP 10 ABSOLUTE ERRORS
# ================================================================

print("\n")
print("=" * 75)
print("TOP 10 ABSOLUTE FUEL PREDICTION ERRORS")
print("=" * 75)


top_errors = (

    final_df

    .sort_values(
        "Fuel_Absolute_Error_t",
        ascending=False
    )

    .head(10)
)


print(
    top_errors[
        [
            "IMO",
            "Ship_Name",
            "Ship_Type",

            "Actual_Fuel_t",
            "Predicted_Fuel_t",

            "Fuel_Error_t",
            "Fuel_Absolute_Error_t",
            "Fuel_Error_Percent"
        ]
    ].to_string(
        index=False
    )
)


# ================================================================
# SAVE ERROR ANALYSIS
# ================================================================

error_analysis = (

    final_df[
        [
            "IMO",
            "Ship_Name",
            "Ship_Type",

            "GT",
            "DWT",

            "Distance_nm",
            "Time_At_Sea_h",
            "Average_Speed_kn",

            "Actual_Fuel_t",
            "Predicted_Fuel_t",

            "Fuel_Error_t",
            "Fuel_Absolute_Error_t",
            "Fuel_Error_Percent"
        ]
    ]

    .sort_values(
        "Fuel_Absolute_Error_t",
        ascending=False
    )
)


error_analysis.to_csv(
    ERROR_FILE,
    index=False
)


# ================================================================
# SAVE SUMMARY
# ================================================================

summary_data = {

    "Metric": [

        "Number_of_vessels",

        "R2",
        "MAE_fuel_t",
        "RMSE_fuel_t",

        "Mean_actual_fuel_t",
        "Mean_predicted_fuel_t",

        "Fleet_actual_fuel_t",
        "Fleet_predicted_fuel_t",
        "Fleet_fuel_change_percent",

        "Mean_actual_CO2_t",
        "Mean_predicted_CO2_t",

        "Fleet_actual_CO2_t",
        "Fleet_predicted_CO2_t",
        "Fleet_CO2_change_percent",

        "CO2_MAE_t",
        "CO2_RMSE_t",

        "Zero_or_negative_predictions"
    ],


    "Value": [

        len(final_df),

        r2,
        mae,
        rmse,

        actual_fuel.mean(),
        predicted_fuel_valid.mean(),

        actual_fuel_total,
        predicted_fuel_total,
        fuel_total_change_pct,

        actual_co2.mean(),
        predicted_co2_valid.mean(),

        actual_co2_total,
        predicted_co2_total,
        co2_total_change_pct,

        co2_mae,
        co2_rmse,

        zero_predictions
    ]
}


summary_df = pd.DataFrame(
    summary_data
)


summary_df.to_csv(
    SUMMARY_FILE,
    index=False
)


# ================================================================
# FINAL OUTPUT
# ================================================================

print("\n")
print("=" * 75)
print("STEP 10 COMPLETED SUCCESSFULLY")
print("=" * 75)


print(
    "\nFinal prediction file:"
)

print(
    PREDICTION_FILE
)


print(
    "\nSummary file:"
)

print(
    SUMMARY_FILE
)


print(
    "\nError analysis file:"
)

print(
    ERROR_FILE
)


if len(zero_df) > 0:

    print(
        "\nZero-prediction diagnostic:"
    )

    print(
        ZERO_FILE
    )


print("\n" + "=" * 75)