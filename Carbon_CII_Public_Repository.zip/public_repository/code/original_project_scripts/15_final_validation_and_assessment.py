# ============================================================
# STEP 15 — FINAL VALIDATION & RESEARCH ASSESSMENT
# ============================================================
#
# Carbon CII Project
#
# Purpose:
#   Final validation and research-quality assessment of the
#   complete ML + IMO CII pipeline.
#
# IMPORTANT:
#   - ML predicts fuel consumption.
#   - CO2 scenario is derived from predicted fuel.
#   - IMO CII is calculated deterministically.
#   - This script does NOT retrain the model.
#   - Step 9 cross-validation remains the primary evidence
#     for model generalization.
#
# ============================================================

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# ============================================================
# PROJECT PATHS
# ============================================================

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

REPORT_DIR = os.path.join(
    BASE_DIR,
    "outputs",
    "reports"
)

FIGURE_DIR = os.path.join(
    BASE_DIR,
    "outputs",
    "figures"
)

os.makedirs(REPORT_DIR, exist_ok=True)
os.makedirs(FIGURE_DIR, exist_ok=True)


# ============================================================
# INPUT FILES
# ============================================================

INTEGRATED_FILE = os.path.join(
    REPORT_DIR,
    "ml_cii_integrated_scenario_results.csv"
)

SHIP_TYPE_FILE = os.path.join(
    REPORT_DIR,
    "ml_cii_ship_type_scenario_analysis.csv"
)

TRANSITION_FILE = os.path.join(
    REPORT_DIR,
    "ml_cii_rating_transition_matrix.csv"
)

SUMMARY_FILE = os.path.join(
    REPORT_DIR,
    "step14_final_analytical_summary.csv"
)

RATING_FILE = os.path.join(
    REPORT_DIR,
    "step14_rating_comparison.csv"
)


# ============================================================
# HEADER
# ============================================================

print("=" * 90)
print("STEP 15 — FINAL VALIDATION & RESEARCH ASSESSMENT")
print("=" * 90)


# ============================================================
# [1/10] LOAD FINAL PROJECT OUTPUTS
# ============================================================

print("\n[1/10] Loading final project outputs...")


required_files = [
    INTEGRATED_FILE,
    SHIP_TYPE_FILE,
    TRANSITION_FILE,
    SUMMARY_FILE,
    RATING_FILE
]


for file_path in required_files:

    if not os.path.exists(file_path):

        raise FileNotFoundError(
            f"\nRequired file not found:\n{file_path}"
        )


integrated = pd.read_csv(
    INTEGRATED_FILE
)

ship_type = pd.read_csv(
    SHIP_TYPE_FILE
)

transition = pd.read_csv(
    TRANSITION_FILE,
    index_col=0
)

summary = pd.read_csv(
    SUMMARY_FILE
)

rating_comparison = pd.read_csv(
    RATING_FILE
)


print(
    f"Integrated dataset : {integrated.shape}"
)

print(
    f"Ship-type dataset  : {ship_type.shape}"
)

print(
    f"Transition matrix  : {transition.shape}"
)

print(
    f"Summary dataset    : {summary.shape}"
)

print(
    f"Rating comparison  : {rating_comparison.shape}"
)


# ============================================================
# DISPLAY IMPORTANT COLUMNS
# ============================================================

print("\nRelevant integrated columns:")

relevant_columns = [

    col

    for col in integrated.columns

    if (
        "Ship_Type" in col
        or "Fuel" in col
        or "CO2" in col
        or "CII" in col
        or "Rating" in col
        or "Distance" in col
    )

]

print(
    relevant_columns
)


# ============================================================
# HELPER FUNCTION — FIND COLUMN
# ============================================================

def find_column(
    dataframe,
    candidates,
    required=True
):
    """
    Find the first available column from a list of candidates.
    """

    for column in candidates:

        if column in dataframe.columns:

            return column

    if required:

        raise KeyError(
            "\nNone of the expected columns were found.\n"
            f"Candidates: {candidates}\n\n"
            "Available columns:\n"
            + "\n".join(dataframe.columns)
        )

    return None


# ============================================================
# RESOLVE IMPORTANT COLUMNS
# ============================================================

SHIP_TYPE_COLUMN = find_column(
    integrated,
    [
        "Ship_Type",
        "Ship_Type_ML",
        "Ship_Type_CII",
        "Ship_Type_x",
        "Ship_Type_y"
    ]
)

IMO_COLUMN = find_column(
    integrated,
    [
        "IMO",
        "IMO_ML",
        "IMO_CII",
        "IMO_x",
        "IMO_y"
    ]
)

ACTUAL_FUEL_COLUMN = find_column(
    integrated,
    [
        "Actual_Fuel_t",
        "Actual_Fuel",
        "Fuel_Consumption_t"
    ]
)

PREDICTED_FUEL_COLUMN = find_column(
    integrated,
    [
        "Predicted_Fuel_t",
        "Predicted_Fuel"
    ]
)

RAW_PREDICTED_FUEL_COLUMN = find_column(
    integrated,
    [
        "Raw_Predicted_Fuel_t",
        "Raw_Predicted_Fuel"
    ],
    required=False
)

ACTUAL_CO2_COLUMN = find_column(
    integrated,
    [
        "Actual_CO2_t",
        "CO2_Emissions_t",
        "CO2_Emissions_t_CII"
    ]
)

PREDICTED_CO2_COLUMN = find_column(
    integrated,
    [
        "Predicted_CO2_t",
        "Scenario_CO2_t",
        "Scenario_CO2"
    ]
)

BASELINE_CII_COLUMN = find_column(
    integrated,
    [
        "Attained_CII",
        "Baseline_CII"
    ]
)

SCENARIO_CII_COLUMN = find_column(
    integrated,
    [
        "Scenario_CII"
    ]
)

BASELINE_RATING_COLUMN = find_column(
    integrated,
    [
        "CII_Rating",
        "Baseline_CII_Rating"
    ]
)

SCENARIO_RATING_COLUMN = find_column(
    integrated,
    [
        "Scenario_CII_Rating"
    ]
)

CII_APPLICABLE_COLUMN = find_column(
    integrated,
    [
        "CII_Applicable_Final",
        "CII_Applicable",
        "CII_Applicable_ML"
    ],
    required=False
)


print("\nResolved columns:")

print(
    f"Ship Type           : {SHIP_TYPE_COLUMN}"
)

print(
    f"IMO                 : {IMO_COLUMN}"
)

print(
    f"Actual Fuel         : {ACTUAL_FUEL_COLUMN}"
)

print(
    f"Predicted Fuel      : {PREDICTED_FUEL_COLUMN}"
)

print(
    f"Raw Predicted Fuel  : {RAW_PREDICTED_FUEL_COLUMN}"
)

print(
    f"Actual CO2          : {ACTUAL_CO2_COLUMN}"
)

print(
    f"Predicted CO2       : {PREDICTED_CO2_COLUMN}"
)

print(
    f"Baseline CII        : {BASELINE_CII_COLUMN}"
)

print(
    f"Scenario CII        : {SCENARIO_CII_COLUMN}"
)

print(
    f"Baseline Rating     : {BASELINE_RATING_COLUMN}"
)

print(
    f"Scenario Rating     : {SCENARIO_RATING_COLUMN}"
)


# ============================================================
# STANDARDIZE INTERNAL COLUMN NAMES
# ============================================================

integrated["Ship_Type_Final"] = integrated[
    SHIP_TYPE_COLUMN
]

integrated["IMO_Final"] = integrated[
    IMO_COLUMN
]

integrated["Actual_Fuel_Final_t"] = pd.to_numeric(
    integrated[ACTUAL_FUEL_COLUMN],
    errors="coerce"
)

integrated["Predicted_Fuel_Final_t"] = pd.to_numeric(
    integrated[PREDICTED_FUEL_COLUMN],
    errors="coerce"
)

integrated["Actual_CO2_Final_t"] = pd.to_numeric(
    integrated[ACTUAL_CO2_COLUMN],
    errors="coerce"
)

integrated["Predicted_CO2_Final_t"] = pd.to_numeric(
    integrated[PREDICTED_CO2_COLUMN],
    errors="coerce"
)

integrated["Baseline_CII_Final"] = pd.to_numeric(
    integrated[BASELINE_CII_COLUMN],
    errors="coerce"
)

integrated["Scenario_CII_Final"] = pd.to_numeric(
    integrated[SCENARIO_CII_COLUMN],
    errors="coerce"
)

integrated["Baseline_Rating_Final"] = (
    integrated[BASELINE_RATING_COLUMN]
    .astype(str)
    .str.strip()
)

integrated["Scenario_Rating_Final"] = (
    integrated[SCENARIO_RATING_COLUMN]
    .astype(str)
    .str.strip()
)


# ============================================================
# [2/10] FINAL ML PREDICTION VALIDATION
# ============================================================

print(
    "\n[2/10] Validating final ML predictions..."
)


ml_valid = integrated[
    integrated["Actual_Fuel_Final_t"].notna()
    &
    integrated["Predicted_Fuel_Final_t"].notna()
].copy()


print(
    f"Valid ML predictions : {len(ml_valid):,}"
)


# ------------------------------------------------------------
# Actual and predicted values
# ------------------------------------------------------------

y_actual = ml_valid[
    "Actual_Fuel_Final_t"
].values

y_pred = ml_valid[
    "Predicted_Fuel_Final_t"
].values


# ------------------------------------------------------------
# Residual
#
# Residual = predicted - actual
# ------------------------------------------------------------

errors = (
    y_pred
    -
    y_actual
)


# ------------------------------------------------------------
# MAE
# ------------------------------------------------------------

mae = np.mean(
    np.abs(errors)
)


# ------------------------------------------------------------
# RMSE
# ------------------------------------------------------------

rmse = np.sqrt(
    np.mean(
        errors ** 2
    )
)


# ------------------------------------------------------------
# R²
# ------------------------------------------------------------

ss_res = np.sum(
    errors ** 2
)

ss_tot = np.sum(
    (
        y_actual
        -
        np.mean(y_actual)
    ) ** 2
)


if ss_tot != 0:

    r2 = 1 - (
        ss_res /
        ss_tot
    )

else:

    r2 = np.nan


# ------------------------------------------------------------
# MAPE
# ------------------------------------------------------------

mape_mask = (
    y_actual != 0
)


if mape_mask.sum() > 0:

    mape = np.mean(

        np.abs(

            (
                y_pred[mape_mask]
                -
                y_actual[mape_mask]
            )
            /
            y_actual[mape_mask]

        )

    ) * 100

else:

    mape = np.nan


print(
    "\nFinal dataset diagnostic metrics:"
)

print(
    f"R²        : {r2:.4f}"
)

print(
    f"MAE       : {mae:.2f} t"
)

print(
    f"RMSE      : {rmse:.2f} t"
)

print(
    f"MAPE      : {mape:.2f}%"
)


print(
    "\nIMPORTANT:"
)

print(
    "These are in-sample diagnostic metrics."
)

print(
    "They are NOT the primary generalization metrics."
)


# ============================================================
# STEP 9 CROSS-VALIDATION RESULTS
# ============================================================

print(
    "\nPrimary generalization performance from Step 9:"
)

print(
    "-" * 90
)

print(
    "Cross-validation R²   : 0.9480 ± 0.0169"
)

print(
    "Cross-validation MAE  : 469.03 ± 40.99 t"
)

print(
    "Cross-validation RMSE : 1010.86 ± 203.61 t"
)


# ============================================================
# [3/10] PREDICTION ERROR ANALYSIS
# ============================================================

print(
    "\n[3/10] Analyzing prediction errors..."
)


ml_valid["Residual_t"] = (

    ml_valid[
        "Predicted_Fuel_Final_t"
    ]

    -

    ml_valid[
        "Actual_Fuel_Final_t"
    ]

)


ml_valid["Absolute_Error_t"] = (

    np.abs(
        ml_valid[
            "Residual_t"
        ]
    )

)


ml_valid[
    "Absolute_Error_Percent"
] = (

    ml_valid[
        "Absolute_Error_t"
    ]

    /

    ml_valid[
        "Actual_Fuel_Final_t"
    ].replace(
        0,
        np.nan
    )

) * 100


# ------------------------------------------------------------
# Error statistics
# ------------------------------------------------------------

error_statistics = pd.DataFrame({

    "Metric": [

        "Mean Residual (t)",

        "Median Residual (t)",

        "Mean Absolute Error (t)",

        "Median Absolute Error (t)",

        "RMSE (t)",

        "Maximum Absolute Error (t)",

        "95th Percentile Absolute Error (t)"

    ],

    "Value": [

        ml_valid[
            "Residual_t"
        ].mean(),

        ml_valid[
            "Residual_t"
        ].median(),

        ml_valid[
            "Absolute_Error_t"
        ].mean(),

        ml_valid[
            "Absolute_Error_t"
        ].median(),

        np.sqrt(
            np.mean(
                ml_valid[
                    "Residual_t"
                ] ** 2
            )
        ),

        ml_valid[
            "Absolute_Error_t"
        ].max(),

        ml_valid[
            "Absolute_Error_t"
        ].quantile(
            0.95
        )

    ]

})


print(
    "\nPrediction error statistics:"
)

print(
    error_statistics.to_string(
        index=False
    )
)


# ------------------------------------------------------------
# Save error statistics
# ------------------------------------------------------------

error_statistics_file = os.path.join(

    REPORT_DIR,

    "step15_ml_error_statistics.csv"

)


error_statistics.to_csv(

    error_statistics_file,

    index=False

)


# ============================================================
# FIGURE 1 — ACTUAL VS PREDICTED FUEL
# ============================================================

print(
    "\nCreating actual vs predicted fuel plot..."
)


plt.figure(
    figsize=(8, 8)
)


plt.scatter(

    ml_valid[
        "Actual_Fuel_Final_t"
    ],

    ml_valid[
        "Predicted_Fuel_Final_t"
    ],

    alpha=0.35

)


min_value = min(

    ml_valid[
        "Actual_Fuel_Final_t"
    ].min(),

    ml_valid[
        "Predicted_Fuel_Final_t"
    ].min()

)


max_value = max(

    ml_valid[
        "Actual_Fuel_Final_t"
    ].max(),

    ml_valid[
        "Predicted_Fuel_Final_t"
    ].max()

)


plt.plot(

    [
        min_value,
        max_value
    ],

    [
        min_value,
        max_value
    ],

    linestyle="--"

)


plt.xlabel(
    "Actual Fuel Consumption (t)"
)

plt.ylabel(
    "Predicted Fuel Consumption (t)"
)

plt.title(
    "Final XGBoost: Actual vs Predicted Fuel Consumption"
)

plt.tight_layout()


actual_predicted_file = os.path.join(

    FIGURE_DIR,

    "step15_actual_vs_predicted_fuel.png"

)


plt.savefig(

    actual_predicted_file,

    dpi=300,

    bbox_inches="tight"

)

plt.close()


# ============================================================
# FIGURE 2 — RESIDUAL DISTRIBUTION
# ============================================================

print(
    "Creating residual distribution..."
)


plt.figure(
    figsize=(10, 6)
)


plt.hist(

    ml_valid[
        "Residual_t"
    ],

    bins=50

)


plt.axvline(

    0,

    linestyle="--"

)


plt.xlabel(
    "Prediction Residual (t)"
)

plt.ylabel(
    "Number of Vessels"
)

plt.title(
    "Final XGBoost Fuel Prediction Residual Distribution"
)

plt.tight_layout()


residual_file = os.path.join(

    FIGURE_DIR,

    "step15_fuel_prediction_residual_distribution.png"

)


plt.savefig(

    residual_file,

    dpi=300,

    bbox_inches="tight"

)

plt.close()


# ============================================================
# [4/10] ERROR BY SHIP TYPE
# ============================================================

print(
    "\n[4/10] Analyzing prediction error by ship type..."
)


# ------------------------------------------------------------
# IMPORTANT:
# Step 13 can contain:
#
# Ship_Type
# Ship_Type_ML
# Ship_Type_CII
# Ship_Type_x
# Ship_Type_y
#
# We already resolved the correct column above.
# ------------------------------------------------------------

ml_valid["Ship_Type_Final"] = (
    ml_valid[SHIP_TYPE_COLUMN]
)


ship_type_ml = (

    ml_valid

    .groupby(
        "Ship_Type_Final"
    )

    .agg(

        Vessels=(
            "IMO_Final",
            "count"
        ),

        Mean_Absolute_Error_t=(
            "Absolute_Error_t",
            "mean"
        ),

        Median_Absolute_Error_t=(
            "Absolute_Error_t",
            "median"
        ),

        Mean_Residual_t=(
            "Residual_t",
            "mean"
        ),

        Mean_Absolute_Error_Percent=(
            "Absolute_Error_Percent",
            "mean"
        )

    )

    .reset_index()

)


ship_type_ml = ship_type_ml.rename(

    columns={
        "Ship_Type_Final": "Ship_Type"
    }

)


ship_type_ml = (

    ship_type_ml

    .sort_values(

        "Mean_Absolute_Error_t",

        ascending=False

    )

)


print(
    "\nPrediction error by ship type:"
)

print(
    ship_type_ml.to_string(
        index=False
    )
)


# ------------------------------------------------------------
# Save report
# ------------------------------------------------------------

ship_type_error_file = os.path.join(

    REPORT_DIR,

    "step15_ml_error_by_ship_type.csv"

)


ship_type_ml.to_csv(

    ship_type_error_file,

    index=False

)


# ============================================================
# FIGURE 3 — ERROR BY SHIP TYPE
# ============================================================

plt.figure(

    figsize=(12, 8)

)


plot_error = (

    ship_type_ml

    .sort_values(

        "Mean_Absolute_Error_t",

        ascending=True

    )

)


plt.barh(

    plot_error[
        "Ship_Type"
    ],

    plot_error[
        "Mean_Absolute_Error_t"
    ]

)


plt.xlabel(
    "Mean Absolute Error (t)"
)

plt.ylabel(
    "Ship Type"
)

plt.title(
    "Fuel Prediction Error by Ship Type"
)

plt.tight_layout()


ship_type_error_fig = os.path.join(

    FIGURE_DIR,

    "step15_ml_error_by_ship_type.png"

)


plt.savefig(

    ship_type_error_fig,

    dpi=300,

    bbox_inches="tight"

)

plt.close()


# ============================================================
# [5/10] CII SCENARIO VALIDATION
# ============================================================

print(
    "\n[5/10] Validating ML scenario CII results..."
)


# ------------------------------------------------------------
# Valid A-E baseline and scenario ratings
# ------------------------------------------------------------

valid_ratings = [
    "A",
    "B",
    "C",
    "D",
    "E"
]


cii_valid = integrated[

    integrated[
        "Baseline_Rating_Final"
    ].isin(
        valid_ratings
    )

    &

    integrated[
        "Scenario_Rating_Final"
    ].isin(
        valid_ratings
    )

    &

    integrated[
        "Baseline_CII_Final"
    ].notna()

    &

    integrated[
        "Scenario_CII_Final"
    ].notna()

].copy()


print(
    f"Comparable A-E CII vessels : "
    f"{len(cii_valid):,}"
)


# ------------------------------------------------------------
# CII change
# ------------------------------------------------------------

cii_valid[
    "CII_Change_Percent"
] = (

    (

        cii_valid[
            "Scenario_CII_Final"
        ]

        -

        cii_valid[
            "Baseline_CII_Final"
        ]

    )

    /

    cii_valid[
        "Baseline_CII_Final"
    ].replace(
        0,
        np.nan
    )

) * 100


# ------------------------------------------------------------
# CII statistics
# ------------------------------------------------------------

cii_statistics = pd.DataFrame({

    "Metric": [

        "Mean observed CII",

        "Mean scenario CII",

        "Mean CII change (%)",

        "Median CII change (%)",

        "Minimum CII change (%)",

        "Maximum CII change (%)",

        "Improved vessels",

        "Unchanged vessels",

        "Worsened vessels"

    ],

    "Value": [

        cii_valid[
            "Baseline_CII_Final"
        ].mean(),

        cii_valid[
            "Scenario_CII_Final"
        ].mean(),

        cii_valid[
            "CII_Change_Percent"
        ].mean(),

        cii_valid[
            "CII_Change_Percent"
        ].median(),

        cii_valid[
            "CII_Change_Percent"
        ].min(),

        cii_valid[
            "CII_Change_Percent"
        ].max(),

        (
            cii_valid[
                "Scenario_CII_Final"
            ]

            <

            cii_valid[
                "Baseline_CII_Final"
            ]

        ).sum(),

        (
            cii_valid[
                "Scenario_CII_Final"
            ]

            ==

            cii_valid[
                "Baseline_CII_Final"
            ]

        ).sum(),

        (
            cii_valid[
                "Scenario_CII_Final"
            ]

            >

            cii_valid[
                "Baseline_CII_Final"
            ]

        ).sum()

    ]

})


print(
    "\nCII scenario statistics:"
)

print(
    cii_statistics.to_string(
        index=False
    )
)


# ============================================================
# SAVE CII STATISTICS
# ============================================================

cii_statistics_file = os.path.join(

    REPORT_DIR,

    "step15_cii_statistics.csv"

)


cii_statistics.to_csv(

    cii_statistics_file,

    index=False

)


# ============================================================
# FIGURE 4 — CII CHANGE DISTRIBUTION
# ============================================================

print(
    "\nCreating final CII change distribution..."
)


plt.figure(

    figsize=(10, 6)

)


plt.hist(

    cii_valid[
        "CII_Change_Percent"
    ],

    bins=50

)


plt.axvline(

    0,

    linestyle="--"

)


plt.xlabel(
    "CII Change (%)"
)

plt.ylabel(
    "Number of Vessels"
)

plt.title(
    "Final Distribution of ML Scenario CII Change"
)

plt.tight_layout()


cii_change_file = os.path.join(

    FIGURE_DIR,

    "step15_final_cii_change_distribution.png"

)


plt.savefig(

    cii_change_file,

    dpi=300,

    bbox_inches="tight"

)

plt.close()


# ============================================================
# [6/10] RATING TRANSITION ANALYSIS
# ============================================================

print(
    "\n[6/10] Analyzing CII rating transitions..."
)


# ------------------------------------------------------------
# Rating numerical order
#
# Lower numerical value = better rating
# ------------------------------------------------------------

rating_score = {

    "A": 1,

    "B": 2,

    "C": 3,

    "D": 4,

    "E": 5

}


cii_valid[
    "Baseline_Score"
] = cii_valid[
    "Baseline_Rating_Final"
].map(
    rating_score
)


cii_valid[
    "Scenario_Score"
] = cii_valid[
    "Scenario_Rating_Final"
].map(
    rating_score
)


# ------------------------------------------------------------
# Determine rating change
# ------------------------------------------------------------

cii_valid[
    "Rating_Change"
] = np.select(

    [

        cii_valid[
            "Scenario_Score"
        ]

        <

        cii_valid[
            "Baseline_Score"
        ],

        cii_valid[
            "Scenario_Score"
        ]

        ==

        cii_valid[
            "Baseline_Score"
        ],

        cii_valid[
            "Scenario_Score"
        ]

        >

        cii_valid[
            "Baseline_Score"
        ]

    ],

    [

        "Improved",

        "Unchanged",

        "Worsened"

    ],

    default="Unknown"

)


# ------------------------------------------------------------
# Count transitions
# ------------------------------------------------------------

improved = int(

    (

        cii_valid[
            "Rating_Change"
        ]

        ==

        "Improved"

    ).sum()

)


unchanged = int(

    (

        cii_valid[
            "Rating_Change"
        ]

        ==

        "Unchanged"

    ).sum()

)


worsened = int(

    (

        cii_valid[
            "Rating_Change"
        ]

        ==

        "Worsened"

    ).sum()

)


# ------------------------------------------------------------
# Transition summary
# ------------------------------------------------------------

transition_summary = (

    cii_valid[
        "Rating_Change"
    ]

    .value_counts()

    .reindex(

        [
            "Improved",
            "Unchanged",
            "Worsened"
        ],

        fill_value=0

    )

    .reset_index()

)


transition_summary.columns = [

    "Rating_Change",

    "Vessels"

]


transition_summary[
    "Percentage"
] = (

    transition_summary[
        "Vessels"
    ]

    /

    len(cii_valid)

) * 100


print(
    "\nRating transition summary:"
)

print(
    transition_summary.to_string(
        index=False
    )
)


# ============================================================
# SAVE TRANSITION SUMMARY
# ============================================================

transition_summary_file = os.path.join(

    REPORT_DIR,

    "step15_rating_change_summary.csv"

)


transition_summary.to_csv(

    transition_summary_file,

    index=False

)


# ============================================================
# FIGURE 5 — RATING CHANGE
# ============================================================

plt.figure(

    figsize=(8, 6)

)


plt.bar(

    transition_summary[
        "Rating_Change"
    ],

    transition_summary[
        "Vessels"
    ]

)


plt.xlabel(
    "Rating Change"
)

plt.ylabel(
    "Number of Vessels"
)

plt.title(
    "IMO CII Rating Changes Under ML Scenario"
)

plt.tight_layout()


rating_change_file = os.path.join(

    FIGURE_DIR,

    "step15_cii_rating_change_summary.png"

)


plt.savefig(

    rating_change_file,

    dpi=300,

    bbox_inches="tight"

)

plt.close()


# ============================================================
# [7/10] D/E ANALYSIS
# ============================================================

print(
    "\n[7/10] Final D/E analysis..."
)


baseline_de = int(

    cii_valid[
        "Baseline_Rating_Final"
    ]

    .isin(
        [
            "D",
            "E"
        ]
    )

    .sum()

)


scenario_de = int(

    cii_valid[
        "Scenario_Rating_Final"
    ]

    .isin(
        [
            "D",
            "E"
        ]
    )

    .sum()

)


baseline_de_pct = (

    baseline_de

    /

    len(cii_valid)

) * 100


scenario_de_pct = (

    scenario_de

    /

    len(cii_valid)

) * 100


de_results = pd.DataFrame({

    "Metric": [

        "Baseline D/E vessels",

        "Scenario D/E vessels",

        "D/E vessel change",

        "Baseline D/E percentage",

        "Scenario D/E percentage",

        "D/E percentage-point change"

    ],

    "Value": [

        baseline_de,

        scenario_de,

        scenario_de - baseline_de,

        baseline_de_pct,

        scenario_de_pct,

        scenario_de_pct - baseline_de_pct

    ]

})


print(
    "\nD/E results:"
)

print(
    de_results.to_string(
        index=False
    )
)


# ============================================================
# SAVE D/E RESULTS
# ============================================================

de_results_file = os.path.join(

    REPORT_DIR,

    "step15_de_results.csv"

)


de_results.to_csv(

    de_results_file,

    index=False

)


# ============================================================
# FIGURE 6 — D/E PERFORMANCE
# ============================================================

plt.figure(

    figsize=(8, 6)

)


plt.bar(

    [
        "Baseline",
        "ML Scenario"
    ],

    [
        baseline_de_pct,
        scenario_de_pct
    ]

)


plt.ylabel(
    "D/E Vessels (%)"
)

plt.title(
    "Final IMO CII D/E Performance"
)

plt.tight_layout()


de_final_file = os.path.join(

    FIGURE_DIR,

    "step15_final_de_performance.png"

)


plt.savefig(

    de_final_file,

    dpi=300,

    bbox_inches="tight"

)

plt.close()


# ============================================================
# [8/10] TOP IMPROVEMENTS AND WORSENINGS
# ============================================================

print(
    "\n[8/10] Identifying largest CII scenario changes..."
)


# ------------------------------------------------------------
# Largest CII increases
# ------------------------------------------------------------

worst = (

    cii_valid

    .sort_values(

        "CII_Change_Percent",

        ascending=False

    )

    .head(20)

    .copy()

)


# ------------------------------------------------------------
# Largest CII decreases
# ------------------------------------------------------------

best = (

    cii_valid

    .sort_values(

        "CII_Change_Percent",

        ascending=True

    )

    .head(20)

    .copy()

)


# ------------------------------------------------------------
# Standardize useful columns
# ------------------------------------------------------------

display_columns = [

    "IMO_Final",

    "Ship_Type_Final",

    "Baseline_CII_Final",

    "Scenario_CII_Final",

    "CII_Change_Percent",

    "Baseline_Rating_Final",

    "Scenario_Rating_Final"

]


display_columns = [

    col

    for col in display_columns

    if col in worst.columns

]


worst_output = worst[
    display_columns
].copy()


best_output = best[
    display_columns
].copy()


worst_output = worst_output.rename(

    columns={

        "IMO_Final": "IMO",

        "Ship_Type_Final": "Ship_Type",

        "Baseline_CII_Final": "Baseline_CII",

        "Scenario_CII_Final": "Scenario_CII",

        "Baseline_Rating_Final": "Baseline_Rating",

        "Scenario_Rating_Final": "Scenario_Rating"

    }

)


best_output = best_output.rename(

    columns={

        "IMO_Final": "IMO",

        "Ship_Type_Final": "Ship_Type",

        "Baseline_CII_Final": "Baseline_CII",

        "Scenario_CII_Final": "Scenario_CII",

        "Baseline_Rating_Final": "Baseline_Rating",

        "Scenario_Rating_Final": "Scenario_Rating"

    }

)


# ============================================================
# SAVE TOP 20
# ============================================================

worst_final_file = os.path.join(

    REPORT_DIR,

    "step15_final_top20_cii_worsenings.csv"

)


best_final_file = os.path.join(

    REPORT_DIR,

    "step15_final_top20_cii_improvements.csv"

)


worst_output.to_csv(

    worst_final_file,

    index=False

)


best_output.to_csv(

    best_final_file,

    index=False

)


print(
    "\nTop 20 CII increases saved."
)

print(
    "Top 20 CII decreases saved."
)


# ============================================================
# [9/10] FLEET-LEVEL SCENARIO ANALYSIS
# ============================================================

print(
    "\n[9/10] Calculating final fleet-level scenario results..."
)


actual_fuel_total = (

    integrated[
        "Actual_Fuel_Final_t"
    ]

    .sum()

)


scenario_fuel_total = (

    integrated[
        "Predicted_Fuel_Final_t"
    ]

    .sum()

)


actual_co2_total = (

    integrated[
        "Actual_CO2_Final_t"
    ]

    .sum()

)


scenario_co2_total = (

    integrated[
        "Predicted_CO2_Final_t"
    ]

    .sum()

)


# ------------------------------------------------------------
# Fleet fuel change
# ------------------------------------------------------------

if actual_fuel_total != 0:

    fleet_fuel_change = (

        (

            scenario_fuel_total
            -
            actual_fuel_total

        )

        /

        actual_fuel_total

    ) * 100

else:

    fleet_fuel_change = np.nan


# ------------------------------------------------------------
# Fleet CO2 change
# ------------------------------------------------------------

if actual_co2_total != 0:

    fleet_co2_change = (

        (

            scenario_co2_total
            -
            actual_co2_total

        )

        /

        actual_co2_total

    ) * 100

else:

    fleet_co2_change = np.nan


print(
    "\nFleet-level results:"
)

print(
    f"Actual fuel       : "
    f"{actual_fuel_total:,.2f} t"
)

print(
    f"Scenario fuel     : "
    f"{scenario_fuel_total:,.2f} t"
)

print(
    f"Fuel change       : "
    f"{fleet_fuel_change:+.4f}%"
)

print(
    f"Actual CO2        : "
    f"{actual_co2_total:,.2f} t"
)

print(
    f"Scenario CO2      : "
    f"{scenario_co2_total:,.2f} t"
)

print(
    f"CO2 change        : "
    f"{fleet_co2_change:+.4f}%"
)


# ============================================================
# FIGURE 7 — FLEET FUEL
# ============================================================

plt.figure(

    figsize=(8, 6)

)


plt.bar(

    [
        "Actual",
        "ML Scenario"
    ],

    [
        actual_fuel_total,
        scenario_fuel_total
    ]

)


plt.ylabel(
    "Fleet Fuel Consumption (t)"
)

plt.title(
    "Fleet Fuel Consumption: Actual vs ML Scenario"
)

plt.tight_layout()


fleet_fuel_file = os.path.join(

    FIGURE_DIR,

    "step15_fleet_fuel_actual_vs_scenario.png"

)


plt.savefig(

    fleet_fuel_file,

    dpi=300,

    bbox_inches="tight"

)

plt.close()


# ============================================================
# FIGURE 8 — FLEET CO2
# ============================================================

plt.figure(

    figsize=(8, 6)

)


plt.bar(

    [
        "Actual",
        "ML Scenario"
    ],

    [
        actual_co2_total,
        scenario_co2_total
    ]

)


plt.ylabel(
    "Fleet CO₂ Emissions (t)"
)

plt.title(
    "Fleet CO₂ Emissions: Actual vs ML Scenario"
)

plt.tight_layout()


fleet_co2_file = os.path.join(

    FIGURE_DIR,

    "step15_fleet_co2_actual_vs_scenario.png"

)


plt.savefig(

    fleet_co2_file,

    dpi=300,

    bbox_inches="tight"

)

plt.close()


# ============================================================
# [10/10] FINAL RESEARCH ASSESSMENT
# ============================================================

print(
    "\n[10/10] Preparing final research assessment..."
)


# ------------------------------------------------------------
# Mean CII change
# ------------------------------------------------------------

mean_cii_change = (

    cii_valid[
        "CII_Change_Percent"
    ]

    .mean()

)


median_cii_change = (

    cii_valid[
        "CII_Change_Percent"
    ]

    .median()

)


# ------------------------------------------------------------
# CII direction
# ------------------------------------------------------------

if mean_cii_change > 0:

    cii_direction = (
        "Scenario CII increased on average."
    )

elif mean_cii_change < 0:

    cii_direction = (
        "Scenario CII decreased on average."
    )

else:

    cii_direction = (
        "Scenario CII was unchanged on average."
    )


# ============================================================
# FINAL RESEARCH METRICS TABLE
# ============================================================

final_metrics = pd.DataFrame({

    "Metric": [

        "Dataset vessels",

        "CII applicable vessels",

        "Comparable A-E vessels",

        "Cross-validation R2",

        "Cross-validation R2 SD",

        "Cross-validation MAE (t)",

        "Cross-validation MAE SD (t)",

        "Cross-validation RMSE (t)",

        "Cross-validation RMSE SD (t)",

        "Improved CII ratings",

        "Unchanged CII ratings",

        "Worsened CII ratings",

        "Baseline D/E vessels",

        "Scenario D/E vessels",

        "D/E vessel change",

        "Baseline D/E percentage",

        "Scenario D/E percentage",

        "D/E percentage-point change",

        "Mean baseline CII",

        "Mean scenario CII",

        "Mean CII change (%)",

        "Median CII change (%)",

        "Actual fleet fuel (t)",

        "Scenario fleet fuel (t)",

        "Fleet fuel change (%)",

        "Actual fleet CO2 (t)",

        "Scenario fleet CO2 (t)",

        "Fleet CO2 change (%)"

    ],

    "Value": [

        len(integrated),

        (
            int(
                integrated[
                    CII_APPLICABLE_COLUMN
                ].sum()
            )

            if CII_APPLICABLE_COLUMN
            is not None

            else np.nan
        ),

        len(cii_valid),

        0.9480,

        0.0169,

        469.03,

        40.99,

        1010.86,

        203.61,

        improved,

        unchanged,

        worsened,

        baseline_de,

        scenario_de,

        scenario_de - baseline_de,

        baseline_de_pct,

        scenario_de_pct,

        scenario_de_pct - baseline_de_pct,

        cii_valid[
            "Baseline_CII_Final"
        ].mean(),

        cii_valid[
            "Scenario_CII_Final"
        ].mean(),

        mean_cii_change,

        median_cii_change,

        actual_fuel_total,

        scenario_fuel_total,

        fleet_fuel_change,

        actual_co2_total,

        scenario_co2_total,

        fleet_co2_change

    ]

})


# ============================================================
# SAVE FINAL RESEARCH METRICS
# ============================================================

final_metrics_file = os.path.join(

    REPORT_DIR,

    "step15_final_research_metrics.csv"

)


final_metrics.to_csv(

    final_metrics_file,

    index=False

)


# ============================================================
# FINAL ASSESSMENT TEXT
# ============================================================

assessment_lines = [

    "CARBON CII — FINAL RESEARCH ASSESSMENT",

    "=" * 70,

    "",

    "1. DATASET",

    f"The final integrated dataset contains "
    f"{len(integrated):,} vessel-year observations.",

    f"{len(cii_valid):,} vessels have comparable "
    f"baseline and ML-scenario A-E CII ratings.",

    "",

    "2. MACHINE LEARNING PERFORMANCE",

    "The final operational XGBoost model achieved:",

    "Cross-validation R² = 0.9480 ± 0.0169",

    "Cross-validation MAE = 469.03 ± 40.99 tonnes",

    "Cross-validation RMSE = 1010.86 ± 203.61 tonnes",

    "",

    "These cross-validation results are the primary evidence "
    "used to assess model generalization.",

    "",

    "3. MODEL INTERPRETATION",

    "The ML model predicts vessel fuel consumption.",

    "The resulting scenario CO2 is derived from the predicted "
    "fuel consumption.",

    "IMO CII is then calculated deterministically using the "
    "applicable CII methodology and rating boundaries.",

    "",

    "4. FLEET SCENARIO",

    f"Actual fleet fuel = "
    f"{actual_fuel_total:,.2f} tonnes.",

    f"ML scenario fleet fuel = "
    f"{scenario_fuel_total:,.2f} tonnes.",

    f"Fleet fuel change = "
    f"{fleet_fuel_change:+.4f}%.",

    "",

    f"Actual fleet CO2 = "
    f"{actual_co2_total:,.2f} tonnes.",

    f"ML scenario fleet CO2 = "
    f"{scenario_co2_total:,.2f} tonnes.",

    f"Fleet CO2 change = "
    f"{fleet_co2_change:+.4f}%.",

    "",

    "5. CII SCENARIO",

    f"Mean CII change = "
    f"{mean_cii_change:+.4f}%.",

    f"Median CII change = "
    f"{median_cii_change:+.4f}%.",

    cii_direction,

    "",

    "6. RATING TRANSITIONS",

    f"{improved:,} vessels improved their CII rating.",

    f"{unchanged:,} vessels retained the same rating.",

    f"{worsened:,} vessels worsened their CII rating.",

    "",

    "7. D/E PERFORMANCE",

    f"Baseline D/E share = "
    f"{baseline_de_pct:.2f}%.",

    f"Scenario D/E share = "
    f"{scenario_de_pct:.2f}%.",

    f"D/E change = "
    f"{scenario_de_pct - baseline_de_pct:+.2f} "
    f"percentage points.",

    "",

    "8. RESEARCH INTERPRETATION",

    "The results demonstrate an integrated workflow in which "
    "machine learning estimates fuel consumption while the "
    "IMO CII framework is applied deterministically to evaluate "
    "carbon-intensity performance.",

    "The scenario results should be interpreted as model-based "
    "scenario estimates rather than observations of a future fleet.",

    "",

    "9. LIMITATIONS",

    "The modeling dataset is a matched subset of the available "
    "MRV records because vessel characteristics were obtained "
    "through exact IMO-number matching.",

    "The scenario depends on the predictive model and therefore "
    "inherits its uncertainty.",

    "Low-activity vessels require separate interpretation.",

    "Very small ship-type groups should not be overinterpreted.",

    "The physical lower-bound adjustment applied to negative "
    "fuel predictions is a pragmatic modeling constraint and "
    "is not an IMO regulatory requirement.",

    "",

    "10. FINAL CONCLUSION",

    "The Carbon CII project successfully integrates vessel "
    "characteristics, operational MRV data, machine-learning "
    "fuel prediction and deterministic IMO CII calculations.",

    "The final operational XGBoost model demonstrates strong "
    "cross-validated predictive performance.",

    "The integrated scenario framework can therefore be used "
    "to investigate how modeled changes in vessel fuel "
    "consumption may influence CII performance and A-E ratings.",

    "",

    "END OF STEP 15"

]


assessment_file = os.path.join(

    REPORT_DIR,

    "step15_final_research_assessment.txt"

)


with open(

    assessment_file,

    "w",

    encoding="utf-8"

) as f:

    f.write(
        "\n".join(
            assessment_lines
        )
    )


# ============================================================
# SAVE FINAL INTEGRATED VALIDATION DATA
# ============================================================

final_validation_file = os.path.join(

    REPORT_DIR,

    "step15_final_validation_dataset.csv"

)


# Save only useful validation fields

validation_columns = [

    "IMO_Final",

    "Ship_Type_Final",

    "Actual_Fuel_Final_t",

    "Predicted_Fuel_Final_t",

    "Actual_CO2_Final_t",

    "Predicted_CO2_Final_t",

    "Baseline_CII_Final",

    "Scenario_CII_Final",

    "CII_Change_Percent",

    "Baseline_Rating_Final",

    "Scenario_Rating_Final",

    "Rating_Change"

]


validation_columns = [

    col

    for col in validation_columns

    if col in cii_valid.columns

]


cii_valid[
    validation_columns
].to_csv(

    final_validation_file,

    index=False

)


# ============================================================
# FINAL TERMINAL OUTPUT
# ============================================================

print("\n")
print("=" * 90)
print("STEP 15 — FINAL RESULTS")
print("=" * 90)


print(
    "\nMODEL GENERALIZATION"
)

print(
    "-" * 90
)

print(
    "Cross-validation R²   : "
    "0.9480 ± 0.0169"
)

print(
    "Cross-validation MAE  : "
    "469.03 ± 40.99 t"
)

print(
    "Cross-validation RMSE : "
    "1010.86 ± 203.61 t"
)


print(
    "\nCII SCENARIO"
)

print(
    "-" * 90
)

print(
    f"Comparable A-E vessels : "
    f"{len(cii_valid):,}"
)

print(
    f"Mean CII change        : "
    f"{mean_cii_change:+.4f}%"
)

print(
    f"Median CII change      : "
    f"{median_cii_change:+.4f}%"
)


print(
    "\nRATING TRANSITIONS"
)

print(
    "-" * 90
)

print(
    f"Improved               : "
    f"{improved:,}"
)

print(
    f"Unchanged              : "
    f"{unchanged:,}"
)

print(
    f"Worsened               : "
    f"{worsened:,}"
)


print(
    "\nD/E PERFORMANCE"
)

print(
    "-" * 90
)

print(
    f"Baseline D/E           : "
    f"{baseline_de:,} "
    f"({baseline_de_pct:.2f}%)"
)

print(
    f"Scenario D/E           : "
    f"{scenario_de:,} "
    f"({scenario_de_pct:.2f}%)"
)

print(
    f"D/E vessel change      : "
    f"{scenario_de - baseline_de:+,}"
)

print(
    f"D/E percentage-point   : "
    f"{scenario_de_pct - baseline_de_pct:+.2f}"
)


print(
    "\nFLEET SCENARIO"
)

print(
    "-" * 90
)

print(
    f"Actual fleet fuel      : "
    f"{actual_fuel_total:,.2f} t"
)

print(
    f"Scenario fleet fuel    : "
    f"{scenario_fuel_total:,.2f} t"
)

print(
    f"Fuel change            : "
    f"{fleet_fuel_change:+.4f}%"
)

print(
    f"Actual fleet CO2       : "
    f"{actual_co2_total:,.2f} t"
)

print(
    f"Scenario fleet CO2     : "
    f"{scenario_co2_total:,.2f} t"
)

print(
    f"CO2 change             : "
    f"{fleet_co2_change:+.4f}%"
)


print(
    "\nGENERATED REPORTS"
)

print(
    "-" * 90
)

print(
    final_metrics_file
)

print(
    error_statistics_file
)

print(
    cii_statistics_file
)

print(
    ship_type_error_file
)

print(
    transition_summary_file
)

print(
    de_results_file
)

print(
    worst_final_file
)

print(
    best_final_file
)

print(
    final_validation_file
)

print(
    assessment_file
)


print(
    "\nGENERATED FIGURES"
)

print(
    "-" * 90
)

print(
    actual_predicted_file
)

print(
    residual_file
)

print(
    ship_type_error_fig
)

print(
    cii_change_file
)

print(
    rating_change_file
)

print(
    de_final_file
)

print(
    fleet_fuel_file
)

print(
    fleet_co2_file
)


print("\n")
print("=" * 90)
print("STEP 15 COMPLETED SUCCESSFULLY")
print("=" * 90)