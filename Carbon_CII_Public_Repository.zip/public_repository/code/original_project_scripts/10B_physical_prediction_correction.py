# ================================================================
# STEP 10B — PHYSICAL CONSTRAINT FOR FUEL PREDICTIONS
# Carbon CII Project
# ================================================================

import os
import warnings
import joblib
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")


# ================================================================
# 1. PROJECT PATHS
# ================================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

DATA_FILE = os.path.join(
    BASE_DIR,
    "data",
    "processed",
    "MRV_2023_feature_engineered.csv"
)

MODEL_FILE = os.path.join(
    BASE_DIR,
    "outputs",
    "models",
    "final_operational_xgboost_tuned.joblib"
)

REPORT_DIR = os.path.join(
    BASE_DIR,
    "outputs",
    "reports"
)

os.makedirs(
    REPORT_DIR,
    exist_ok=True
)


# ================================================================
# 2. OUTPUT FILE
# ================================================================

OUTPUT_FILE = os.path.join(
    REPORT_DIR,
    "ml_final_predictions_2023_physical.csv"
)


# ================================================================
# 3. LOAD DATA
# ================================================================

print("=" * 75)
print("STEP 10B — PHYSICAL FUEL PREDICTION CORRECTION")
print("=" * 75)

print("\n[1/7] Loading dataset...")

df = pd.read_csv(
    DATA_FILE
)

print(
    f"Dataset shape: {df.shape}"
)


# ================================================================
# 4. FEATURES
# ================================================================

print("\n[2/7] Preparing ML features...")

FEATURES = [

    "Ship_Type",

    "GT",
    "DWT",

    "Length_m",
    "Beam_m",
    "Draft_m",

    "Vessel_Age",

    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",

    "Length_Beam_Ratio",
    "DWT_GT_ratio",
    "Sea_Time_Utilization"
]

TARGET = "Fuel_Consumption_t"


X = df[
    FEATURES
].copy()

y = pd.to_numeric(
    df[TARGET],
    errors="coerce"
)


# ================================================================
# 5. LOAD AND FIT MODEL
# ================================================================

print("\n[3/7] Loading tuned XGBoost model...")

model = joblib.load(
    MODEL_FILE
)

valid = y.notna()

model.fit(
    X.loc[valid],
    y.loc[valid]
)

print(
    "Model fitted successfully."
)


# ================================================================
# 6. GENERATE RAW PREDICTIONS
# ================================================================

print("\n[4/7] Generating raw ML predictions...")

raw_predictions = model.predict(
    X
)

raw_predictions = np.asarray(
    raw_predictions,
    dtype=float
)


df["Actual_Fuel_t"] = y

df["Raw_Predicted_Fuel_t"] = (
    raw_predictions
)


# ================================================================
# 7. DETERMINE PHYSICAL LOWER BOUND
# ================================================================

print("\n[5/7] Applying physical fuel constraint...")


# Minimum observed positive fuel consumption

positive_fuel = y[
    y > 0
]

minimum_observed_fuel = (
    positive_fuel.min()
)


print(
    f"Minimum observed positive fuel: "
    f"{minimum_observed_fuel:.2f} t"
)


# Identify physically impossible predictions

negative_mask = (
    df["Raw_Predicted_Fuel_t"] < 0
)


negative_count = (
    negative_mask.sum()
)


print(
    f"Negative raw predictions: "
    f"{negative_count}"
)


# ------------------------------------------------
# Physical correction
# ------------------------------------------------
#
# We do NOT use actual fuel.
#
# We only enforce a physically meaningful
# positive lower bound.

df["Predicted_Fuel_t"] = np.maximum(
    df["Raw_Predicted_Fuel_t"],
    minimum_observed_fuel
)


# ================================================================
# 8. RECORD ADJUSTMENT
# ================================================================

df["Fuel_Physical_Adjustment_t"] = (

    df["Predicted_Fuel_t"]

    -

    df["Raw_Predicted_Fuel_t"]
)


df["Fuel_Prediction_Adjusted"] = (
    negative_mask
)


# ================================================================
# 9. CALCULATE FUEL ERRORS
# ================================================================

print("\n[6/7] Calculating fuel prediction errors...")


df["Fuel_Error_t"] = (

    df["Predicted_Fuel_t"]

    -

    df["Actual_Fuel_t"]
)


df["Fuel_Absolute_Error_t"] = (

    df["Fuel_Error_t"]
    .abs()
)


df["Fuel_Error_Percent"] = np.where(

    df["Actual_Fuel_t"] != 0,

    (
        df["Fuel_Error_t"]
        /
        df["Actual_Fuel_t"]
    ) * 100,

    np.nan
)


# ================================================================
# 10. CO2 SCENARIO
# ================================================================

print(
    "\nCalculating CO₂ scenario..."
)


df["Actual_CO2_t"] = pd.to_numeric(
    df["CO2_Emissions_t"],
    errors="coerce"
)


# Vessel-specific observed CO2/fuel ratio

df["CO2_per_Fuel_Ratio"] = np.where(

    df["Actual_Fuel_t"] > 0,

    (
        df["Actual_CO2_t"]
        /
        df["Actual_Fuel_t"]
    ),

    np.nan
)


# Scenario CO2

df["Predicted_CO2_t"] = (

    df["Predicted_Fuel_t"]

    *

    df["CO2_per_Fuel_Ratio"]
)


# CO2 errors

df["CO2_Error_t"] = (

    df["Predicted_CO2_t"]

    -

    df["Actual_CO2_t"]
)


df["CO2_Absolute_Error_t"] = (

    df["CO2_Error_t"]
    .abs()
)


df["CO2_Error_Percent"] = np.where(

    df["Actual_CO2_t"] != 0,

    (
        df["CO2_Error_t"]
        /
        df["Actual_CO2_t"]
    ) * 100,

    np.nan
)


# ================================================================
# 11. SAVE
# ================================================================

print("\n[7/7] Saving physically constrained predictions...")


OUTPUT_COLUMNS = [

    "IMO",
    "Ship_Name",
    "Ship_Type",

    "Reporting_Year",
    "Build_Year",
    "Vessel_Age",

    "GT",
    "DWT",
    "Draft_m",
    "Length_m",
    "Beam_m",

    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",

    "Actual_Fuel_t",

    "Raw_Predicted_Fuel_t",
    "Predicted_Fuel_t",

    "Fuel_Physical_Adjustment_t",
    "Fuel_Prediction_Adjusted",

    "Fuel_Error_t",
    "Fuel_Absolute_Error_t",
    "Fuel_Error_Percent",

    "Actual_CO2_t",
    "Predicted_CO2_t",

    "CO2_Error_t",
    "CO2_Absolute_Error_t",
    "CO2_Error_Percent"
]


final_df = df[
    OUTPUT_COLUMNS
].copy()


final_df.to_csv(
    OUTPUT_FILE,
    index=False
)


# ================================================================
# 12. SUMMARY
# ================================================================

print("\n")
print("=" * 75)
print("PHYSICAL CONSTRAINT SUMMARY")
print("=" * 75)


print(
    f"\nMinimum actual fuel       : "
    f"{y.min():.2f} t"
)

print(
    f"Minimum raw prediction    : "
    f"{raw_predictions.min():.2f} t"
)

print(
    f"Minimum final prediction  : "
    f"{df['Predicted_Fuel_t'].min():.2f} t"
)

print(
    f"Negative predictions      : "
    f"{negative_count}"
)

print(
    f"Adjusted predictions      : "
    f"{df['Fuel_Prediction_Adjusted'].sum()}"
)


# ================================================================
# 13. SHOW ADJUSTED VESSELS
# ================================================================

if negative_count > 0:

    print("\nAdjusted vessels:")

    adjusted = df.loc[
        negative_mask,
        [
            "IMO",
            "Ship_Name",
            "Ship_Type",
            "Actual_Fuel_t",
            "Raw_Predicted_Fuel_t",
            "Predicted_Fuel_t",
            "Fuel_Physical_Adjustment_t"
        ]
    ]

    print(
        adjusted.to_string(
            index=False
        )
    )


# ================================================================
# 14. FINAL
# ================================================================

print("\n")
print("=" * 75)
print("STEP 10B COMPLETED")
print("=" * 75)

print(
    "\nOutput file:"
)

print(
    OUTPUT_FILE
)

print("\n" + "=" * 75)