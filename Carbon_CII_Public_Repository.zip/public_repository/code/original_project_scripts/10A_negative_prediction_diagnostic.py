# ================================================================
# STEP 10A — NEGATIVE FUEL PREDICTION DIAGNOSTIC
# Carbon CII Project
# ================================================================

import os
import warnings
import joblib
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")


# ================================================================
# 1. PROJECT PATHS
# ================================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

DATA_FILE = os.path.join(
    BASE_DIR,
    "data",
    "processed",
    "MRV_2023_feature_engineered.csv"
)

MODEL_FILE = os.path.join(
    BASE_DIR,
    "outputs",
    "models",
    "final_operational_xgboost_tuned.joblib"
)

REPORT_DIR = os.path.join(
    BASE_DIR,
    "outputs",
    "reports"
)

os.makedirs(
    REPORT_DIR,
    exist_ok=True
)


# ================================================================
# 2. LOAD DATA
# ================================================================

print("=" * 75)
print("STEP 10A — NEGATIVE FUEL PREDICTION DIAGNOSTIC")
print("=" * 75)

print("\n[1/8] Loading dataset...")

df = pd.read_csv(
    DATA_FILE
)

print(
    f"Dataset shape: {df.shape}"
)


# ================================================================
# 3. FEATURES
# ================================================================

print("\n[2/8] Preparing operational features...")

FEATURES = [

    "Ship_Type",

    "GT",
    "DWT",

    "Length_m",
    "Beam_m",
    "Draft_m",

    "Vessel_Age",

    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",

    "Length_Beam_Ratio",
    "DWT_GT_ratio",
    "Sea_Time_Utilization"
]

TARGET = "Fuel_Consumption_t"


X = df[
    FEATURES
].copy()

y = pd.to_numeric(
    df[TARGET],
    errors="coerce"
)


# ================================================================
# 4. LOAD MODEL
# ================================================================

print("\n[3/8] Loading tuned model...")

model = joblib.load(
    MODEL_FILE
)

print(
    "Model loaded successfully."
)


# ================================================================
# 5. FIT MODEL
# ================================================================

print("\n[4/8] Fitting model on complete dataset...")

valid = y.notna()

model.fit(
    X.loc[valid],
    y.loc[valid]
)

print(
    "Model fitted successfully."
)


# ================================================================
# 6. GENERATE RAW PREDICTIONS
# ================================================================

print("\n[5/8] Generating raw predictions...")

predictions = model.predict(
    X
)

predictions = np.asarray(
    predictions,
    dtype=float
)

df["Diagnostic_Predicted_Fuel_t"] = predictions


negative_mask = (
    df["Diagnostic_Predicted_Fuel_t"] < 0
)

negative_df = df.loc[
    negative_mask
].copy()


print(
    f"\nNegative predictions: "
    f"{len(negative_df)}"
)


# ================================================================
# 7. TRAINING TARGET DISTRIBUTION
# ================================================================

print("\n[6/8] Examining target distribution...")

print("\nFuel consumption statistics:")

print(
    y.describe()
)


print("\nLowest 20 actual fuel values:")

lowest_fuel = (
    df[
        [
            "IMO",
            "Ship_Name",
            "Ship_Type",
            "Fuel_Consumption_t"
        ]
    ]
    .sort_values(
        "Fuel_Consumption_t"
    )
    .head(20)
)

print(
    lowest_fuel.to_string(
        index=False
    )
)


# ================================================================
# 8. NEGATIVE PREDICTION DETAILS
# ================================================================

print("\n[7/8] Examining negative predictions...")

diagnostic_columns = [

    "IMO",
    "Ship_Name",
    "Ship_Type",

    "GT",
    "DWT",

    "Length_m",
    "Beam_m",
    "Draft_m",

    "Vessel_Age",

    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",

    "Length_Beam_Ratio",
    "DWT_GT_ratio",
    "Sea_Time_Utilization",

    "Fuel_Consumption_t",
    "Diagnostic_Predicted_Fuel_t"
]


print("\nNegative-prediction vessels:")

print(
    negative_df[
        diagnostic_columns
    ].to_string(
        index=False
    )
)


# ================================================================
# 9. SAVE DIAGNOSTIC
# ================================================================

diagnostic_file = os.path.join(
    REPORT_DIR,
    "step10A_negative_prediction_diagnostic.csv"
)

negative_df[
    diagnostic_columns
].to_csv(
    diagnostic_file,
    index=False
)


print(
    f"\nDiagnostic file saved:\n"
    f"{diagnostic_file}"
)


# ================================================================
# 10. MODEL STRUCTURE
# ================================================================

print("\n[8/8] Inspecting model structure...")

print("\nLoaded model type:")

print(
    type(model)
)


if hasattr(model, "named_steps"):

    print("\nPipeline steps:")

    for name, step in model.named_steps.items():

        print(
            f"  {name}: "
            f"{type(step)}"
        )


# ================================================================
# 11. ESTIMATOR PARAMETERS
# ================================================================

print("\nModel parameters:")

try:

    params = model.get_params()

    important_params = {

        key: value

        for key, value in params.items()

        if any(
            term in key.lower()
            for term in [
                "n_estimators",
                "max_depth",
                "learning_rate",
                "min_child_weight",
                "subsample",
                "colsample",
                "gamma",
                "objective"
            ]
        )
    }

    for key, value in important_params.items():

        print(
            f"  {key}: {value}"
        )

except Exception as e:

    print(
        f"Could not extract parameters: {e}"
    )


# ================================================================
# 12. SUMMARY
# ================================================================

print("\n")
print("=" * 75)
print("STEP 10A DIAGNOSTIC COMPLETED")
print("=" * 75)

print(
    f"\nTotal vessels       : {len(df):,}"
)

print(
    f"Negative predictions: {len(negative_df):,}"
)

print(
    f"Minimum prediction : "
    f"{predictions.min():,.6f} t"
)

print(
    f"Maximum prediction : "
    f"{predictions.max():,.2f} t"
)

print(
    f"Minimum actual fuel: "
    f"{y.min():,.4f} t"
)

print(
    "\nDiagnostic report:"
)

print(
    diagnostic_file
)

print("\n" + "=" * 75)