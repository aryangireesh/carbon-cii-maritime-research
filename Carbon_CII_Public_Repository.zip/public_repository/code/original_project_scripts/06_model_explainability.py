import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import shap
import joblib
import os

from sklearn.model_selection import train_test_split


# ============================================================
# CARBON CII PROJECT
# STEP 6 — MODEL EXPLAINABILITY
# ============================================================


# ============================================================
# 1. PATHS
# ============================================================

INPUT_PATH = "data/processed/MRV_2023_feature_engineered.csv"

MODEL_PATH = "outputs/models/operational_xgboost.joblib"

FIGURE_DIR = "outputs/figures"

os.makedirs(
    FIGURE_DIR,
    exist_ok=True
)


# ============================================================
# 2. LOAD DATA
# ============================================================

print("=" * 80)
print("CARBON CII PROJECT - MODEL EXPLAINABILITY")
print("=" * 80)

df = pd.read_csv(INPUT_PATH)

print("\nDataset shape:")
print(df.shape)


# ============================================================
# 3. FEATURES
# ============================================================

features = [

    "Ship_Type",

    "GT",
    "DWT",

    "Length_m",
    "Beam_m",
    "Draft_m",

    "Vessel_Age",

    "Distance_nm",
    "Time_At_Sea_h",
    "Average_Speed_kn",

    "Length_Beam_Ratio",
    "DWT_GT_ratio",
    "Sea_Time_Utilization"
]


TARGET = "Fuel_Consumption_t"


# ============================================================
# 4. PREPARE X AND y
# ============================================================

X = df[features].copy()

y = df[TARGET].copy()


# Use the same random state as model training
X_train, X_test, y_train, y_test = train_test_split(

    X,

    y,

    test_size=0.20,

    random_state=42

)


print("\nTraining samples:", len(X_train))

print("Testing samples:", len(X_test))


# ============================================================
# 5. LOAD TRAINED MODEL
# ============================================================

print("\nLoading trained XGBoost model...")

pipeline = joblib.load(
    MODEL_PATH
)

print("Model loaded successfully.")


# ============================================================
# 6. EXTRACT PREPROCESSOR
# ============================================================

preprocessor = pipeline.named_steps[
    "preprocessor"
]


model = pipeline.named_steps[
    "model"
]


# ============================================================
# 7. TRANSFORM TEST DATA
# ============================================================

print("\nTransforming test data...")

X_test_transformed = preprocessor.transform(
    X_test
)


# ============================================================
# 8. GET FEATURE NAMES
# ============================================================

feature_names = (
    preprocessor
    .get_feature_names_out()
)


print("\nNumber of transformed features:")

print(
    len(feature_names)
)


# ============================================================
# 9. CONVERT TO DENSE ARRAY
# ============================================================

if hasattr(
    X_test_transformed,
    "toarray"
):

    X_test_transformed = (
        X_test_transformed.toarray()
    )


# ============================================================
# 10. SHAP EXPLAINER
# ============================================================

print("\nCreating SHAP explainer...")

explainer = shap.TreeExplainer(
    model
)


# ============================================================
# 11. CALCULATE SHAP VALUES
# ============================================================

print("\nCalculating SHAP values...")

shap_values = explainer.shap_values(
    X_test_transformed
)


print("SHAP calculation completed.")


# ============================================================
# 12. GLOBAL FEATURE IMPORTANCE
# ============================================================

mean_abs_shap = np.abs(
    shap_values
).mean(axis=0)


importance = pd.DataFrame({

    "Feature": feature_names,

    "Mean_Absolute_SHAP": mean_abs_shap

})


importance = importance.sort_values(

    "Mean_Absolute_SHAP",

    ascending=False

)


print("\n" + "=" * 80)

print("SHAP FEATURE IMPORTANCE")

print("=" * 80)

print(

    importance.head(20).to_string(
        index=False
    )

)


# ============================================================
# 13. SAVE FEATURE IMPORTANCE
# ============================================================

importance_path = (
    "outputs/reports/"
    "operational_xgboost_shap_importance.csv"
)

os.makedirs(
    "outputs/reports",
    exist_ok=True
)

importance.to_csv(
    importance_path,
    index=False
)


# ============================================================
# 14. SHAP SUMMARY PLOT
# ============================================================

print("\nGenerating SHAP summary plot...")

plt.figure(
    figsize=(12, 8)
)

shap.summary_plot(

    shap_values,

    X_test_transformed,

    feature_names=feature_names,

    show=False

)

plt.title(
    "SHAP Summary - Operational XGBoost"
)

plt.tight_layout()

summary_path = (
    f"{FIGURE_DIR}/"
    "operational_xgboost_shap_summary.png"
)

plt.savefig(
    summary_path,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# 15. SHAP BAR PLOT
# ============================================================

print("Generating SHAP bar plot...")

plt.figure(
    figsize=(12, 8)
)

shap.summary_plot(

    shap_values,

    X_test_transformed,

    feature_names=feature_names,

    plot_type="bar",

    show=False

)

plt.title(
    "Global SHAP Feature Importance"
)

plt.tight_layout()

bar_path = (
    f"{FIGURE_DIR}/"
    "operational_xgboost_shap_bar.png"
)

plt.savefig(
    bar_path,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# 16. ACTUAL VS PREDICTED
# ============================================================

predictions = pipeline.predict(
    X_test
)


plt.figure(
    figsize=(8, 8)
)

plt.scatter(

    y_test,

    predictions,

    alpha=0.5

)


minimum = min(
    y_test.min(),
    predictions.min()
)

maximum = max(
    y_test.max(),
    predictions.max()
)


plt.plot(

    [minimum, maximum],

    [minimum, maximum],

    linestyle="--"

)


plt.xlabel(
    "Actual Fuel Consumption (tonnes)"
)

plt.ylabel(
    "Predicted Fuel Consumption (tonnes)"
)

plt.title(
    "Actual vs Predicted Fuel Consumption"
)

plt.tight_layout()


actual_pred_path = (
    f"{FIGURE_DIR}/"
    "operational_xgboost_actual_vs_predicted.png"
)


plt.savefig(
    actual_pred_path,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# 17. RESIDUAL ANALYSIS
# ============================================================

residuals = (
    y_test -
    predictions
)


plt.figure(
    figsize=(10, 6)
)

plt.scatter(

    predictions,

    residuals,

    alpha=0.5

)


plt.axhline(
    y=0,
    linestyle="--"
)


plt.xlabel(
    "Predicted Fuel Consumption (tonnes)"
)

plt.ylabel(
    "Residual (Actual - Predicted)"
)

plt.title(
    "Residual Analysis - Operational XGBoost"
)

plt.tight_layout()


residual_path = (
    f"{FIGURE_DIR}/"
    "operational_xgboost_residuals.png"
)


plt.savefig(
    residual_path,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


# ============================================================
# 18. COMPLETION
# ============================================================

print("\n" + "=" * 80)

print("EXPLAINABILITY COMPLETED")

print("=" * 80)

print("\nFeature importance saved:")
print(importance_path)

print("\nFigures saved:")

print(summary_path)
print(bar_path)
print(actual_pred_path)
print(residual_path)

print("\n" + "=" * 80)