import json
from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold, RandomizedSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from xgboost import XGBRegressor

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data" / "processed" / "MRV_2023_feature_engineered.csv"
OUTPUT = ROOT / "results" / "nested_cv_reanalysis_results.csv"
FEATURES = [
    "Ship_Type", "GT", "DWT", "Length_m", "Beam_m", "Draft_m", "Vessel_Age",
    "Length_Beam_Ratio", "DWT_GT_ratio", "Distance_nm", "Time_At_Sea_h",
    "Average_Speed_kn", "Sea_Time_Utilization",
]
TARGET = "Fuel_Consumption_t"
CAT = ["Ship_Type"]
NUM = [name for name in FEATURES if name not in CAT]
SEARCH_SPACE = {
    "model__n_estimators": [300, 400, 500, 600, 800, 1000],
    "model__learning_rate": [0.01, 0.03, 0.05, 0.07, 0.10],
    "model__max_depth": [3, 4, 5, 6, 7, 8],
    "model__min_child_weight": [1, 3, 5, 7],
    "model__subsample": [0.70, 0.80, 0.85, 0.90, 1.00],
    "model__colsample_bytree": [0.70, 0.80, 0.85, 0.90, 1.00],
    "model__gamma": [0, 0.1, 0.2, 0.3],
}


def make_pipeline():
    prep = ColumnTransformer(
        transformers=[
            ("numerical", Pipeline([("imputer", SimpleImputer(strategy="median", add_indicator=True))]), NUM),
            ("categorical", Pipeline([
                ("imputer", SimpleImputer(strategy="most_frequent")),
                ("onehot", OneHotEncoder(handle_unknown="ignore")),
            ]), CAT),
        ]
    )
    model = XGBRegressor(objective="reg:squarederror", random_state=42, n_jobs=-1)
    return Pipeline([("preprocessor", prep), ("model", model)])


def main():
    df = pd.read_csv(INPUT)
    X = df[FEATURES].copy()
    y = pd.to_numeric(df[TARGET], errors="coerce")
    valid = y.notna()
    X, y = X.loc[valid].reset_index(drop=True), y.loc[valid].reset_index(drop=True)

    outer = KFold(n_splits=5, shuffle=True, random_state=42)
    rows = []
    for fold, (train_idx, test_idx) in enumerate(outer.split(X, y), start=1):
        inner = KFold(n_splits=5, shuffle=True, random_state=42)
        search = RandomizedSearchCV(
            estimator=make_pipeline(),
            param_distributions=SEARCH_SPACE,
            n_iter=30,
            scoring="neg_root_mean_squared_error",
            cv=inner,
            random_state=42,
            n_jobs=1,
            return_train_score=False,
            refit=True,
        )
        search.fit(X.iloc[train_idx], y.iloc[train_idx])
        prediction = search.predict(X.iloc[test_idx])
        rows.append({
            "fold": fold,
            "n_train": len(train_idx),
            "n_test": len(test_idx),
            "R2": r2_score(y.iloc[test_idx], prediction),
            "MAE_t": mean_absolute_error(y.iloc[test_idx], prediction),
            "RMSE_t": mean_squared_error(y.iloc[test_idx], prediction) ** 0.5,
            "best_params": json.dumps(search.best_params_, sort_keys=True),
        })
        print(json.dumps(rows[-1]), flush=True)

    result = pd.DataFrame(rows)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(OUTPUT, index=False)
    summary = {
        metric: {
            "mean": float(result[metric].mean()),
            "sd_population": float(result[metric].std(ddof=0)),
        }
        for metric in ["R2", "MAE_t", "RMSE_t"]
    }
    print("SUMMARY", json.dumps(summary), flush=True)
    print("RESULTS_FILE", OUTPUT, flush=True)


if __name__ == "__main__":
    main()
