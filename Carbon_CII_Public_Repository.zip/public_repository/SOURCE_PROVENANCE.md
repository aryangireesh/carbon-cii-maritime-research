# Source provenance

## EU MRV source

- Source portal: EMSA THETIS-MRV public emissions reporting portal: https://mrv.emsa.europa.eu/#public/emission-report
- Local project filename: `2023-v91-15082026-EU MRV Publication of information.xlsx`
- Local size: 4,147,431 bytes
- SHA-256 of local source file: `ab143e656218a874a01da39ce306dcc454adffc344b4971f1a5bf146f42c4431`
- Access date was not preserved in the project records. The filename contains a version/date marker; this is not a verified download date.
- EMSA identifies the reporting data as publicly accessible. A source-specific licence permitting redistribution of this exact workbook was not verified.

## Vessel characteristics

- Source: Richard Iannone, MarineVessels R package: https://github.com/rich-iannone/MarineVessels
- Upstream repository identifies an MIT license. The local project had a `MarineVessels.rda` file in `data/external/`.
- Local file size: 1,656,340 bytes
- SHA-256 of local source file: `4924c131f82af0c34addee1f159d6b0f983e6529aefee5aac855c94ab852355f`
- The exact upstream commit/release corresponding to the local file was not recorded.

## Project analytical file

- File included: `data/processed/MRV_2023_feature_engineered.csv`
- Rows: 4,515; columns: 26; unique IMO values: 4,515; missing fuel target values: 0 (as observed in the local project file).
- SHA-256: `ef28a7d4384e4b729d52afec1a561b7a232f06a44b166457c61f5175d54e8792`
- This is a derived file and combines fields from public EU MRV reporting with vessel characteristics. Its inclusion in this review bundle follows the author's stated intent to share the derived dataset; downstream licensing remains subject to confirmation of source terms.
