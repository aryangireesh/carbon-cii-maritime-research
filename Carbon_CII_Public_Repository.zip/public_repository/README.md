# Carbon CII maritime modeling and scenario assessment

This repository contains the analysis code, a derived analytical dataset, result tables, and figures accompanying a study of annual vessel fuel-consumption prediction and a separate deterministic IMO Carbon Intensity Indicator (CII) scenario assessment.

## Main findings

The analytical cohort contains 4,515 2023 EU MRV records matched to MarineVessels characteristics by IMO number. Nested five-fold cross-validation of a tuned XGBoost regressor yielded R² = 0.9477 ± 0.0164, MAE = 467.65 ± 41.84 tonnes, and RMSE = 1,014.75 ± 201.92 tonnes (outer-fold mean ± population standard deviation). These are model-validation metrics for annual fuel consumption.

The CII results are from a separate deterministic calculation under an evaluated emissions scenario. Among 4,126 paired vessel ratings, 858 improved, 2,167 were unchanged, and 1,101 worsened. This scenario is not a forecast or causal estimate; the rating transition matrix is not a predictive confusion matrix.

## Repository contents

- `data/processed/MRV_2023_feature_engineered.csv`: 4,515-row analytical dataset with 26 columns, including vessel names and IMO identifiers.
- `data/derived/step15_final_validation_dataset.csv`: paired baseline/scenario validation records.
- `code/reproduce_nested_cv.py`: portable nested-CV reanalysis script.
- `code/original_project_scripts/`: copies of the project's analysis scripts. Machine-specific absolute paths were replaced in three later scripts; source project files were not modified.
- `results/`: fold metrics and supporting model/CII tables.
- `figures/`: eight images from the research paper.
- `SOURCE_PROVENANCE.md`, `RIGHTS_AND_LICENSE.md`, `THIRD_PARTY_NOTICES.md`: data origin and rights notes.

## Reproduce the primary fuel model evaluation

Install the packages listed in `requirements-reproduction.txt`, then run:

```text
python code/reproduce_nested_cv.py
```

The script reads the included analytical CSV and writes its fold-level results to `results/`. Nested cross-validation is computationally intensive. These results were not rerun while preparing this repository.

## Data sources

The project used the 2023 EU MRV publication workbook and vessel characteristics from the MarineVessels R package. The original workbook and `.rda` package file are not redistributed here. Source locations and local input-file checksums are in `SOURCE_PROVENANCE.md`.

## Rights and licence

No reuse licence is assigned to this combined repository. See `RIGHTS_AND_LICENSE.md` for the source-licence limitation and third-party attribution. Public availability does not by itself grant a licence to reuse materials.
